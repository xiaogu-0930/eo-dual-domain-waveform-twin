`timescale 1ns/1ps
// STAGE3 / D4 (user-approved: option A = horizontal 2:1 squeeze, vertical untouched; pair-priority overlay select (ii)).
// Right-half camera path.  ui_dbuf (A; only change = C-04c single-bit idle flag, rtl_r2/uidbuf.v) is parametrised as R_DATAWIDTH=64, R_XSIZE=R_XSTRIDE=960, R_BUFDEPTH=512
// so every 64-bit pop carries source pixels (2k, 2k+1) of the line, display x = 960 + k.
//   pop      -> ui_dbuf.I_R_tready : de_valid & (x_d2 >= X0) & en_frame & ddr_ready   (exactly 960 pops per line, right half only)
//   x_d2     = hcnt delayed 2 clocks, aligned with the ui_vtc de_valid output (which is 2 clocks behind hcnt)
//   en_frame = ddr_ready sampled at the rising edge of vs: the camera is shown/popped only for WHOLE frames
//   pair select: red ROI colour has priority over blue coordinate colour over the even pixel
//   output alignment: rgb/pix_valid are L clocks behind the raw hcnt of the same pixel (same convention as the compositor, L=6)
// Pixel format: 32-bit words, RGB in [23:0]; word[31:0]=source pixel 2k (lower address), word[63:32]=2k+1.
module cam_right_path #(
 parameter integer L = 6,
 parameter integer X0 = 960,
 parameter [23:0] ROI_COLOR   = 24'hFF0000,
 parameter [23:0] COORD_COLOR = 24'h0000FF,
 parameter [23:0] FALLBACK    = 24'h202020,   // shown on the right half when the camera is not enabled/valid
 parameter [23:0] UNDERRUN    = 24'hFF00FF    // shown when a pop found the FIFO empty (also latches 'underrun')
)(
 input  wire        clk,
 input  wire        rst_n,
 input  wire        de_valid,       // ui_vtc O_vtc_de_valid
 input  wire [11:0] hcnt,           // ui_vtc_xy O_vtc_hcnt (raw)
 input  wire        vs,             // ui_vtc O_vtc_vs
 input  wire        ddr_ready,      // merge_reset O_ddr_ready (pclk domain)
 input  wire        fifo_tvalid,    // ui_dbuf O_R_tvalid
 input  wire [63:0] fifo_data,      // ui_dbuf O_R_tdata
 output wire        pop,            // -> ui_dbuf I_R_tready
 output wire [23:0] rgb,
 output wire        pix_valid,      // rgb is a real camera pixel
 output reg         underrun        // sticky
);
 localparam integer ND = L - 4;
 reg [11:0] x_d1, x_d2;
 reg vs_d1, en_frame;
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin x_d1 <= 12'd0; x_d2 <= 12'd0; vs_d1 <= 1'b0; en_frame <= 1'b0; end
  else begin
   x_d1 <= hcnt; x_d2 <= x_d1; vs_d1 <= vs;
   if (vs & ~vs_d1) en_frame <= ddr_ready;
  end
 end
 wire active_right = de_valid & (x_d2 >= X0);
 assign pop = active_right & en_frame & ddr_ready;

 reg [63:0] d1; reg v1, u1;
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin d1 <= 64'd0; v1 <= 1'b0; u1 <= 1'b0; underrun <= 1'b0; end
  else begin
   d1 <= fifo_data; v1 <= pop & fifo_tvalid; u1 <= pop & ~fifo_tvalid;
   if (pop & ~fifo_tvalid) underrun <= 1'b1;
  end
 end
 wire [23:0] p0 = d1[23:0];
 wire [23:0] p1 = d1[55:32];
 wire red  = (p0 == ROI_COLOR)   | (p1 == ROI_COLOR);
 wire blue = (p0 == COORD_COLOR) | (p1 == COORD_COLOR);
 wire [23:0] sel = red ? ROI_COLOR : (blue ? COORD_COLOR : p0);
 reg [23:0] s2; reg sv2, su2;
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin s2 <= 24'd0; sv2 <= 1'b0; su2 <= 1'b0; end
  else begin s2 <= sel; sv2 <= v1; su2 <= u1; end
 end
 wire [24:0] o0 = su2 ? {1'b0, UNDERRUN} : (sv2 ? {1'b1, s2} : {1'b0, FALLBACK});
 generate
  if (ND <= 0) begin : g_nodelay
   assign {pix_valid, rgb} = o0;
  end else begin : g_delay
   reg [25*ND-1:0] sh;
   wire [25*ND+24:0] sh_ext = {sh, o0};
   always @(posedge clk or negedge rst_n) begin
    if (!rst_n) sh <= {ND{1'b0, FALLBACK}};   // reset value = FALLBACK, pix_valid=0
    else        sh <= sh_ext[25*ND-1:0];
   end
   assign {pix_valid, rgb} = sh[25*ND-1 -: 25];
  end
 endgenerate
endmodule
