`timescale 1ns/1ps
// STAGE3 production reset structure (replaces Stage 1/2 video_reset_gen; replacement point: merge_top instance X_video_rst).
// Decisions: R-1(a) display decoupled from DDR/camera; vrst = PLL lock -> 2-stage sync -> hold 2^HOLD_BITS pclk.
//            ddr_ready (init_cal_done -> pclk) gates ONLY the right half; it never feeds vrst.
//            B's run_rst_n only drives B's logic via a sys-domain rst_sync; it never touches the shared PLL.
//            DDR / ui_dbuf resets stay exactly as in A (not in this module).
module merge_reset #(
 parameter integer HOLD_BITS   = 20,   // A: ~dl_cnt[20] -> 2^20 pclk
 parameter integer SYNC_STAGES = 2
)(
 input  wire I_sys_clk,
 input  wire I_pclk,
 input  wire I_hsrx_clk,       // camera byte clock (may be absent: reset then stays asserted)
 input  wire I_pll_lock,       // raw ui_pll.lock, active high
 input  wire I_ddr_init_done,  // S_ddr_init_cal_done (dfi_clk domain), active high
 input  wire I_b_run_rst_n,    // B power-up reset (sys_clk domain), active low
 output wire O_sys_rst_n,      // sys_clk domain, A's 25 MHz logic
 output wire O_hsrx_rst_n,     // hs_rx_clk domain, A's camera/ISP logic
 output wire O_b_rst_n,        // sys_clk domain, B's logic only
 output wire O_vrst_n,         // pclk domain: VTC, compositor, scope core (active low)
 output wire O_vrst,           // pclk domain: HDMI I_rst (active high)
 output wire O_ddr_ready       // pclk domain, active high; right-half gate
);
 rst_sync #(.STAGES(SYNC_STAGES)) u_sys  (.clk(I_sys_clk),   .I_rst_n(I_pll_lock),      .O_rst_n(O_sys_rst_n));
 rst_sync #(.STAGES(SYNC_STAGES)) u_hsrx (.clk(I_hsrx_clk),  .I_rst_n(I_pll_lock),      .O_rst_n(O_hsrx_rst_n));
 rst_sync #(.STAGES(SYNC_STAGES)) u_b    (.clk(I_sys_clk),   .I_rst_n(I_b_run_rst_n),   .O_rst_n(O_b_rst_n));
 wire lock_p_n;
 rst_sync #(.STAGES(SYNC_STAGES)) u_vlock (.clk(I_pclk),     .I_rst_n(I_pll_lock),      .O_rst_n(lock_p_n));
 rst_sync #(.STAGES(SYNC_STAGES)) u_ddr   (.clk(I_pclk),     .I_rst_n(I_ddr_init_done), .O_rst_n(O_ddr_ready));
 // STAGE5 (fix11): the (HOLD_BITS+1)-bit hold counter is split into a low and a high half with a REGISTERED carry
 // (look-ahead one cycle: hold_c is high exactly in the cycle in which hold_lo is all ones).  The sequence of the
 // concatenation {hold_hi,hold_lo} is cycle-for-cycle identical to the original single counter (same reset, same
 // freeze value 2^HOLD_BITS, same O_vrst_n edge); only the carry chain is half as long.  Proven by tb_reset_eq.v.
 // Requires HOLD_BITS >= 1.
 localparam integer HW  = HOLD_BITS + 1;
 localparam integer LO  = HW / 2;
 localparam integer HI  = HW - LO;
 reg [LO-1:0] hold_lo;
 reg [HI-1:0] hold_hi;
 reg          hold_c;
 wire         hold_done = hold_hi[HI-1];
 always @(posedge I_pclk or negedge lock_p_n) begin
  if (!lock_p_n) begin
   hold_lo <= {LO{1'b0}};
   hold_hi <= {HI{1'b0}};
   hold_c  <= 1'b0;
  end else if (!hold_done) begin
   hold_lo <= hold_lo + 1'b1;
   hold_c  <= (hold_lo == ({LO{1'b1}} - 1'b1));
   if (hold_c) hold_hi <= hold_hi + 1'b1;
  end
 end
 assign O_vrst_n = hold_done;
 assign O_vrst   = ~hold_done;
endmodule
