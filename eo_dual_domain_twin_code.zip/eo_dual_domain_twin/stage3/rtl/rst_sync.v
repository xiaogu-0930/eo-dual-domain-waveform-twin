`timescale 1ns/1ps
// STAGE3: generic reset synchroniser. Active-low in/out.
//   assertion : asynchronous (I_rst_n low clears every stage at once)
//   release   : synchronous to clk, exactly STAGES clk edges after I_rst_n rises
// If clk is not running the output stays asserted (reset is never released without a clock).
// All STAGES flops have the async clear driven by I_rst_n -> recovery/removal endpoints = STAGES flops.
module rst_sync #(parameter integer STAGES = 2)(
 input  wire clk,
 input  wire I_rst_n,
 output wire O_rst_n
);
 reg [STAGES-1:0] q;
 always @(posedge clk or negedge I_rst_n) begin
  if (!I_rst_n) q <= {STAGES{1'b0}};
  else          q <= {q[STAGES-2:0], 1'b1};
 end
 assign O_rst_n = q[STAGES-1];
endmodule
