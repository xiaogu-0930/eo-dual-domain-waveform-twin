`timescale 1ns/1ps
// STAGE3 compositor (from Stage 2 video_compositor_scope): right half now = rgb_right from cam_right_path.
// rgb_right must be valid L-1 clocks after x_in (same alignment as rgb_left) -> build cam_right_path with L = L_comp - 1.
// COLOR_RIGHT kept only as an unused legacy parameter.
// Stage 2 compositor: left half = b_scope_core rgb (aligned), x==DIV_X divider, right half placeholder colour
// (Stage 3: A camera stream).  Single coordinate source x_in (from the one VTC).
// Latency: x_in(t) -> rgb_out(t+L), L = CORE_LAT + 1 = 6.  The core's rgb for x_in(t) is valid at t+5 (T5), x is
// pipelined to t+5 (L-1 stages) and the select is registered once more.
// hs/vs delayed L-1, de delayed L-2 (keeps A's native relative offsets).  Requires L >= 4.
module video_compositor_cam #(
 parameter integer L = 6,
 parameter integer DIV_X = 959,
 parameter [23:0] COLOR_DIV   = 24'hFFFFFF,
 parameter [23:0] COLOR_RIGHT = 24'hC04020
)(
 input  wire        clk,
 input  wire        rst_n,
 input  wire [11:0] x_in,
 input  wire        hs_in,
 input  wire        vs_in,
 input  wire        de_in,
 input  wire [23:0] rgb_left,    // b_scope_core.rgb, valid 5 clocks after x_in
 input  wire [23:0] rgb_right,   // cam_right_path.rgb built with L=L-1, valid 5 clocks after x_in
 output wire        hs_out,
 output wire        vs_out,
 output wire        de_out,
 output reg  [23:0] rgb_out
);
 localparam integer DH = L - 1;
 localparam integer DD = L - 2;
 reg [11:0] xs [0:L-2];
 reg [DH-1:0] hs_sr;
 reg [DH-1:0] vs_sr;
 reg [DD-1:0] de_sr;
 integer k;
 wire [11:0] x_last = xs[L-2];
 wire        de_next = de_sr[DD-2];
 assign hs_out = hs_sr[DH-1];
 assign vs_out = vs_sr[DH-1];
 assign de_out = de_sr[DD-1];
 always @(posedge clk) begin
  if (!rst_n) begin
   for (k = 0; k <= L-2; k = k + 1) xs[k] <= 12'd0;
   hs_sr   <= {DH{1'b0}};
   vs_sr   <= {DH{1'b0}};
   de_sr   <= {DD{1'b0}};
   rgb_out <= 24'h000000;
  end else begin
   xs[0] <= x_in;
   for (k = 1; k <= L-2; k = k + 1) xs[k] <= xs[k-1];
   hs_sr <= {hs_sr[DH-2:0], hs_in};
   vs_sr <= {vs_sr[DH-2:0], vs_in};
   de_sr <= {de_sr[DD-2:0], de_in};
   if (de_next) begin
    if (x_last < DIV_X)       rgb_out <= rgb_left;
    else if (x_last == DIV_X) rgb_out <= COLOR_DIV;
    else                      rgb_out <= rgb_right;
   end else
    rgb_out <= 24'h000000;
  end
 end
endmodule
