`timescale 1ns/1ps
// STAGE3 merged top (display side, no DDR/camera IP inside): real reset structure (merge_reset, replaces video_reset_gen),
// ONE ui_pll / ui_vtc_xy / hdmi_tx, B scope core on the left, cam_right_path + compositor on the right.
// The camera read FIFO is OUTSIDE this module: O_cam_pop -> ui_dbuf.I_R_tready, I_cam_tvalid/I_cam_tdata <- ui_dbuf (R_DATAWIDTH=64, ...),
// O_vtc_vs -> ui_dbuf.I_R_en, O_pclk -> ui_dbuf.I_R_rclk.  Stage 4/5 integrate A's DDR/camera around it.
// C-07 (Stage 4b, ADDITIVE ONLY): USE_STIM=0 takes B's scope data from the I_w_* ports instead of scope_stim_s2; the PLL's 25/70 MHz outputs, PLL lock and the
//   merge_reset outputs are brought out for A's camera/ISP logic; I_hsrx_clk feeds the hs_rx reset synchroniser (was tied to 0).  With the defaults (USE_STIM=1,
//   new inputs unconnected) the module is the Stage 3 module: tb_s3int does not change.
module merge_top_s3 #(
 parameter integer HOLD_BITS = 20,
 parameter integer L         = 6,        // compositor latency
 parameter integer L_CAM     = 5,        // cam_right_path latency = L-1 (mutation knob)
 parameter integer DIV_X     = 959,
 parameter integer USE_STIM  = 1         // C-07: 1 = scope_stim_s2 (Stage 2/3 tests), 0 = B's real data from I_w_*
)(
 input  wire        I_sys_clk,
 input  wire        I_ddr_init_done,     // S_ddr_init_cal_done (dfi_clk domain, async)
 input  wire        I_b_run_rst_n,       // B power-up reset (sys domain)
 output wire        O_pclk,
 output wire        O_vtc_vs,
 output wire        O_cam_pop,
 input  wire        I_cam_tvalid,
 input  wire [63:0] I_cam_tdata,
 output wire        O_cam_underrun,
 output wire [2:0]  O_hdmi_tx_p,
 output wire        O_hdmi_clk_p,
 // ---- C-07 additive ports ----
 input  wire        I_hsrx_clk,          // A camera byte clock (reset synchroniser clock); unconnected in Stage 3 tests
 output wire        O_clk25,             // ui_pll clk2_out
 output wire        O_clk70,             // ui_pll clk3_out
 output wire        O_pll_lock,
 output wire        O_sys_rst_n,         // merge_reset (sys_clk domain)
 output wire        O_hsrx_rst_n,        // merge_reset (hs_rx_clk domain)
 output wire        O_b_rst_n,           // merge_reset (sys_clk domain, B only)
 input  wire [767:0] I_w0, input wire [767:0] I_w1, input wire I_w_bank, input wire I_w_tog,
 input  wire [23:0] I_w_freq, input wire [15:0] I_w_amp, input wire [79:0] I_w_harm, input wire [39:0] I_w_hh,
 input  wire [2:0]  I_w_type, input wire [2:0] I_w_stat
);
 wire pclk, sclk, clk_25m, clk_70m, pll_lock;
 ui_pll X_ui_pll (.refclk(I_sys_clk), .reset(1'b0), .lock(pll_lock),
  .clk0_out(pclk), .clk1_out(sclk), .clk2_out(clk_25m), .clk3_out(clk_70m));
 assign O_pclk = pclk;
 assign O_clk25 = clk_25m; assign O_clk70 = clk_70m; assign O_pll_lock = pll_lock;

 wire sys_rst_n, hsrx_rst_n, b_rst_n, rst_n, vrst, ddr_ready;
 assign O_sys_rst_n = sys_rst_n; assign O_hsrx_rst_n = hsrx_rst_n; assign O_b_rst_n = b_rst_n;
 merge_reset #(.HOLD_BITS(HOLD_BITS)) X_reset (   // REPLACES Stage 1/2 X_video_rst (video_reset_gen)
  .I_sys_clk(I_sys_clk), .I_pclk(pclk), .I_hsrx_clk(I_hsrx_clk), .I_pll_lock(pll_lock),
  .I_ddr_init_done(I_ddr_init_done), .I_b_run_rst_n(I_b_run_rst_n),
  .O_sys_rst_n(sys_rst_n), .O_hsrx_rst_n(hsrx_rst_n), .O_b_rst_n(b_rst_n),
  .O_vrst_n(rst_n), .O_vrst(vrst), .O_ddr_ready(ddr_ready));

 wire vtc_vs, vtc_hs, vtc_de, vtc_user, vtc_last; wire [11:0] hcnt, vcnt;
 ui_vtc_xy #(.H_ActiveSize(1920), .H_SyncStart(1920+88), .H_SyncEnd(1920+88+44), .H_FrameSize(1920+88+44+16),
             .V_ActiveSize(1080), .V_SyncStart(1080+4), .V_SyncEnd(1080+4+5), .V_FrameSize(1080+4+5+19)) X_ui_vtc (
  .I_vtc_rstn(rst_n), .I_vtc_clk(pclk), .O_vtc_vs(vtc_vs), .O_vtc_hs(vtc_hs), .O_vtc_de_valid(vtc_de),
  .O_vtc_user(vtc_user), .O_vtc_last(vtc_last), .O_vtc_hcnt(hcnt), .O_vtc_vcnt(vcnt));
 assign O_vtc_vs = vtc_vs;
 // ---- C-05 REMOVED (C-10) ----
 // C-05 had given every pixel-domain consumer its own syn_keep register copy of hcnt/vcnt/de/hs/vs (36 flops).  The 2nd synthesis shows no such register in any
 // timing path or report and logs "141 dangling syn_keep insts", and the real pclk violation is elsewhere (b_scope_core char_calc, fixed by C-09).  A protection that cannot be
 // shown to exist is removed instead of kept as insurance.  Consumers read the VTC outputs directly again (relative alignment inside each consumer is unchanged;
 // the whole output is one pclk EARLIER than with C-05).  If the 3rd synthesis shows hcnt fanout as the worst pclk path, re-do the split with a mechanism that is verified in the netlist.

 wire [767:0] w0, w1; wire w_bank, w_tog; wire [23:0] w_freq; wire [15:0] w_amp; wire [79:0] w_harm;
 wire [39:0] w_hh; wire [2:0] w_type, w_stat;
 generate if (USE_STIM != 0) begin : g_stim
  scope_stim_s2 X_stim (.clk(I_sys_clk), .waveform0_flat(w0), .waveform1_flat(w1), .waveform_bank(w_bank), .update_toggle(w_tog),
   .frequency_x10_in(w_freq), .amplitude_cv_in(w_amp), .harmonics_cv_in(w_harm), .harmonic_heights_in(w_hh),
   .wave_type_in(w_type), .status_in(w_stat));
 end else begin : g_real
  assign w0 = I_w0; assign w1 = I_w1; assign w_bank = I_w_bank; assign w_tog = I_w_tog; assign w_freq = I_w_freq; assign w_amp = I_w_amp;
  assign w_harm = I_w_harm; assign w_hh = I_w_hh; assign w_type = I_w_type; assign w_stat = I_w_stat;
 end endgenerate
 wire [23:0] scope_rgb;
 b_scope_core #(.DRAW_DIVIDER(0)) X_scope (.pixel_clk(pclk), .rst_n(rst_n),
  .waveform0_flat(w0), .waveform1_flat(w1), .waveform_bank(w_bank), .update_toggle(w_tog),
  .frequency_x10_in(w_freq), .amplitude_cv_in(w_amp), .harmonics_cv_in(w_harm), .harmonic_heights_in(w_hh),
  .wave_type_in(w_type), .status_in(w_stat), .x_in(hcnt), .y_in(vcnt), .rgb(scope_rgb));

 wire [23:0] cam_rgb; wire cam_pix_valid;
 cam_right_path #(.L(L_CAM)) X_cam (.clk(pclk), .rst_n(rst_n), .de_valid(vtc_de), .hcnt(hcnt), .vs(vtc_vs), .ddr_ready(ddr_ready),
  .fifo_tvalid(I_cam_tvalid), .fifo_data(I_cam_tdata), .pop(O_cam_pop), .rgb(cam_rgb), .pix_valid(cam_pix_valid), .underrun(O_cam_underrun));

 wire c_hs, c_vs, c_de; wire [23:0] c_rgb;
 video_compositor_cam #(.L(L), .DIV_X(DIV_X)) X_compositor (.clk(pclk), .rst_n(rst_n), .x_in(hcnt),
  .hs_in(vtc_hs), .vs_in(vtc_vs), .de_in(vtc_de), .rgb_left(scope_rgb), .rgb_right(cam_rgb),
  .hs_out(c_hs), .vs_out(c_vs), .de_out(c_de), .rgb_out(c_rgb));

 hdmi_tx #(.DEVICE("PH1A_HP")) X_hdmi_tx (.I_pixel_clk(pclk), .I_serial_clk(sclk), .I_rst(vrst),
  .I_video_in_data(c_rgb), .I_video_in_de(c_de), .I_video_in_vs(c_vs), .I_video_in_hs(c_hs),
  .O_hdmi_clk_p(O_hdmi_clk_p), .O_hdmi_tx_p(O_hdmi_tx_p));
endmodule
