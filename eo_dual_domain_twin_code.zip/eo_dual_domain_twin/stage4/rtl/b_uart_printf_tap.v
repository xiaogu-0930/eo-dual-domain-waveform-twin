`timescale 1ns/1ps
// Decimal ASCII output for frequency, fundamental Vpp, harmonic Vpp and class.
// Binary values are converted with double-dabble; UART never sends hex digits.
module uart_printf #(parameter integer CLK_HZ=25000000,
 parameter integer BAUD=115200,
 parameter integer PEAK_TO_CENTIVOLT_Q16=63015)(
 input wire clk,rst_n,start,
 input wire [2:0] status,
 input wire [2:0] wave_type,
 input wire plot_mode,
 input wire [23:0] frequency_x10,
 input wire [15:0] wave_pp,h1_a,h2_a,h3_a,h4_a,h5_a,
 output wire byte_valid, output wire [7:0] byte_data, input wire byte_ready, output reg busy,done);   // C-06: byte tap replaces tx
 localparam integer LINE_LENGTH=122;
 reg [31:0] values[0:5],decimal_digits[0:5];
 reg [2:0] status_latched,wave_type_latched,field_index;
 reg plot_mode_latched;
 reg [5:0] conversion_bit;
 reg [31:0] binary_shift,bcd,corrected_bcd;
 reg [2:0] state;
 reg [6:0] character_index;
 reg uart_send;
 reg [7:0] uart_data;
 wire uart_busy;
 wire [31:0] scale_product=values[field_index][15:0]*PEAK_TO_CENTIVOLT_Q16;
 wire [31:0] scale_rounded=scale_product+32'd32768;
 wire [15:0] voltage_centi=(scale_rounded[31:16]>9999)?16'd9999:scale_rounded[31:16];
 integer digit,harmonic,field_position;
 uart_byte_tap transmitter   // C-06: was uart_tx (baud shifter); same send/data/busy handshake
  (.clk(clk),.rst_n(rst_n),.send(uart_send),.data(uart_data),.busy(uart_busy),.byte_valid(byte_valid),.byte_data(byte_data),.byte_ready(byte_ready));
 always @* begin
  corrected_bcd=bcd;
  for(digit=0;digit<8;digit=digit+1)
   if(bcd[digit*4 +: 4]>=5)
    corrected_bcd[digit*4 +: 4]=bcd[digit*4 +: 4]+4'd3;
 end
 function [7:0] line_character;
  input [6:0] index;
  begin
   line_character=" ";
   case(index)
    0: line_character="F";
    1: line_character="0";
    2: line_character="=";
    3: line_character=8'h30+{4'b0,decimal_digits[0][27:24]};
    4: line_character=8'h30+{4'b0,decimal_digits[0][23:20]};
    5: line_character=8'h30+{4'b0,decimal_digits[0][19:16]};
    6: line_character=8'h30+{4'b0,decimal_digits[0][15:12]};
    7: line_character=8'h30+{4'b0,decimal_digits[0][11:8]};
    8: line_character=8'h30+{4'b0,decimal_digits[0][7:4]};
    9: line_character=".";
    10: line_character=8'h30+{4'b0,decimal_digits[0][3:0]};
    11: line_character="H";
    12: line_character="z";
    13: line_character=",";
    14: line_character="A";
    15: line_character="M";
    16: line_character="P";
    17: line_character="=";
    18: line_character=8'h30+{4'b0,decimal_digits[1][15:12]};
    19: line_character=8'h30+{4'b0,decimal_digits[1][11:8]};
    20: line_character=".";
    21: line_character=8'h30+{4'b0,decimal_digits[1][7:4]};
    22: line_character=8'h30+{4'b0,decimal_digits[1][3:0]};
    23: line_character="V";
    24: line_character="p";
    25: line_character="p";
    26: line_character=",";
    27: line_character="S";
    28: line_character="T";
    29: line_character="A";
    30: line_character="T";
    31: line_character="U";
    32: line_character="S";
    33: line_character="=";
    34: line_character=8'h30+{5'b0,status_latched};
    35: line_character=",";
    36: line_character="T";
    37: line_character="Y";
    38: line_character="P";
    39: line_character="E";
    40: line_character="=";
    41,42,43,44,45,46,47,48: begin
     case(wave_type_latched)
      0: case(index)
       41: line_character="S"; 42: line_character="I";
       43: line_character="N"; 44: line_character="E";
       default: line_character=" ";
      endcase
      1: case(index)
       41: line_character="S"; 42: line_character="Q";
       43: line_character="U"; 44: line_character="A";
       45: line_character="R"; 46: line_character="E";
       default: line_character=" ";
      endcase
      2: case(index)
       41: line_character="T"; 42: line_character="R";
       43: line_character="I"; 44: line_character="A";
       45: line_character="N"; 46: line_character="G";
       47: line_character="L"; 48: line_character="E";
       default: line_character=" ";
      endcase
      3: case(index)
       41: line_character="M"; 42: line_character="I";
       43: line_character="X"; 44: line_character="E";
       45: line_character="D";
       default: line_character=" ";
      endcase
      default: case(index)
       41: line_character="U"; 42: line_character="N";
       43: line_character="K"; 44: line_character="N";
       45: line_character="O"; 46: line_character="W";
       47: line_character="N";
       default: line_character=" ";
      endcase
     endcase
    end
    49: line_character=",";
    50: line_character=" ";
    51: line_character="M";
    52: line_character="O";
    53: line_character="D";
    54: line_character="E";
    55: line_character="=";
    56,57,58,59: begin
     if(plot_mode_latched) case(index)
      56: line_character="R"; 57: line_character="A"; 58: line_character="W";
      default: line_character=" ";
     endcase
     else case(index)
      56: line_character="F"; 57: line_character="U"; 58: line_character="N";
      59: line_character="D";
      default: line_character=" ";
     endcase
    end
    60: line_character=",";
    120: line_character=8'h0d;
    121: line_character=8'h0a;
    default: begin
     if(index>=61 && index<=119) begin
      harmonic=(index-61)/12;
      field_position=(index-61)%12;
      case(field_position)
       0: line_character="H";
       1: line_character=8'h31+harmonic;
       2: line_character="=";
       3: line_character=8'h30+{4'b0,decimal_digits[harmonic+1][15:12]};
       4: line_character=8'h30+{4'b0,decimal_digits[harmonic+1][11:8]};
       5: line_character=".";
       6: line_character=8'h30+{4'b0,decimal_digits[harmonic+1][7:4]};
       7: line_character=8'h30+{4'b0,decimal_digits[harmonic+1][3:0]};
       8: line_character="V";
       9,10: line_character="p";
       11: if(harmonic<4) line_character=",";
       default: line_character=" ";
      endcase
     end
    end
   endcase
  end
 endfunction
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0; busy<=0; done<=0; uart_send<=0; uart_data<=0;
   status_latched<=0; wave_type_latched<=4; plot_mode_latched<=0;
   field_index<=0; conversion_bit<=0;
   binary_shift<=0; bcd<=0; character_index<=0;
  end else begin
   uart_send<=0; done<=0;
   case(state)
    0: if(start) begin
     status_latched<=status;
     wave_type_latched<=wave_type;
     plot_mode_latched<=plot_mode;
     values[0]<={8'b0,frequency_x10};
     values[1]<={16'b0,h1_a};
     values[2]<={16'b0,h2_a};
     values[3]<={16'b0,h3_a};
     values[4]<={16'b0,h4_a};
     values[5]<={16'b0,h5_a};
     field_index<=0; busy<=1; state<=1;
    end
    1: begin
     binary_shift<=(field_index==0)?values[0]:voltage_centi;
     bcd<=0; conversion_bit<=0; state<=2;
    end
    2: begin
     bcd<={corrected_bcd[30:0],binary_shift[31]};
     binary_shift<={binary_shift[30:0],1'b0};
     if(conversion_bit==31) state<=3;
     else conversion_bit<=conversion_bit+1'b1;
    end
    3: begin
     decimal_digits[field_index]<=bcd;
     if(field_index==5) begin character_index<=0; state<=4; end
     else begin field_index<=field_index+1'b1; state<=1; end
    end
    4: if(!uart_busy) begin
     uart_data<=line_character(character_index); uart_send<=1; state<=5;
    end
    5: if(uart_busy) state<=6;
    6: if(!uart_busy) begin
     if(character_index==LINE_LENGTH-1) begin busy<=0; done<=1; state<=0; end
     else begin character_index<=character_index+1'b1; state<=4; end
    end
    default: begin state<=0; busy<=0; end
   endcase
  end
 end
endmodule
