`timescale 1ns / 1ns

// 32 点波形采样和 UART 验证模块。
// 视频时钟域把 ROI 横向划分�?32 个区间，每个区间记录命中像素�?
// sum_y/count_y，帧结束后以命中点平均值作为该区间的代表坐标。
// 系统时钟域在按键触发后等待下一帧，并发�?P00..P31 �?32 个采样点�?
// 仅使�?32 组小型寄存器，不使用�?wave_column_accum �?1521 列数组，
// 也不使用�?wave_uart_report 的大 FIFO�?
module wave_sample32_uart #(
    parameter integer SYS_CLK_HZ       = 25_000_000,
    parameter integer BAUD_RATE        = 115_200,
    parameter integer ROI_X_START      = 400,
    parameter integer ROI_X_END        = 1200,
    parameter integer ROI_Y_START      = 250,
    parameter integer ROI_Y_END        = 650,
    // Reject trace candidates too close to the ROI top/bottom border.
    // A value of 0 keeps the complete ROI; 4 removes the usual border
    // saturation caused by a missing trace column.
    parameter integer EDGE_GUARD_PIXELS = 4,
    parameter integer EDGE_AVERAGE_REJECT_ENABLE = 0,
    parameter integer SAMPLE_COUNT     = 128,
    // 25 MHz 系统时钟下约 4 ms 按键消抖
    parameter integer DEBOUNCE_CYCLES  = 100_000,
    // 相邻采样点允许的最�?Y 跳变量，超过该值视为异常点
    parameter integer Y_JUMP_MAX       = 100,
    parameter integer OUTLIER_THRESHOLD = 60,
    // 0: 暂时保留所有原始有效点，用于验证采样链路；1: 启用趋势异常点剔除
    parameter integer OUTLIER_FILTER_ENABLE = 1,
    parameter integer FRAME_WAIT_TIMEOUT_CYCLES = 1_000_000,
    // 1: 对没有命中波形的横向区间进行补点�?: 保留 FFFF 便于调试
    parameter integer INVALID_FILL_ENABLE = 1,
    // 1: 内部缺失点按横坐标线性插值；0: 临时使用左右点平均值，便于验证 HDMI 链路
    parameter integer LINEAR_INTERP_ENABLE = 1,
    parameter integer DAC_CODE_MIN         = 0,
    parameter integer DAC_CODE_MAX         = 16383,
    // 像素 -> DAC 码 的可标定比例：code = OFFSET + (ROI_Y_END - y) * NUM / DEN
    //
    // 默认 (16383 / 400) 只保证"像素振幅占 ROI 的比例"正确，不保证真实电压。
    // 要恢复原始电压，先实测 DAC 在两个已知码值下的输出电压，再定 NUM/DEN：
    //   V_per_pixel = 示波器 V/div / 每格像素数
    //   NUM / DEN   = V_per_pixel / V_FS_dac * 16384
    // 例如 V/div=0.5、每格 100 px、DAC 满量程 5.0 V：
    //   5 mV/px / 5 V * 16384 = 16 码/px -> NUM=16, DEN=1
    parameter integer DAC_Y_SCALE_NUM      = 16383,
    parameter integer DAC_Y_SCALE_DEN      = 400,
    parameter integer DAC_Y_SCALE_OFFSET   = 0,
    // 2026-11-02 调试：1 = 不做 NUM/DEN 乘除，直接用
    //   code = 8192 + (DAC_Y_MID_PX - y) * 32
    // 只保留一次减法/移位，先把波形和时序跑通。改回 0 恢复标定。
    parameter integer DAC_SIMPLE_MODE      = 0,
    // 波形在 ROI 内实际占用的像素高度（居中基准用这个，而不是整个 ROI 高度）。
    // 默认 400 = 整个 ROI，行为与原来一致；标定时填波形的真实跨度，
    // 否则 NUM/DEN 调大后 span_code 会超出 16383 导致钳位。
    parameter integer DAC_Y_ACTIVE_PX      = 400,   // 已弃用，仅保留兼容
    // 波形中线在 ROI 坐标系里的 y 值（由该帧 y_min/y_max 求得）。
    // 默认 = ROI 中心，与旧的"以 ROI 底边为原点"公式在默认比例下等价。
    parameter integer DAC_Y_MID_PX         = (ROI_Y_START + ROI_Y_END) / 2,
    // DAC 显示门控：一次快照里至少要有多少个有效点才允许刷新 DAC。
    // 以前是"128 点全部有效 && x 范围有效 && 两个守恒检查全过"才刷新，
    // 任何一条纯诊断条件出问题都会让 DAC 静默冻在上一帧（报告 P1）。
    parameter integer DAC_MIN_VALID_POINTS = (SAMPLE_COUNT * 3) / 4,
    // R-2: 0 = the TIMEOUT report carries no live video-domain arrays (clean CDC); the array fields are
    //      reported as sentinels (FFFF / FFFFFFFF = "not measured", never 0).
    //      1 = legacy dump of the live arrays.  DEBUG ONLY: this is an UNCONTROLLED cross-domain read of
    //      multi-bit video-domain state.  It must not be used in any acceptance, regression-signoff or
    //      production build; it is excluded from the timing constraints.
    parameter integer TIMEOUT_LIVE_DUMP = 0,
    // R-2: system clocks to wait for the status-snapshot acknowledge on the timeout path.
    parameter integer STATUS_ACK_LIMIT = 512,
    // R-2: I_video_clk frequency meter.  The gate is open for FREQ_GATE_CYCLES sys clocks (default 1 s);
    // the reported HS_RX_CNT is the number of I_video_clk rising edges counted in that window
    // (= Hz when FREQ_GATE_CYCLES = SYS_CLK_HZ).  Measured every 2*FREQ_GATE_CYCLES, last value reported.
    parameter integer FREQ_GATE_CYCLES = SYS_CLK_HZ,
    // Stage 4 / C-06: 1 = byte tap for the shared T25 UART mux (no baud shifter here; a byte is 'pending' in tx_active until I_byte_ready).
    // 0 (default) = the original UART transmitter, behaviour unchanged.
    parameter integer BYTE_TAP = 0
)(
    input  wire        I_sys_clk,
    input  wire        I_video_clk,
    input  wire        I_rst_n,
    input  wire        I_capture_key_n,
    input  wire        I_frame_start,
    input  wire        I_frame_end,
    input  wire        I_sample_valid,
    input  wire [15:0] I_sample_x,
    input  wire [15:0] I_sample_y,
    output wire        O_uart_tx,
    // Stage 4 / C-06 byte tap (all 0 when BYTE_TAP=0)
    input  wire        I_byte_ready,
    output wire        O_tap_valid,
    output wire [7:0]  O_tap_data,
    output wire        O_tap_is_ack,
    output wire        O_tap_rpt_req,
    output wire        O_tap_ack_req,
    output wire [15:0] O_tap_rpt_len,
    output wire [7:0]  O_tap_req_drop,
    output wire [7:0]  O_tap_stale_drop,
    output wire        O_report_busy,
    output reg         O_dac_sample_we,
    output reg  [7:0]  O_dac_sample_addr,
    output reg  [13:0] O_dac_sample_code,
    output reg         O_dac_frame_commit,
    output reg         O_dac_frame_valid,
    // ChipWatcher 调试输出：补点前32个分区有效标志，以及两个重点分区状态
    output wire [7:0]  O_dbg_raw_valid_0,
    output wire [7:0]  O_dbg_raw_valid_1,
    output wire [7:0]  O_dbg_raw_valid_2,
    output wire [7:0]  O_dbg_raw_valid_3,
    output wire [7:0]  O_dbg_bin14_status,
    output wire [7:0]  O_dbg_bin24_status
);

    localparam integer ROI_WIDTH = ROI_X_END - ROI_X_START + 1;
    localparam integer BIN_WIDTH = (ROI_WIDTH / SAMPLE_COUNT < 1) ? 1 :
                                   (ROI_WIDTH / SAMPLE_COUNT);
    localparam integer BAUD_DIV  = (SYS_CLK_HZ / BAUD_RATE < 1) ? 1 :
                                   (SYS_CLK_HZ / BAUD_RATE);
    localparam integer DB_WIDTH  = (DEBOUNCE_CYCLES <= 1) ? 1 :
                                   $clog2(DEBOUNCE_CYCLES + 1);
    localparam [DB_WIDTH-1:0] DEBOUNCE_LIMIT = DEBOUNCE_CYCLES;
    // FRAME_START(13) + FMT(8, R-2) + FIRST_X/LAST_X(27) + debug fields(805+41 R-2)
    // + SAMPLE_COUNT points + FRAME_END(11)
    localparam integer DEBUG_OFFSET = 48;   // R-2: +8 bytes (FMT=02 line after FRAME_START)
    localparam integer DEBUG_BYTES  = 1003;  // R-2: +41 bytes (REQ_DROP / STALE_DROP / STATUS_OK) +20 bytes (HS_RX_CNT)
    localparam integer POINTS_OFFSET = DEBUG_OFFSET + DEBUG_BYTES;
    // Each point reports final Y, raw hit count, raw sum, and raw average:
    // P00=yyyy,C=cccc,S=ssssssss,R=rrrr\r\n (35 bytes).
    localparam integer POINT_RECORD_BYTES = 35;
    localparam integer REPORT_BYTES = POINTS_OFFSET + SAMPLE_COUNT * POINT_RECORD_BYTES + 11;
    localparam integer REPORT_POS_WIDTH = (REPORT_BYTES <= 2) ? 1 :
                                          $clog2(REPORT_BYTES);
    localparam integer WAIT_WIDTH = (FRAME_WAIT_TIMEOUT_CYCLES <= 1) ? 1 :
                                    $clog2(FRAME_WAIT_TIMEOUT_CYCLES + 1);

    // ---- 像素 -> 码值标定（以波形中线为原点）--------------------------
    // code = MID + (DAC_Y_MID_PX - y) * NUM / DEN
    //
    // 旧实现以 ROI 底边(ROI_Y_END)为原点：
    //   code = center + (ROI_Y_END - y) * NUM / DEN
    // 缩放比例一大，整段码值就会整体偏移甚至饱和——因为原点不是波形中心。
    //
    // 现在原点是波形中线 DAC_Y_MID_PX（由该帧的 y_min/y_max 求出）：
    //   y = y_mid  -> MID（正中）
    //   y = y_min  -> MID + span/2（顶部）
    //   y = y_max  -> MID - span/2（底部）
    // 默认 MID 取 ROI 中心、NUM/DEN = 16383/400 时，行为与旧公式一致。
    // DAC_Y_SCALE_OFFSET 仍是叠加在居中基础上的细调（默认 0）。
    // Pure ROI-bottom origin (rolled back 2026-11-02):
    //   code = DAC_CODE_MIN + DAC_Y_SCALE_OFFSET + (ROI_Y_END - y) * NUM / DEN
    function [13:0] pixel_y_to_dac_code;
        input [15:0] pixel_y;
        reg signed [63:0] scaled_y;
        reg signed [63:0] mapped_code;
        reg signed [31:0] simple_code;
        reg [31:0] y_span;
        begin
            if (DAC_SIMPLE_MODE != 0) begin
                // 调试通路：1 px = 32 码，以 DAC_Y_MID_PX 为中点。
                // 没有乘法器/除法器，只有一次减法和左移。
                simple_code = 32'sd8192 +
                    (($signed(DAC_Y_MID_PX) - $signed({16'd0, pixel_y})) <<< 5);
                if (simple_code >= DAC_CODE_MAX)
                    pixel_y_to_dac_code = DAC_CODE_MAX;
                else if (simple_code <= DAC_CODE_MIN)
                    pixel_y_to_dac_code = DAC_CODE_MIN;
                else
                    pixel_y_to_dac_code = simple_code[13:0];
            end else if ((ROI_Y_END <= ROI_Y_START) || (DAC_Y_SCALE_DEN <= 0)) begin
                pixel_y_to_dac_code = 14'h2000;
            end else begin
                if (pixel_y <= ROI_Y_START)
                    y_span = ROI_Y_END - ROI_Y_START;
                else if (pixel_y >= ROI_Y_END)
                    y_span = 0;
                else
                    y_span = ROI_Y_END - pixel_y;

                scaled_y = y_span * DAC_Y_SCALE_NUM;
                mapped_code = DAC_CODE_MIN + DAC_Y_SCALE_OFFSET +
                    (scaled_y / DAC_Y_SCALE_DEN);
                if (mapped_code >= DAC_CODE_MAX)
                    pixel_y_to_dac_code = DAC_CODE_MAX;
                else if (mapped_code <= DAC_CODE_MIN)
                    pixel_y_to_dac_code = DAC_CODE_MIN;
                else
                    pixel_y_to_dac_code = mapped_code[13:0];
            end
        end
    endfunction

    // ------------------------------------------------------------------
    // Video clock domain: 32-bin average accumulation.
    // ------------------------------------------------------------------
    // ROI内每个分区最多可能命中数千个像素，不能使�?位计数器�?
    reg [31:0] bin_sum_y [0:SAMPLE_COUNT-1];
    reg [15:0] bin_count_y [0:SAMPLE_COUNT-1];
    // Stable frame-end snapshot consumed by division, filtering and UART.
    reg [31:0] scan_sum_y [0:SAMPLE_COUNT-1];
    reg [15:0] scan_count_y [0:SAMPLE_COUNT-1];
    // Raw per-bin average, captured when the divide stage completes.  This
    // is diagnostic data and is intentionally kept separate from the final
    // value that may later be filtered or filled.
    reg [15:0] raw_average_y_mem [0:SAMPLE_COUNT-1];
    reg [15:0] frame_y_mem [0:SAMPLE_COUNT-1];
    reg        frame_valid_mem [0:SAMPLE_COUNT-1];
    reg        capture_x_valid;
    reg [15:0] capture_first_x;
    reg [15:0] capture_last_x;
    reg        frame_x_valid;
    reg [15:0] frame_first_x;
    reg [15:0] frame_last_x;
    reg        frame_toggle;
    reg        frame_ready_pending;
    // Publish the completed snapshot one video clock before toggling the
    // cross-domain frame event.  This gives the system-clock synchronizers a
    // stable bus instead of changing the payload and toggle on the same edge.
    reg        frame_commit_pending;
    reg [15:0] done_count_mem [0:SAMPLE_COUNT-1];
    reg [31:0] done_sum_mem [0:SAMPLE_COUNT-1];
    reg [7:0] done_zero_count_sum_errors;
    reg [7:0] done_first_zero_count_sum_error;
    reg [7:0] done_nonzero_count_zero_sum_errors;
    reg [7:0] done_first_nonzero_count_zero_sum_error;
    // 零计数/零求和错误统计改成在除法阶段"每 bin 一拍"串行累加，
    // 不再在 finalize 里做一次 128 路汇总（那条路径布线占 10 ns，
    // 是 2026-10-30 报告里的新最差路径）。
    reg [7:0] scan_zero_cnt;
    reg [7:0] scan_zero_first;
    reg [7:0] scan_nz_cnt;
    reg [7:0] scan_nz_first;
    reg [7:0] done_division_errors;
    reg [7:0] done_first_division_error;
    reg [31:0] done_first_division_error_sum;
    reg [15:0] done_first_division_error_count_value;
    reg [15:0] done_first_division_error_quotient;
    reg [16:0] done_first_division_error_remainder;
    reg [5:0]  done_first_division_error_bit;
    reg [31:0] done_first_division_error_shift;
    reg [16:0] done_first_division_error_pre_rem;
    reg [31:0] done_first_division_error_pre_q;
    reg [16:0] done_first_division_error_trial;
    reg [31:0] done_first_division_error_next_q;
    reg [31:0] done_p7f_sum;
    reg [15:0] done_p7f_count;
    reg [15:0] done_p7f_raw_y;
    reg [15:0] done_raw_y_mem [0:SAMPLE_COUNT-1];
    reg [15:0] done_frame_y_mem [0:SAMPLE_COUNT-1];
    reg        done_frame_valid_mem [0:SAMPLE_COUNT-1];
    reg [31:0] capture_accept_count;
    reg [15:0] capture_y_min;
    reg [15:0] capture_y_max;
    reg [31:0] done_accept_count;
    reg [31:0] done_capture_count;
    reg [15:0] done_y_min;
    reg [15:0] done_y_max;
    reg [31:0] capture_input_y_sum;
    reg [31:0] done_input_y_sum;
    reg [31:0] divide_count_sum;
    reg [31:0] done_bin_count_sum;
    reg [31:0] divide_y_sum;
    reg [31:0] done_bin_y_sum;
    reg [7:0] finalize_zero_count_sum_error_accum;
    reg [7:0] finalize_first_zero_count_sum_error;
    reg [7:0] finalize_nonzero_count_zero_sum_accum;
    reg [7:0] finalize_first_nonzero_count_zero_sum;
    reg [7:0] division_error_count;
    reg [7:0] first_division_error;
    reg [31:0] first_division_error_sum;
    reg [15:0] first_division_error_count_value;
    reg [15:0] first_division_error_quotient;
    reg [16:0] first_division_error_remainder;
    reg [5:0]  first_division_error_bit;
    reg [31:0] first_division_error_shift;
    reg [16:0] first_division_error_pre_rem;
    reg [31:0] first_division_error_pre_q;
    reg [16:0] first_division_error_trial;
    reg [31:0] first_division_error_next_q;
    reg [31:0] pre_div_sum [0:2];
    reg [15:0] pre_div_count [0:2];
    reg        pre_div_valid [0:2];
    reg [31:0] done_pre_div_sum [0:2];
    reg [15:0] done_pre_div_count [0:2];
    reg        done_pre_div_valid [0:2];
    reg [31:0] done_dbg_sum [0:2];
    reg [15:0] done_dbg_count [0:2];
    reg [15:0] done_dbg_avg [0:2];
    reg        done_dbg_valid [0:2];
    reg        done_x_valid;
    reg [15:0] done_first_x;
    reg [15:0] done_last_x;
    reg [1:0]  req_gray_meta; /* fehdl keep="true" */                 // R-2: Gray-coded request tag, 2-FF synchroniser per bit (video side)
    reg [1:0]  req_gray_sync; /* fehdl keep="true" */
    // System-clock-domain key event toggle, declared here because the
    // video-domain synchronizer below references it.
    reg [1:0]  req_id_sys;                    // R-2: binary request counter (+1 per ACCEPTED press), sys domain only
    reg [1:0]  req_gray_sys;                  // Gray code of req_id_sys, a FLOP (exactly one bit changes per accept);
                                              // this is the only request signal that crosses to the video domain
    reg        fm_gate_sys;                   // sys: gate (flop output), crosses to video through a 2-FF
    wire [1:0] req_id_next   = req_id_sys + 2'd1;
    wire [1:0] req_gray_next = req_id_next ^ {1'b0, req_id_next[1]};
    reg        capture_armed;
    reg        capture_active;
    // ---- R-2 request binding (video domain): a frame may be reported only if it was
    // started after the key press that is currently pending.  *_req = request toggle
    // that armed the frame, *_valid = nothing re-armed the video side while it was in flight.
    reg [1:0]  cap_req;  reg cap_owned;       // 2-bit request tag (see req_id_sys)
    reg        fm_gate_meta, fm_gate_sync, fm_gate_q; /* fehdl keep="true" */   // video: 2-FF for the single-bit gate
    reg [31:0] fm_cnt, fm_result;                        // video: edge counter / latched result (stable for the whole idle half)
    reg        fm_done;                                  // video: toggles when fm_result is updated
    reg [1:0]  req_seen;                      // tag of the request that armed the video side
    reg [1:0]  post_req; reg post_valid;
    reg [1:0]  done_req; reg done_valid;
    // ---- R-2 status snapshots (video domain).  st_* is written in the same video clock
    // edge that flips frame_toggle (frame path); tq_* is written on a request/acknowledge
    // handshake (timeout path).  The system domain reads them only after the event/ack.
    reg [8:0]  st_post_state;   reg        st_div_busy;   reg [5:0]  st_div_bit;
    reg [2:0]  st_fill_stage;   reg        st_div_active; reg        st_div_load;
    reg [7:0]  st_div_index;    reg [15:0] st_divisor;    reg [15:0] st_div_quotient;
    reg [31:0] st_div_remainder; reg [31:0] st_div_sum;
    reg [8:0]  tq_post_state;   reg        tq_div_busy;   reg [5:0]  tq_div_bit;
    reg [2:0]  tq_fill_stage;   reg        tq_div_active; reg        tq_div_load;
    reg [7:0]  tq_div_index;    reg [15:0] tq_divisor;    reg [15:0] tq_div_quotient;
    reg [31:0] tq_div_remainder; reg [31:0] tq_div_sum;
    reg [31:0] tq_capture_count; reg [15:0] tq_y_min; reg [15:0] tq_y_max;
    reg [31:0] tq_y_sum; reg [31:0] tq_bin_count_sum; reg [31:0] tq_bin_y_sum;
    reg        tq_req_meta, tq_req_sync, tq_req_seen; /* fehdl keep="true" */   // video side of the request toggle
    reg        tq_ack_pending, tq_ack;                    // video side of the acknowledge toggle
    reg        tq_req_sys;                                // system side request toggle (declared here: used by video sync)
    wire       arm_now = (req_gray_sync != req_seen);
    reg        sample_pending;
    reg [7:0]  sample_bin_index_pending;
    reg [15:0] sample_x_pending;
    reg [15:0] sample_y_pending;
    reg        frame_end_pending;
    reg        frame_finalize_pending;
    reg        divide_active;
    reg        divide_load;
    reg        divide_bin_busy;
    reg        fill_active;
    reg [7:0]  fill_index;
    reg [7:0]  fill_scan_index;
    reg        fill_have_value;
    reg [15:0] fill_hold_y;
    reg        filter_active;
    reg [7:0]  filter_index;
    reg        filter_have_prev;
    reg        filter_have_prev2;
    reg [15:0] filter_prev_y;
    reg [15:0] filter_prev2_y;
    reg [7:0]  divide_index;
    reg [31:0] divide_quotient;
    reg [31:0] divide_numerator;
    reg [16:0] divide_remainder;
    reg [15:0] divide_divisor;
    reg [5:0]  divide_bit_index;
    reg [31:0] divide_average_value;
    wire scan_zero_hit = (scan_count_y[divide_index] == 0) &&
                         (scan_sum_y[divide_index] != 0);
    wire scan_nz_hit   = (scan_count_y[divide_index] != 0) &&
                         (scan_sum_y[divide_index] == 0);
    // 2026-11-02：给 done_* 诊断计数器用的 S/C 打一拍。
    // 原来 scan_sum_y[divide_index] 的 128:1 mux 组合到
    // done_nonzero_count_zero_sum_errors 的 +1，是 9.853 ns 的 setup
    // 关键路径（-0.099 ns）。divide_index 在整个除法段稳定，末 bin 的
    // 锁存值与当前 bin 相同，因此语义不变，只把 mux 后的比较/加一
    // 放到寄存器之后。
    reg [31:0] scan_sum_err_lat;
    reg [15:0] scan_count_err_lat;
    always @(posedge I_video_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            scan_sum_err_lat <= 32'd0;
            scan_count_err_lat <= 16'd0;
        end else begin
            scan_sum_err_lat <= scan_sum_y[divide_index];
            scan_count_err_lat <= scan_count_y[divide_index];
        end
    end
    wire scan_zero_hit_lat = (scan_count_err_lat == 0) &&
                             (scan_sum_err_lat != 0);
    wire scan_nz_hit_lat   = (scan_count_err_lat != 0) &&
                             (scan_sum_err_lat == 0);
    wire [16:0] divide_trial_remainder =
        {divide_remainder[15:0], divide_numerator[31]};
    wire        divide_quotient_bit =
        (divide_trial_remainder >= {1'b0, divide_divisor});
    wire [16:0] divide_difference =
        divide_trial_remainder - {1'b0, divide_divisor};
    wire [31:0] divide_quotient_next =
        {divide_quotient[30:0], divide_quotient_bit};
    wire [16:0] divide_remainder_next = divide_quotient_bit ?
        divide_difference : divide_trial_remainder;
    // 除法占用标志：装载时置 1、最后一位算完清 0。
    // 用它禁止"运行中被重新装载"——否则 numerator 会被重新加载、
    // quotient/remainder 被清零、bit_index 回到 31 重头再除，
    // 板上表现就是商突然变成 0 或极小值（见检查报告 §10.4）。
    reg        div_inflight;
    integer clear_index;
    integer filter_current_y;
    integer filter_diff_y;
    integer filter_delta_y;
    integer filter_predict_y;
    integer filter_predict_diff_y;
    integer fill_scan;
    integer fill_prev_found;
    integer fill_next_found;
    integer fill_prev_index;
    integer fill_next_index;
    integer fill_prev_y;
    integer fill_next_y;
    integer fill_delta_y_signed;
    integer fill_offset_x_signed;
    integer fill_span_x_signed;
    integer fill_interpolated_y;
    integer fill_value_y;
    reg fill_output_valid;
    reg [2:0] fill_stage;
    // 插值除法改成多拍恢复除法：stage2 锁存操作数、stage3 每拍 1 位。
    // 原来 (delta*offset)/span 一拍算完，是 -27.8ns 的最差路径（52 级、
    // 40 个加法器、1 个 DSP 乘法，见 final_timing.rpt）。
    reg [15:0] dv_num;
    reg [15:0] dv_den;
    reg [15:0] dv_base;
    reg [15:0] dv_quot;
    reg [16:0] dv_rem;
    reg [3:0]  dv_bit;
    reg        dv_neg;
    reg [15:0] dv_quot_next;
    reg        fill_step_done;
    // 第 2 拍的流水寄存器：把 7 个 128:1 mux 的输出先存下来，
    // 判定和乘法放到下一拍，避免"mux + 乘法"串在同一条路径上。
    reg [15:0] cap_y;
    reg [15:0] cap_cnt;
    reg        cap_valid;
    reg        cap_lf;
    reg        cap_rf;
    reg [15:0] cap_ly;
    reg [15:0] cap_ry;
    reg [7:0]  cap_li;
    reg [7:0]  cap_ri;
    reg       fill_prev_valid;
    reg       fill_next_valid;
    reg [7:0] fill_prev_index_reg;
    reg [7:0] fill_next_index_reg;
    reg [15:0] fill_prev_y_reg;
    reg [15:0] fill_next_y_reg;
    reg [7:0] fill_left_index_mem [0:SAMPLE_COUNT-1];
    reg [7:0] fill_right_index_mem [0:SAMPLE_COUNT-1];
    reg [15:0] fill_left_y_mem [0:SAMPLE_COUNT-1];
    reg [15:0] fill_right_y_mem [0:SAMPLE_COUNT-1];
    reg fill_left_found_mem [0:SAMPLE_COUNT-1];
    reg fill_right_found_mem [0:SAMPLE_COUNT-1];

    wire sample_accept = capture_active && I_sample_valid &&
                         (I_sample_x >= ROI_X_START) &&
                         (I_sample_x <= ROI_X_END) &&
                         (I_sample_y >= (ROI_Y_START + EDGE_GUARD_PIXELS)) &&
                         (I_sample_y <= (ROI_Y_END - EDGE_GUARD_PIXELS));
    wire [31:0] sample_x_relative = {16'd0, I_sample_x} - ROI_X_START;
    // 分箱：bin = x_rel * SAMPLE_COUNT / ROI_WIDTH
    // 用"乘倒数 + 移位"代替常数除法。原来的 /ROI_WIDTH 会被综合成一条
    // 20 级的移位加减链，是 2026-10-30 报告里 -1.139 ns 的最差路径
    // （X_waveform_extract/O_sample_x_reg → mux3447）。
    // M = floor(SAMPLE_COUNT * 2^18 / ROI_WIDTH)。对当前两组参数
    // （ROI_WIDTH=741 与 801）逐点验证过：0..ROI_WIDTH-1 全部与整数除法一致。
    localparam integer BIN_MUL_SHIFT = 18;
    localparam integer BIN_MUL =
        (SAMPLE_COUNT << BIN_MUL_SHIFT) / ROI_WIDTH;
    wire [31:0] sample_bin_calculated =
        (sample_x_relative * BIN_MUL) >> BIN_MUL_SHIFT;
    wire [7:0] sample_bin_index =
        (sample_bin_calculated >= SAMPLE_COUNT) ?
        (SAMPLE_COUNT - 1) : sample_bin_calculated[7:0];

    // 单个样本的写入条件。这里用一次"变址读"求出被选中 bin 的状态，
    // 替代原实现里 128 路 "sample_bin_index_pending == i" 的或树，
    // 全局计数器、x 追踪、最小/最大 y 都不再依赖 128 路循环体。
    wire bin_write_en = sample_pending &&
                        (sample_bin_index_pending < SAMPLE_COUNT) &&
                        (bin_count_y[sample_bin_index_pending] != 16'hffff) &&
                        (capture_accept_count != 32'hffff_ffff);

    // Y 坐标保护：波形提取结果必须落在纵�?ROI 内�?
    // 该保护同时用于原始平均值、填充值和 UART 显示值�?
    function [15:0] clamp_y;
        input integer value;
        begin
            if (value < ROI_Y_START)
                clamp_y = ROI_Y_START;
            else if (value > ROI_Y_END)
                clamp_y = ROI_Y_END;
            else
                clamp_y = value;
        end
    endfunction

    // 调试信号只读映射，不参与视频�?UART 数据路径�?
    // 每个 raw_valid 探针按低位到高位覆盖连续8个采样区间。
    assign O_dbg_raw_valid_0 = {(bin_count_y[7] != 0),  (bin_count_y[6] != 0),
                                (bin_count_y[5] != 0),  (bin_count_y[4] != 0),
                                (bin_count_y[3] != 0),  (bin_count_y[2] != 0),
                                (bin_count_y[1] != 0),  (bin_count_y[0] != 0)};
    assign O_dbg_raw_valid_1 = {(bin_count_y[15] != 0), (bin_count_y[14] != 0),
                                (bin_count_y[13] != 0), (bin_count_y[12] != 0),
                                (bin_count_y[11] != 0), (bin_count_y[10] != 0),
                                (bin_count_y[9] != 0),  (bin_count_y[8] != 0)};
    assign O_dbg_raw_valid_2 = {(bin_count_y[23] != 0), (bin_count_y[22] != 0),
                                (bin_count_y[21] != 0), (bin_count_y[20] != 0),
                                (bin_count_y[19] != 0), (bin_count_y[18] != 0),
                                (bin_count_y[17] != 0), (bin_count_y[16] != 0)};
    assign O_dbg_raw_valid_3 = {(bin_count_y[31] != 0), (bin_count_y[30] != 0),
                                (bin_count_y[29] != 0), (bin_count_y[28] != 0),
                                (bin_count_y[27] != 0), (bin_count_y[26] != 0),
                                (bin_count_y[25] != 0), (bin_count_y[24] != 0)};
    // bit7 为滤�?补点前后的最终有效状态，bit6:0 为原始命中像素数�?
    assign O_dbg_bin14_status = {frame_valid_mem[14], bin_count_y[14][6:0]};
    assign O_dbg_bin24_status = {frame_valid_mem[24], bin_count_y[24][6:0]};

    always @(posedge I_video_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_toggle <= 1'b0;
            frame_ready_pending <= 1'b0;
            frame_commit_pending <= 1'b0;
            req_gray_meta <= 2'd0;
            req_gray_sync <= 2'd0;
            capture_armed <= 1'b0;
            capture_active <= 1'b0;
            cap_req <= 2'd0; cap_owned <= 1'b0; post_req <= 2'd0; post_valid <= 1'b0; req_seen <= 2'd0;
            done_req <= 2'd0; done_valid <= 1'b0;
            tq_req_meta <= 1'b0; tq_req_sync <= 1'b0; tq_req_seen <= 1'b0;
            fm_gate_meta <= 1'b0; fm_gate_sync <= 1'b0; fm_gate_q <= 1'b0;
            fm_cnt <= 32'd0; fm_result <= 32'd0; fm_done <= 1'b0;
            tq_ack_pending <= 1'b0; tq_ack <= 1'b0;
            st_post_state <= 9'd0; st_div_busy <= 1'b0; st_div_bit <= 6'd0; st_fill_stage <= 3'd0;
            st_div_active <= 1'b0; st_div_load <= 1'b0; st_div_index <= 8'd0; st_divisor <= 16'd0;
            st_div_quotient <= 16'd0; st_div_remainder <= 32'd0; st_div_sum <= 32'd0;
            tq_post_state <= 9'd0; tq_div_busy <= 1'b0; tq_div_bit <= 6'd0; tq_fill_stage <= 3'd0;
            tq_div_active <= 1'b0; tq_div_load <= 1'b0; tq_div_index <= 8'd0; tq_divisor <= 16'd0;
            tq_div_quotient <= 16'd0; tq_div_remainder <= 32'd0; tq_div_sum <= 32'd0;
            tq_capture_count <= 32'd0; tq_y_min <= 16'd0; tq_y_max <= 16'd0; tq_y_sum <= 32'd0;
            tq_bin_count_sum <= 32'd0; tq_bin_y_sum <= 32'd0;
            sample_pending <= 1'b0;
            sample_bin_index_pending <= 8'd0;
            sample_x_pending <= 16'd0;
            sample_y_pending <= 16'd0;
            frame_end_pending <= 1'b0;
            frame_finalize_pending <= 1'b0;
            divide_active <= 1'b0;
            divide_load <= 1'b0;
            divide_bin_busy <= 1'b0;
            div_inflight <= 1'b0;
            fill_active <= 1'b0;
            fill_output_valid <= 1'b0;
            fill_index <= 8'd0;
            fill_stage <= 2'd0;
            dv_num <= 16'd0;
            dv_den <= 16'd1;
            dv_base <= 16'd0;
            dv_quot <= 16'd0;
            dv_rem <= 17'd0;
            dv_bit <= 4'd0;
            dv_neg <= 1'b0;
            dv_quot_next <= 16'd0;
            cap_y <= 16'hffff;
            cap_cnt <= 16'd0;
            cap_valid <= 1'b0;
            cap_lf <= 1'b0;
            cap_rf <= 1'b0;
            cap_ly <= 16'd0;
            cap_ry <= 16'd0;
            cap_li <= 8'd0;
            cap_ri <= 8'd0;
            fill_prev_valid <= 1'b0;
            fill_next_valid <= 1'b0;
            fill_prev_index_reg <= 8'd0;
            fill_next_index_reg <= 8'd0;
            fill_prev_y_reg <= 16'd0;
            fill_next_y_reg <= 16'd0;
            fill_scan_index <= 8'd0;
            fill_have_value <= 1'b0;
            fill_hold_y <= 16'd0;
            filter_active <= 1'b0;
            filter_index <= 8'd0;
            filter_have_prev <= 1'b0;
            filter_have_prev2 <= 1'b0;
            filter_prev_y <= 16'd0;
            filter_prev2_y <= 16'd0;
            divide_index <= 8'd0;
            divide_remainder <= 17'd0;
            divide_divisor <= 16'd0;
            divide_quotient <= 32'd0;
            divide_numerator <= 32'd0;
            divide_bit_index <= 6'd0;
            for (clear_index = 0; clear_index < SAMPLE_COUNT; clear_index = clear_index + 1) begin
                bin_sum_y[clear_index]     <= 32'd0;
                bin_count_y[clear_index]   <= 16'd0;
                scan_sum_y[clear_index]    <= 32'd0;
                scan_count_y[clear_index]  <= 16'd0;
                raw_average_y_mem[clear_index] <= 16'hffff;
                frame_y_mem[clear_index]  <= 16'd0;
                frame_valid_mem[clear_index] <= 1'b0;
                done_count_mem[clear_index] <= 16'd0;
                done_sum_mem[clear_index] <= 32'd0;
                done_raw_y_mem[clear_index] <= 16'hffff;
                done_frame_y_mem[clear_index] <= 16'hffff;
                done_frame_valid_mem[clear_index] <= 1'b0;
                fill_left_index_mem[clear_index] <= 8'd0;
                fill_right_index_mem[clear_index] <= 8'd0;
                fill_left_y_mem[clear_index] <= 16'd0;
                fill_right_y_mem[clear_index] <= 16'd0;
                fill_left_found_mem[clear_index] <= 1'b0;
                fill_right_found_mem[clear_index] <= 1'b0;
            end
            capture_accept_count <= 32'd0;
            capture_y_min <= 16'hffff;
            capture_y_max <= 16'd0;
            done_accept_count <= 32'd0;
            done_capture_count <= 32'd0;
            done_y_min <= 16'hffff;
            done_y_max <= 16'd0;
            capture_input_y_sum <= 32'd0;
            done_input_y_sum <= 32'd0;
            done_zero_count_sum_errors <= 8'd0;
            done_first_zero_count_sum_error <= 8'hff;
            done_nonzero_count_zero_sum_errors <= 8'd0;
            done_first_nonzero_count_zero_sum_error <= 8'hff;
            done_division_errors <= 8'd0;
            done_first_division_error <= 8'hff;
            done_first_division_error_sum <= 32'd0;
            done_first_division_error_count_value <= 16'd0;
            done_first_division_error_quotient <= 16'd0;
            done_first_division_error_remainder <= 17'd0;
            done_first_division_error_bit <= 6'd0;
            done_first_division_error_shift <= 32'd0;
            done_first_division_error_pre_rem <= 17'd0;
            done_first_division_error_pre_q <= 32'd0;
            done_first_division_error_trial <= 17'd0;
            done_first_division_error_next_q <= 32'd0;
            division_error_count <= 8'd0;
            first_division_error <= 8'hff;
            first_division_error_sum <= 32'd0;
            first_division_error_count_value <= 16'd0;
            first_division_error_quotient <= 16'd0;
            first_division_error_remainder <= 17'd0;
            first_division_error_bit <= 6'd0;
            first_division_error_shift <= 32'd0;
            first_division_error_pre_rem <= 17'd0;
            first_division_error_pre_q <= 32'd0;
            first_division_error_trial <= 17'd0;
            first_division_error_next_q <= 32'd0;
            divide_count_sum <= 32'd0;
            done_bin_count_sum <= 32'd0;
            divide_y_sum <= 32'd0;
            done_bin_y_sum <= 32'd0;
            done_p7f_sum <= 32'd0;
            done_p7f_count <= 16'd0;
            done_p7f_raw_y <= 16'hffff;
            divide_numerator <= 32'd0;
            finalize_zero_count_sum_error_accum = 8'd0;
            finalize_first_zero_count_sum_error = 8'hff;
            finalize_nonzero_count_zero_sum_accum = 8'd0;
            finalize_first_nonzero_count_zero_sum = 8'hff;
            for (clear_index = 0; clear_index < 3; clear_index = clear_index + 1) begin
                done_dbg_sum[clear_index] <= 32'd0;
                done_dbg_count[clear_index] <= 16'd0;
                done_dbg_avg[clear_index] <= 16'hffff;
                done_dbg_valid[clear_index] <= 1'b0;
                pre_div_sum[clear_index] <= 32'd0;
                pre_div_count[clear_index] <= 16'd0;
                pre_div_valid[clear_index] <= 1'b0;
                done_pre_div_sum[clear_index] <= 32'd0;
                done_pre_div_count[clear_index] <= 16'd0;
                done_pre_div_valid[clear_index] <= 1'b0;
            end
            capture_x_valid <= 1'b0;
            capture_first_x <= 16'd0;
            capture_last_x  <= 16'd0;
            frame_x_valid   <= 1'b0;
            frame_first_x   <= 16'd0;
            frame_last_x    <= 16'd0;
        end else begin
            req_gray_meta <= req_gray_sys;
            req_gray_sync <= req_gray_meta;

            // Pipeline one accepted pixel so the bin write uses the static
            // decoder used by the target FPGA synthesis flow.
            sample_pending <= sample_accept && !frame_end_pending;
            if (sample_accept && !frame_end_pending) begin
                sample_bin_index_pending <= sample_bin_index;
                sample_x_pending <= I_sample_x;
                sample_y_pending <= I_sample_y;
            end
            // A stretched frame-end level becomes one pending event only.
            frame_end_pending <= capture_active && I_frame_end &&
                                 !frame_end_pending;

            // The snapshot registers are written while frame_ready_pending is
            // asserted.  Toggle only on the following video clock so the
            // system domain cannot observe a new event with an old payload.
            if (frame_commit_pending) begin
                frame_commit_pending <= 1'b0;
                frame_toggle <= ~frame_toggle;
                // R-2: coherent status snapshot, same edge as the toggle (read by the system
                // domain only after it has seen the toggle).
                st_post_state <= {frame_ready_pending, fill_active, filter_active, divide_bin_busy,
                                  divide_load, divide_active, frame_finalize_pending,
                                  frame_end_pending, capture_active};
                st_div_busy <= divide_bin_busy;   st_div_bit <= divide_bit_index;
                st_fill_stage <= fill_stage;      st_div_active <= divide_active;
                st_div_load <= divide_load;       st_div_index <= divide_index;
                st_divisor <= divide_divisor;     st_div_quotient <= divide_quotient;
                st_div_remainder <= divide_remainder;
                st_div_sum <= scan_sum_y[divide_index];
            end

            if (frame_ready_pending) begin
                for (clear_index = 0; clear_index < SAMPLE_COUNT; clear_index = clear_index + 1) begin
                    done_count_mem[clear_index] <= scan_count_y[clear_index];
                    done_sum_mem[clear_index] <= scan_sum_y[clear_index];
                    done_raw_y_mem[clear_index] <= raw_average_y_mem[clear_index];
                    // Keep independently verified bins even when diagnostics
                    // find corruption elsewhere in the frame. Bad bins have
                    // already been marked invalid by the divider and are
                    // excluded from interpolation anchors.
                    done_frame_y_mem[clear_index] <=
                        (frame_valid_mem[clear_index] &&
                         (frame_y_mem[clear_index] >= ROI_Y_START) &&
                         (frame_y_mem[clear_index] <= ROI_Y_END)) ?
                        frame_y_mem[clear_index] : 16'hffff;
                    done_frame_valid_mem[clear_index] <=
                        frame_valid_mem[clear_index] &&
                        (frame_y_mem[clear_index] >= ROI_Y_START) &&
                        (frame_y_mem[clear_index] <= ROI_Y_END);
                end
                done_p7f_sum <= scan_sum_y[127];
                done_p7f_count <= scan_count_y[127];
                done_p7f_raw_y <= raw_average_y_mem[127];
                done_division_errors <= division_error_count;
                done_first_division_error <= first_division_error;
                done_first_division_error_sum <= first_division_error_sum;
                done_first_division_error_count_value <= first_division_error_count_value;
                done_first_division_error_quotient <= first_division_error_quotient;
                done_first_division_error_remainder <= first_division_error_remainder;
                done_first_division_error_bit <= first_division_error_bit;
                done_first_division_error_shift <= first_division_error_shift;
                done_first_division_error_pre_rem <= first_division_error_pre_rem;
                done_first_division_error_pre_q <= first_division_error_pre_q;
                done_first_division_error_trial <= first_division_error_trial;
                done_first_division_error_next_q <= first_division_error_next_q;
                done_x_valid <= frame_x_valid;
                done_first_x <= frame_first_x;
                done_last_x <= frame_last_x;
                // ACC_HITS = Σ bin 计数，由除法阶段的串行累加器提供�?
                done_accept_count <= divide_count_sum;

                done_dbg_sum[0] <= scan_sum_y[1];
                done_dbg_sum[1] <= scan_sum_y[15];
                done_dbg_sum[2] <= scan_sum_y[62];
                done_dbg_count[0] <= scan_count_y[1];
                done_dbg_count[1] <= scan_count_y[15];
                done_dbg_count[2] <= scan_count_y[62];
                done_dbg_avg[0] <= raw_average_y_mem[1];
                done_dbg_avg[1] <= raw_average_y_mem[15];
                done_dbg_avg[2] <= raw_average_y_mem[62];
                done_dbg_valid[0] <= (scan_count_y[1] != 0);
                done_dbg_valid[1] <= (scan_count_y[15] != 0);
                done_dbg_valid[2] <= (scan_count_y[62] != 0);
                done_pre_div_sum[0] <= pre_div_sum[0];
                done_pre_div_sum[1] <= pre_div_sum[1];
                done_pre_div_sum[2] <= pre_div_sum[2];
                done_pre_div_count[0] <= pre_div_count[0];
                done_pre_div_count[1] <= pre_div_count[1];
                done_pre_div_count[2] <= pre_div_count[2];
                done_pre_div_valid[0] <= pre_div_valid[0];
                done_pre_div_valid[1] <= pre_div_valid[1];
                done_pre_div_valid[2] <= pre_div_valid[2];
                frame_ready_pending <= 1'b0;
                frame_commit_pending <= 1'b1;
                done_req <= post_req;
                done_valid <= post_valid;
            end

            if (arm_now) begin
                capture_armed <= 1'b1;
                // R-2: a new request invalidates everything still in flight.
                post_valid <= 1'b0;
                done_valid <= 1'b0;
                // A frame already being captured belongs to the old request: it stays invalid.
                cap_owned <= !capture_active;
                req_seen <= req_gray_sync;
                if (!capture_active) cap_req <= req_gray_sync;
            end

            // R-2: I_video_clk frequency meter (gate from the sys domain, result handed back with a done toggle).
            fm_gate_meta <= fm_gate_sys;
            fm_gate_sync <= fm_gate_meta;
            fm_gate_q    <= fm_gate_sync;
            if (fm_gate_sync) begin
                if (!fm_gate_q) fm_cnt <= 32'd1;
                else            fm_cnt <= fm_cnt + 1'b1;
            end
            if (!fm_gate_sync && fm_gate_q) begin
                fm_result <= fm_cnt;
                fm_done   <= ~fm_done;
            end

            // R-2: status request / acknowledge (timeout path).  tq_* is written on the edge that
            // sees the request, the acknowledge toggles one clock later.
            tq_req_meta <= tq_req_sys;
            tq_req_sync <= tq_req_meta;
            if (tq_ack_pending) begin
                tq_ack_pending <= 1'b0;
                tq_ack <= ~tq_ack;
            end
            if (tq_req_sync != tq_req_seen) begin
                tq_req_seen <= tq_req_sync;
                tq_post_state <= {frame_ready_pending, fill_active, filter_active, divide_bin_busy,
                                  divide_load, divide_active, frame_finalize_pending,
                                  frame_end_pending, capture_active};
                tq_div_busy <= divide_bin_busy;   tq_div_bit <= divide_bit_index;
                tq_fill_stage <= fill_stage;      tq_div_active <= divide_active;
                tq_div_load <= divide_load;       tq_div_index <= divide_index;
                tq_divisor <= divide_divisor;     tq_div_quotient <= divide_quotient;
                tq_div_remainder <= divide_remainder;
                tq_div_sum <= scan_sum_y[divide_index];
                tq_capture_count <= capture_accept_count;
                tq_y_min <= capture_y_min;        tq_y_max <= capture_y_max;
                tq_y_sum <= capture_input_y_sum;
                tq_bin_count_sum <= divide_count_sum;
                tq_bin_y_sum <= divide_y_sum;
                tq_ack_pending <= 1'b1;
            end

            if (capture_armed && I_frame_start) begin
                capture_armed <= arm_now;       // R-2: do not lose a request that arrives on this very edge
                capture_active <= 1'b1;
                cap_req <= req_seen;  // the request that armed this frame
                cap_owned <= !arm_now;
                for (clear_index = 0; clear_index < SAMPLE_COUNT; clear_index = clear_index + 1) begin
                    bin_sum_y[clear_index] <= 32'd0;
                    bin_count_y[clear_index] <= 16'd0;
                    raw_average_y_mem[clear_index] <= 16'hffff;
                end
                capture_accept_count <= 32'd0;
                capture_y_min <= 16'hffff;
                capture_y_max <= 16'd0;
                capture_input_y_sum <= 32'd0;
                capture_x_valid <= 1'b0;
                capture_first_x <= 16'd0;
                capture_last_x  <= 16'd0;
            end

            /*
            if (sample_accept &&
                (I_sample_x >= ROI_X_START) &&
                (I_sample_x <= ROI_X_END) &&
                // 只累加纵�?ROI 内的坐标，防止异�?y 值污染区间平均值�?
                (I_sample_y >= (ROI_Y_START + EDGE_GUARD_PIXELS)) &&
                (I_sample_y <= (ROI_Y_END - EDGE_GUARD_PIXELS))) begin
                if (capture_accept_count != 32'hffff_ffff)
                    capture_accept_count <= capture_accept_count + 1'b1;
                capture_input_y_sum <= capture_input_y_sum + I_sample_y;
                if (I_sample_y < capture_y_min)
                    capture_y_min <= I_sample_y;
                if (I_sample_y > capture_y_max)
                    capture_y_max <= I_sample_y;
                if (!capture_x_valid) begin
                    capture_x_valid <= 1'b1;
                    capture_first_x <= I_sample_x;
                    capture_last_x  <= I_sample_x;
                end else begin
                    if (I_sample_x < capture_first_x)
                        capture_first_x <= I_sample_x;
                    if (I_sample_x > capture_last_x)
                        capture_last_x <= I_sample_x;
                end
                // X-to-bin mapping is computed once and reused by all accesses.
                // 以固定区间宽度分箱，避免综合出大乘法�?除法器�?
                // Map the complete ROI to all bins, including the right edge.
                // Static decode makes the one-bin write explicit to synthesis.
                // Exactly one iteration matches sample_bin_index for an accepted sample.
                for (clear_index = 0; clear_index < SAMPLE_COUNT;
                     clear_index = clear_index + 1) begin
                    if (sample_bin_index == clear_index) begin
                        if (bin_count_y[clear_index] == 0) begin
                            bin_sum_y[clear_index] <= {16'd0, I_sample_y};
                            bin_count_y[clear_index] <= 16'd1;
                        end else begin
                            bin_sum_y[clear_index] <=
                                bin_sum_y[clear_index] + I_sample_y;
                            if (bin_count_y[clear_index] != 16'hffff)
                                bin_count_y[clear_index] <=
                                    bin_count_y[clear_index] + 1'b1;
                        end
                    end
                end
            end

            */
            if (bin_write_en) begin
                // 全局统计量只在循环外更新一次，不再经过 128 路或树�?
                capture_accept_count <= capture_accept_count + 1'b1;
                capture_input_y_sum <= capture_input_y_sum + sample_y_pending;
                if (sample_y_pending < capture_y_min)
                    capture_y_min <= sample_y_pending;
                if (sample_y_pending > capture_y_max)
                    capture_y_max <= sample_y_pending;
                if (!capture_x_valid) begin
                    capture_x_valid <= 1'b1;
                    capture_first_x <= sample_x_pending;
                    capture_last_x <= sample_x_pending;
                end else begin
                    if (sample_x_pending < capture_first_x)
                        capture_first_x <= sample_x_pending;
                    if (sample_x_pending > capture_last_x)
                        capture_last_x <= sample_x_pending;
                end
                // 只剩"写哪一�?bin"需�?128 路静态译码；条件已在外面判过�?
                for (clear_index = 0; clear_index < SAMPLE_COUNT;
                     clear_index = clear_index + 1) begin
                    if (sample_bin_index_pending == clear_index) begin
                        if (bin_count_y[clear_index] == 0) begin
                            bin_sum_y[clear_index] <= {16'd0, sample_y_pending};
                            bin_count_y[clear_index] <= 16'd1;
                        end else begin
                            bin_sum_y[clear_index] <=
                                bin_sum_y[clear_index] + sample_y_pending;
                            bin_count_y[clear_index] <=
                                bin_count_y[clear_index] + 1'b1;
                        end
                    end
                end
            end

            if (frame_end_pending && capture_active) begin
                capture_active <= 1'b0;
                frame_finalize_pending <= 1'b1;
                post_req <= cap_req;
                post_valid <= cap_owned && !arm_now;
            end

            // Run the frame scan only after the final registered pixel has
            // committed its count, sum, and coordinate updates above.
            if (frame_finalize_pending) begin
                frame_finalize_pending <= 1'b0;
                finalize_zero_count_sum_error_accum = 8'd0;
                finalize_first_zero_count_sum_error = 8'hff;
                finalize_nonzero_count_zero_sum_accum = 8'd0;
                finalize_first_nonzero_count_zero_sum = 8'hff;
                scan_zero_cnt <= 8'd0;
                scan_zero_first <= 8'hff;
                scan_nz_cnt <= 8'd0;
                scan_nz_first <= 8'hff;
                division_error_count <= 8'd0;
                first_division_error <= 8'hff;
                first_division_error_sum <= 32'd0;
                first_division_error_count_value <= 16'd0;
                first_division_error_quotient <= 16'd0;
                first_division_error_remainder <= 17'd0;
                first_division_error_bit <= 6'd0;
                first_division_error_shift <= 32'd0;
                first_division_error_pre_rem <= 17'd0;
                first_division_error_pre_q <= 32'd0;
                first_division_error_trial <= 17'd0;
                first_division_error_next_q <= 32'd0;
                for (clear_index = 0; clear_index < SAMPLE_COUNT;
                     clear_index = clear_index + 1) begin
                    scan_sum_y[clear_index] <= bin_sum_y[clear_index];
                    scan_count_y[clear_index] <= bin_count_y[clear_index];
                end
                // 总数不再用"单周期 128 级 64 位阻塞累加"求，改由除法阶段
                // 已有的串行累加器 divide_count_sum / divide_y_sum 给出
                // （每 bin 一拍，128 拍完成，天然可收敛）。
                // 见检查报告 §9.1 / §10.5：原来的链在板上必然算错。
                frame_x_valid <= capture_x_valid;
                frame_first_x <= capture_x_valid ? capture_first_x : 16'hffff;
                frame_last_x <= capture_x_valid ? capture_last_x : 16'hffff;
                // Snapshot input-side diagnostics at the same frame boundary as bins.
                // Keep input-side counters independent from the bin totals so
                // UART diagnostics can detect a dropped or duplicated commit.
                done_capture_count <= capture_accept_count;
                done_y_min <= capture_y_min;
                done_y_max <= capture_y_max;
                done_input_y_sum <= capture_input_y_sum;
                // 零计数/零求和错误在除法阶段串行统计（见 divide 装载块），
                // 这里不再做 128 路汇总。
                divide_count_sum <= 32'd0;
                divide_y_sum <= 32'd0;
                pre_div_sum[0] <= bin_sum_y[1];
                pre_div_sum[1] <= bin_sum_y[15];
                pre_div_sum[2] <= bin_sum_y[62];
                pre_div_count[0] <= bin_count_y[1];
                pre_div_count[1] <= bin_count_y[15];
                pre_div_count[2] <= bin_count_y[62];
                pre_div_valid[0] <= (bin_count_y[1] != 0);
                pre_div_valid[1] <= (bin_count_y[15] != 0);
                pre_div_valid[2] <= (bin_count_y[62] != 0);
                divide_active <= 1'b1;
                divide_load <= 1'b1;
                divide_bin_busy <= 1'b0;
                div_inflight <= 1'b0;
                divide_index <= 8'd0;
            end

            if (divide_active && divide_load && !divide_bin_busy && !div_inflight) begin
                divide_load <= 1'b0;
                divide_count_sum <= divide_count_sum + scan_count_y[divide_index];
                divide_y_sum <= divide_y_sum + scan_sum_y[divide_index];
                // 零计数/零求和错误在这里逐 bin 串行统计（每 bin 一拍），
                // 取代原来 finalize 里的 128 路汇总。
                if (scan_zero_hit) begin
                    if (scan_zero_cnt != 8'hff)
                        scan_zero_cnt <= scan_zero_cnt + 1'b1;
                    if (scan_zero_first == 8'hff)
                        scan_zero_first <= divide_index;
                end
                if (scan_nz_hit) begin
                    if (scan_nz_cnt != 8'hff)
                        scan_nz_cnt <= scan_nz_cnt + 1'b1;
                    if (scan_nz_first == 8'hff)
                        scan_nz_first <= divide_index;
                end
                if (scan_count_y[divide_index] != 0) begin
                    divide_numerator <= scan_sum_y[divide_index];
                    divide_quotient <= 32'd0;
                    divide_remainder <= 17'd0;
                    divide_divisor <= scan_count_y[divide_index];
                    divide_bit_index <= 6'd31;
                    divide_bin_busy <= 1'b1;
                    div_inflight <= 1'b1;
                end else begin
                    raw_average_y_mem[divide_index] <= 16'hffff;
                    frame_valid_mem[divide_index] <= 1'b0;
                    frame_y_mem[divide_index] <= 16'hffff;
                    div_inflight <= 1'b0;
                    divide_divisor <= 16'd0;
                    divide_quotient <= 32'd0;
                    divide_remainder <= 17'd0;
                    if (divide_index == SAMPLE_COUNT-1) begin
                        divide_active <= 1'b0;
                        done_bin_count_sum <= divide_count_sum;
                        done_bin_y_sum <= divide_y_sum;
                        // 这个 bin 的统计与装载在同一拍，把它的贡献补上
                        done_zero_count_sum_errors <=
                            (scan_zero_hit_lat && (scan_zero_cnt != 8'hff)) ?
                            (scan_zero_cnt + 8'd1) : scan_zero_cnt;
                        done_first_zero_count_sum_error <=
                            (scan_zero_hit_lat && (scan_zero_first == 8'hff)) ?
                            divide_index : scan_zero_first;
                        done_nonzero_count_zero_sum_errors <=
                            (scan_nz_hit_lat && (scan_nz_cnt != 8'hff)) ?
                            (scan_nz_cnt + 8'd1) : scan_nz_cnt;
                        done_first_nonzero_count_zero_sum_error <=
                            (scan_nz_hit_lat && (scan_nz_first == 8'hff)) ?
                            divide_index : scan_nz_first;
                        if ((OUTLIER_FILTER_ENABLE == 0) && (INVALID_FILL_ENABLE == 0)) begin
                            filter_active <= 1'b0;
                            frame_ready_pending <= 1'b1;
                        end else begin
                            filter_active <= 1'b1;
                            filter_index <= 8'd0;
                            filter_have_prev <= 1'b0;
                            filter_have_prev2 <= 1'b0;
                            filter_prev_y <= (ROI_Y_START + ROI_Y_END) / 2;
                            filter_prev2_y <= (ROI_Y_START + ROI_Y_END) / 2;
                        end
                    end else begin
                        divide_index <= divide_index + 1'b1;
                        divide_load <= 1'b1;
                    end
                end
            end

            // Keep the numerator fixed; accumulate one quotient bit per clock.
            if (divide_active && divide_bin_busy) begin
                divide_numerator <= {divide_numerator[30:0], 1'b0};
                divide_quotient <= divide_quotient_next;
                divide_remainder <= divide_remainder_next;
                if (divide_bit_index == 0) begin
                    divide_bin_busy <= 1'b0;
                    div_inflight <= 1'b0;
                    // 恢复除法器本身是精确的；只保留"余数必须小于除数"这个
                    // 便宜且可靠的保护。multiply-based identity 校验已删除：
                    // 它是视频域里 16x16 乘法 + 33bit 比较的长路径，板上既会误杀正确结果、又会放过错误结果（报告 §1.3 / §9.3）。
                    if (divide_remainder_next >= {1'b0, divide_divisor}) begin
                        // Do not allow a failed quotient/remainder check to
                        // feed filtering, interpolation, or the DAC path.
                        raw_average_y_mem[divide_index] <= 16'hffff;
                        frame_valid_mem[divide_index] <= 1'b0;
                        frame_y_mem[divide_index] <= 16'hffff;
                        if (division_error_count != 8'hff)
                            division_error_count <= division_error_count + 1'b1;
                        if (first_division_error == 8'hff) begin
                            first_division_error <= divide_index;
                            first_division_error_sum <= scan_sum_y[divide_index];
                            first_division_error_count_value <= divide_divisor;
                            first_division_error_quotient <= divide_quotient_next[15:0];
                            first_division_error_remainder <= divide_remainder_next;
                            first_division_error_bit <= divide_bit_index;
                            first_division_error_shift <= scan_sum_y[divide_index];
                            first_division_error_pre_rem <= divide_remainder;
                            first_division_error_pre_q <= divide_quotient;
                            first_division_error_trial <= divide_trial_remainder;
                            first_division_error_next_q <= divide_quotient_next;
                        end
                    end else begin
                        raw_average_y_mem[divide_index] <= divide_quotient_next[15:0];
                        // Reject impossible bin means when the frame-level
                        // range is itself sane. If min/max are corrupted or
                        // reversed, retain the independent ROI-only check.
                        if ((divide_quotient_next < ROI_Y_START) ||
                            (divide_quotient_next > ROI_Y_END) ||
                            ((capture_y_min <= capture_y_max) &&
                             ((divide_quotient_next < capture_y_min) ||
                              (divide_quotient_next > capture_y_max))) ||
                            ((EDGE_AVERAGE_REJECT_ENABLE != 0) &&
                             ((divide_quotient_next < (ROI_Y_START + EDGE_GUARD_PIXELS)) ||
                              (divide_quotient_next > (ROI_Y_END - EDGE_GUARD_PIXELS))))) begin
                            frame_valid_mem[divide_index] <= 1'b0;
                            frame_y_mem[divide_index] <= 16'hffff;
                        end else begin
                            frame_valid_mem[divide_index] <= 1'b1;
                            frame_y_mem[divide_index] <= divide_quotient_next[15:0];
                        end
                    end

                    if (divide_index == SAMPLE_COUNT-1) begin
                        divide_active <= 1'b0;
                        done_bin_count_sum <= divide_count_sum;
                        done_bin_y_sum <= divide_y_sum;
                        // 这个 bin 在 33 拍前就已计入串行统计，直接锁存
                        done_zero_count_sum_errors <= scan_zero_cnt;
                        done_first_zero_count_sum_error <= scan_zero_first;
                        done_nonzero_count_zero_sum_errors <= scan_nz_cnt;
                        done_first_nonzero_count_zero_sum_error <= scan_nz_first;
                        if ((OUTLIER_FILTER_ENABLE == 0) && (INVALID_FILL_ENABLE == 0)) begin
                            filter_active <= 1'b0;
                            frame_ready_pending <= 1'b1;
                        end else begin
                            filter_active <= 1'b1;
                            filter_index <= 8'd0;
                            filter_have_prev <= 1'b0;
                            filter_have_prev2 <= 1'b0;
                            filter_prev_y <= (ROI_Y_START + ROI_Y_END) / 2;
                            filter_prev2_y <= (ROI_Y_START + ROI_Y_END) / 2;
                        end
                    end else begin
                        divide_index <= divide_index + 1'b1;
                        divide_load <= 1'b1;
                    end
                end else begin
                    divide_bit_index <= divide_bit_index - 1'b1;
                end
            end

            // 异常跳点剔除：对 32 个区间的原始平均值逐点检查。
            // 当前点与前一个稳定点的差值超�?Y_JUMP_MAX 时，
            // 使用前一个稳定点替换，避免边界限幅值污染波形�?
            // Recover if the divider enters an idle state with no load request.
            // 必须排除"正在算"的情况（div_inflight）：否则只要 divide_bin_busy
            // 在运行中采到一拍低电平，这里就会置 divide_load，把正在进行的
            // 除法重新装载、商清零，最终得到 Q=0（报告 §10.4）。
            if (divide_active && !divide_load && !divide_bin_busy && !div_inflight)
                divide_load <= 1'b1;

            if (filter_active && 1'b0) begin
                if ((scan_count_y[filter_index] != 0) && frame_valid_mem[filter_index]) begin
                    filter_current_y = clamp_y(frame_y_mem[filter_index]);
                    filter_diff_y = filter_current_y - filter_prev_y;
                    if (filter_diff_y < 0)
                        filter_diff_y = -filter_diff_y;

                    if (!filter_have_prev) begin
                        frame_y_mem[filter_index] <= filter_current_y[15:0];
                        filter_prev_y <= filter_current_y[15:0];
                        filter_have_prev <= 1'b1;
                    end else if (filter_diff_y > Y_JUMP_MAX) begin
                        frame_y_mem[filter_index] <= filter_prev_y;
                        // 异常点替换后不更�?filter_prev_y�?
                    end else begin
                        frame_y_mem[filter_index] <= filter_current_y[15:0];
                        filter_prev_y <= filter_current_y[15:0];
                    end
                    frame_valid_mem[filter_index] <= 1'b1;
                end

                if (filter_index == SAMPLE_COUNT-1) begin
                    filter_active <= 1'b0;
                    if (INVALID_FILL_ENABLE != 0) begin
                        fill_active <= 1'b1;
                        fill_stage <= 2'd0;
                        fill_index <= 8'd0;
                        fill_scan_index <= 8'd0;
                        fill_have_value <= 1'b0;
                        fill_hold_y <= (ROI_Y_START + ROI_Y_END) / 2;
                        fill_prev_valid <= 1'b0;
                        fill_next_valid <= 1'b0;
                    end else begin
                        frame_ready_pending <= 1'b1;
                    end
                end else begin
                    filter_index <= filter_index + 1'b1;
                end
            end

            // 无效点填充：每个时钟处理一个横向区间�?
            // 为控制资源量，使用最近有效点保持策略�?
            //   1) 左端连续缺口使用本帧第一个有效点；
            //   2) 中间和右端缺口使用前一个有效点；
            //   3) 整帧无有效点时使�?ROI 中线�?
            // 该策略不使用乘法器或可变除法器，适合当前资源已经较紧的工程�?
            // 趋势异常点过滤：异常点置无效，由后续左右邻点插值恢复�?
            if (filter_active) begin
                if ((scan_count_y[filter_index] != 0) && frame_valid_mem[filter_index]) begin
                    filter_current_y = clamp_y(frame_y_mem[filter_index]);
                    if (OUTLIER_FILTER_ENABLE == 0) begin
                        // 基线模式：不改变原始均值，避免滤波器影响采样链路诊断�?
                        frame_y_mem[filter_index] <= filter_current_y[15:0];
                        frame_valid_mem[filter_index] <= 1'b1;
                        filter_prev2_y <= filter_prev_y;
                        filter_prev_y <= filter_current_y[15:0];
                        filter_have_prev <= 1'b1;
                        filter_have_prev2 <= 1'b1;
                    end else if (!filter_have_prev) begin
                        frame_y_mem[filter_index] <= filter_current_y[15:0];
                        frame_valid_mem[filter_index] <= 1'b1;
                        filter_prev_y <= filter_current_y[15:0];
                        filter_have_prev <= 1'b1;
                        filter_have_prev2 <= 1'b0;
                    end else if (!filter_have_prev2) begin
                        frame_y_mem[filter_index] <= filter_current_y[15:0];
                        frame_valid_mem[filter_index] <= 1'b1;
                        filter_prev2_y <= filter_prev_y;
                        filter_prev_y <= filter_current_y[15:0];
                        filter_have_prev2 <= 1'b1;
                    end else begin
                        // 先扩展为有符号整数再做差，避�?6位无符号坐标在下降沿回绕�?
                        filter_delta_y = $signed({16'b0, filter_prev_y}) -
                                         $signed({16'b0, filter_prev2_y});
                        filter_predict_y = $signed({16'b0, filter_prev_y}) +
                                           filter_delta_y;
                        filter_predict_diff_y = filter_current_y - filter_predict_y;
                        if (filter_predict_diff_y < 0)
                            filter_predict_diff_y = -filter_predict_diff_y;
                        if (filter_predict_diff_y > OUTLIER_THRESHOLD) begin
                            frame_y_mem[filter_index] <= 16'hffff;
                            frame_valid_mem[filter_index] <= 1'b0;
                        end else begin
                            frame_y_mem[filter_index] <= filter_current_y[15:0];
                            frame_valid_mem[filter_index] <= 1'b1;
                            filter_prev2_y <= filter_prev_y;
                            filter_prev_y <= filter_current_y[15:0];
                        end
                    end
                end
                if (filter_index == SAMPLE_COUNT-1) begin
                    filter_active <= 1'b0;
                    if (INVALID_FILL_ENABLE != 0) begin
                        fill_active <= 1'b1;
                        fill_stage <= 2'd0;
                        fill_index <= 8'd0;
                        fill_scan_index <= 8'd0;
                        fill_prev_valid <= 1'b0;
                        fill_next_valid <= 1'b0;
                    end else begin
                        frame_ready_pending <= 1'b1;
                    end
                end else begin
                    filter_index <= filter_index + 1'b1;
                end
            end

            if (fill_active && 1'b0) begin
                if (!fill_have_value) begin
                    // 先串行寻找本帧第一个原始有效点。
                    if ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) begin
                        fill_hold_y <= frame_y_mem[fill_scan_index];
                        fill_have_value <= 1'b1;
                        fill_index <= 8'd0;
                    end else if (fill_scan_index == SAMPLE_COUNT-1) begin
                        fill_hold_y <= (ROI_Y_START + ROI_Y_END) / 2;
                        fill_have_value <= 1'b1;
                        fill_index <= 8'd0;
                    end else begin
                        fill_scan_index <= fill_scan_index + 1'b1;
                    end
                end else begin
                    if (bin_count_y[fill_index] != 0) begin
                        // 原始有效点保持不变，并成为后续缺口的保持值�?
                        fill_hold_y <= clamp_y(frame_y_mem[fill_index]);
                        frame_valid_mem[fill_index] <= 1'b1;
                    end else begin
                        frame_y_mem[fill_index] <= clamp_y(fill_hold_y);
                        frame_valid_mem[fill_index] <= 1'b1;
                    end

                    if (fill_index == SAMPLE_COUNT-1) begin
                        fill_active <= 1'b0;
                        frame_ready_pending <= 1'b1;
                    end else begin
                        fill_index <= fill_index + 1'b1;
                    end
                end
            end

            // 新的无效点填充：左端用第一个有效点，内部取前后有效点平均，
            // 右端用最后一个有效点。只使用原始命中计数，避免重复使用填充值�?
            if (fill_active && 1'b0) begin
                fill_prev_found = 0;
                fill_next_found = 0;
                fill_prev_index = 0;
                fill_next_index = SAMPLE_COUNT - 1;
                fill_prev_y = (ROI_Y_START + ROI_Y_END) / 2;
                fill_next_y = (ROI_Y_START + ROI_Y_END) / 2;
                fill_interpolated_y = (ROI_Y_START + ROI_Y_END) / 2;
                fill_value_y = (ROI_Y_START + ROI_Y_END) / 2;

                if (bin_count_y[fill_index] != 0) begin
                    fill_value_y = clamp_y(frame_y_mem[fill_index]);
                end else begin
                    for (fill_scan = 0; fill_scan < SAMPLE_COUNT; fill_scan = fill_scan + 1) begin
                        if ((fill_scan < fill_index) && (bin_count_y[fill_scan] != 0)) begin
                            fill_prev_found = 1;
                            fill_prev_index = fill_scan;
                            fill_prev_y = clamp_y(frame_y_mem[fill_scan]);
                        end
                    end
                    for (fill_scan = SAMPLE_COUNT-1; fill_scan >= 0; fill_scan = fill_scan - 1) begin
                        if ((fill_scan > fill_index) && (bin_count_y[fill_scan] != 0)) begin
                            fill_next_found = 1;
                            fill_next_index = fill_scan;
                            fill_next_y = clamp_y(frame_y_mem[fill_scan]);
                        end
                    end

                    if ((LINEAR_INTERP_ENABLE != 0) &&
                        fill_prev_found && fill_next_found &&
                        (fill_next_index > fill_prev_index)) begin
                        // 按横坐标比例线性插值：
                        // y = y_left + (y_right-y_left)*(x-x_left)/(x_right-x_left)
                        fill_interpolated_y = fill_prev_y +
                            ((fill_next_y - fill_prev_y) *
                             (fill_index - fill_prev_index)) /
                            (fill_next_index - fill_prev_index);
                        fill_value_y = clamp_y(fill_interpolated_y[15:0]);
                    end else if ((LINEAR_INTERP_ENABLE == 0) &&
                                 fill_prev_found && fill_next_found) begin
                        // 低资源回退模式：仅用于确认 HDMI 时钟和显示链路
                        fill_value_y = clamp_y(((fill_prev_y + fill_next_y) >> 1));
                    end else if (fill_prev_found) begin
                        fill_value_y = fill_prev_y;
                    end else if (fill_next_found) begin
                        fill_value_y = fill_next_y;
                    end
                end

                frame_y_mem[fill_index] <= fill_value_y[15:0];
                frame_valid_mem[fill_index] <= 1'b1;
                if (fill_index == SAMPLE_COUNT-1) begin
                    fill_active <= 1'b0;
                frame_ready_pending <= 1'b1;
                end else begin
                    fill_index <= fill_index + 1'b1;
                end
            end

            // Multi-cycle fill pipeline: build left/right neighbour tables first,
            // then interpolate one sample per video clock. This avoids unrolling
            // 32 searches and a divider into the HDMI data path.
            if (fill_active) begin
                fill_step_done = 1'b0;   // 每个时钟默认不推进索引，由各状态置位
                if (fill_stage == 2'd0) begin
                    if ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) begin
                        fill_prev_valid <= 1'b1;
                        fill_prev_index_reg <= fill_scan_index;
                        fill_prev_y_reg <= clamp_y(frame_y_mem[fill_scan_index]);
                    end
                    fill_left_found_mem[fill_scan_index] <=
                        fill_prev_valid |
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]);
                    fill_left_index_mem[fill_scan_index] <=
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) ?
                        fill_scan_index : fill_prev_index_reg;
                    fill_left_y_mem[fill_scan_index] <=
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) ?
                        clamp_y(frame_y_mem[fill_scan_index]) : fill_prev_y_reg;
                    if (fill_scan_index == SAMPLE_COUNT-1) begin
                        fill_stage <= 2'd1;
                        fill_scan_index <= SAMPLE_COUNT-1;
                        fill_next_valid <= 1'b0;
                        fill_next_index_reg <= SAMPLE_COUNT-1;
                        fill_next_y_reg <= (ROI_Y_START + ROI_Y_END) / 2;
                    end else begin
                        fill_scan_index <= fill_scan_index + 1'b1;
                    end
                end else if (fill_stage == 2'd1) begin
                    if ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) begin
                        fill_next_valid <= 1'b1;
                        fill_next_index_reg <= fill_scan_index;
                        fill_next_y_reg <= clamp_y(frame_y_mem[fill_scan_index]);
                    end
                    fill_right_found_mem[fill_scan_index] <=
                        fill_next_valid |
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]);
                    fill_right_index_mem[fill_scan_index] <=
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) ?
                        fill_scan_index : fill_next_index_reg;
                    fill_right_y_mem[fill_scan_index] <=
                        ((scan_count_y[fill_scan_index] != 0) && frame_valid_mem[fill_scan_index]) ?
                        clamp_y(frame_y_mem[fill_scan_index]) : fill_next_y_reg;
                    if (fill_scan_index == 0) begin
                        fill_stage <= 2'd2;
                        fill_index <= 8'd0;
                    end else begin
                        fill_scan_index <= fill_scan_index - 1'b1;
                    end
                end else if (fill_stage == 2'd2) begin
                    // ---- 第 2 拍：只把 7 个 128:1 mux 的输出打一拍 ----
                    cap_y     <= frame_y_mem[fill_index];
                    cap_cnt   <= scan_count_y[fill_index];
                    cap_valid <= frame_valid_mem[fill_index];
                    cap_lf    <= fill_left_found_mem[fill_index];
                    cap_rf    <= fill_right_found_mem[fill_index];
                    cap_ly    <= fill_left_y_mem[fill_index];
                    cap_ry    <= fill_right_y_mem[fill_index];
                    cap_li    <= fill_left_index_mem[fill_index];
                    cap_ri    <= fill_right_index_mem[fill_index];
                    fill_stage <= 3'd3;
                end else if (fill_stage == 2'd3) begin
                    // ---- 第 3 拍：判定 + 乘法（操作数都已寄存）----
                    fill_step_done = 1'b0;
                    if ((cap_cnt != 0) && cap_valid) begin
                        // 实测点：直接写回
                        frame_y_mem[fill_index] <= clamp_y(cap_y);
                        frame_valid_mem[fill_index] <= 1'b1;
                        fill_step_done = 1'b1;
                    end else if ((LINEAR_INTERP_ENABLE != 0) &&
                                 cap_lf && cap_rf && (cap_ri > cap_li)) begin
                        // 内部缺口：锁存 |delta|*offset / span，交给第 4 段多拍除法
                        dv_neg  <= (cap_ry < cap_ly);
                        dv_base <= cap_ly;
                        dv_den  <= {8'd0, (cap_ri - cap_li)};
                        dv_num  <= (cap_ry < cap_ly) ?
                                   ((cap_ly - cap_ry) * (fill_index - cap_li)) :
                                   ((cap_ry - cap_ly) * (fill_index - cap_li));
                        dv_quot <= 16'd0;
                        dv_rem  <= 17'd0;
                        dv_bit  <= 4'd15;
                        fill_stage <= 3'd4;
                    end else if ((LINEAR_INTERP_ENABLE == 0) && cap_lf && cap_rf) begin
                        frame_y_mem[fill_index] <= clamp_y((cap_ly + cap_ry) >> 1);
                        frame_valid_mem[fill_index] <= 1'b1;
                        fill_step_done = 1'b1;
                    end else if (cap_lf) begin
                        frame_y_mem[fill_index] <= cap_ly;
                        frame_valid_mem[fill_index] <= 1'b1;
                        fill_step_done = 1'b1;
                    end else if (cap_rf) begin
                        frame_y_mem[fill_index] <= cap_ry;
                        frame_valid_mem[fill_index] <= 1'b1;
                        fill_step_done = 1'b1;
                    end else begin
                        frame_y_mem[fill_index] <= 16'hffff;
                        frame_valid_mem[fill_index] <= 1'b0;
                        fill_step_done = 1'b1;
                    end
                end else begin
                    // ---- 第 4 段：16 拍恢复除法，每拍只做一次比较/减法 ----
                    fill_step_done = 1'b0;
                    if ({dv_rem[15:0], dv_num[15]} >= {1'b0, dv_den}) begin
                        dv_rem <= {dv_rem[15:0], dv_num[15]} - {1'b0, dv_den};
                        dv_quot_next = {dv_quot[14:0], 1'b1};
                    end else begin
                        dv_rem <= {dv_rem[15:0], dv_num[15]};
                        dv_quot_next = {dv_quot[14:0], 1'b0};
                    end
                    dv_num <= {dv_num[14:0], 1'b0};
                    if (dv_bit == 4'd0) begin
                        fill_value_y = dv_neg ? (dv_base - dv_quot_next)
                                              : (dv_base + dv_quot_next);
                        frame_y_mem[fill_index] <= clamp_y(fill_value_y);
                        frame_valid_mem[fill_index] <= 1'b1;
                        fill_step_done = 1'b1;
                    end else begin
                        dv_quot <= dv_quot_next;
                        dv_bit  <= dv_bit - 1'b1;
                    end
                end

                // 统一的索引推进：第 3 段除法期间不动
                if (fill_step_done) begin
                    if (fill_index == SAMPLE_COUNT-1) begin
                        fill_active <= 1'b0;
                        frame_ready_pending <= 1'b1;
                    end else begin
                        fill_index <= fill_index + 1'b1;
                        fill_stage <= 2'd2;
                    end
                end
            end
        end
    end

    // ------------------------------------------------------------------
    // System clock domain: key, frame event synchronization and UART.
    // ------------------------------------------------------------------
    reg frame_toggle_meta; /* fehdl keep="true" */
    reg frame_toggle_sync; /* fehdl keep="true" */
    reg frame_toggle_seen;
    reg key_meta; /* fehdl keep="true" */
    reg key_sync; /* fehdl keep="true" */
    reg key_armed;
    reg [DB_WIDTH-1:0] key_count;
    reg capture_pending;
    reg timeout_reported;
    reg [WAIT_WIDTH-1:0] capture_wait_count;
    reg report_active;
    // ---- R-2 system-domain state
    reg        tq_ack_meta, tq_ack_sync, tq_ack_seen; /* fehdl keep="true" */   // acknowledge toggle from the video domain
    reg [1:0]  tmo_state;                                // 0 idle, 1 waiting for the status acknowledge
    reg [15:0] tmo_cnt;
    reg [7:0]  req_drop;                                 // key presses ignored by the interlock
    reg [7:0]  stale_drop;                               // frame events discarded (stale / unrequested)
    reg [7:0]  report_req_drop, report_stale_drop;
    reg [31:0] report_hs_cnt;
    reg [31:0] fm_gate_ctr;                              // sys: gate generator counter
    reg        fm_done_meta, fm_done_sync, fm_done_seen; /* fehdl keep="true" */  // sys: 2-FF for the single-bit done toggle
    reg [31:0] fm_report;                                // sys: copy of fm_result taken on the done toggle
    reg        report_status_ok;
    // Copy one completed bin per system clock before starting UART.  The
    // video-domain arrays remain frozen, so this avoids a torn CDC snapshot.
    reg report_snapshot_active;
    reg report_snapshot_wait;
    reg [7:0] report_snapshot_bin_index;
    reg [15:0] report_snapshot_count_hold;
    reg [31:0] report_snapshot_sum_hold;
    reg [15:0] report_snapshot_raw_y_hold;
    reg [15:0] report_snapshot_final_y_hold;
    reg report_snapshot_final_valid_hold;
    reg [7:0] dac_valid_points;
    reg [13:0] dac_hold_code;
    // 帧被拒次数/最后一帧是否被拒：给 ChipWatcher 看的诊断，不参与数据通路。
    reg [7:0] dac_reject_count;
    reg       dac_frame_ok;
    wire [13:0] dac_point_code = pixel_y_to_dac_code(report_snapshot_final_y_hold);
    wire dac_snapshot_point_valid = report_snapshot_final_valid_hold &&
        (report_snapshot_final_y_hold >= ROI_Y_START) &&
        (report_snapshot_final_y_hold <= ROI_Y_END);
    reg [REPORT_POS_WIDTH-1:0] report_pos;
    reg [15:0] baud_count;
    reg [3:0] tx_bit_count;
    reg [9:0] tx_shift;
    reg tx_active;
    reg key_ack_active;
    reg key_ack_pending;
    reg tx_is_ack;                      // C-06: the byte in the tap slot belongs to the key acknowledge
    reg [2:0] key_ack_pos;
    reg [7:0] tx_byte;
    reg [7:0] key_ack_byte;
    // Stable system-clock-domain copy of the completed video frame.  The
    // UART must not serialize live video-domain arrays one field at a time.
    reg [15:0] report_count_mem [0:SAMPLE_COUNT-1];
    reg [31:0] report_sum_mem [0:SAMPLE_COUNT-1];
    reg [7:0] report_zero_count_sum_errors;
    reg [7:0] report_first_zero_count_sum_error;
    reg [7:0] report_nonzero_count_zero_sum_errors;
    reg [7:0] report_first_nonzero_count_zero_sum_error;
    reg [7:0] report_division_errors;
    reg [7:0] report_first_division_error;
    reg [31:0] report_first_division_error_sum;
    reg [15:0] report_first_division_error_count_value;
    reg [15:0] report_first_division_error_quotient;
    reg [16:0] report_first_division_error_remainder;
    reg [5:0]  report_first_division_error_bit;
    reg [31:0] report_first_division_error_shift;
    reg [16:0] report_first_division_error_pre_rem;
    reg [31:0] report_first_division_error_pre_q;
    reg [16:0] report_first_division_error_trial;
    reg [31:0] report_first_division_error_next_q;
    reg [15:0] report_raw_y_mem [0:SAMPLE_COUNT-1];
    reg [15:0] report_final_y_mem [0:SAMPLE_COUNT-1];
    reg        report_raw_valid_mem [0:SAMPLE_COUNT-1];
    reg        report_final_valid_mem [0:SAMPLE_COUNT-1];
    reg [15:0] report_first_x;
    reg [15:0] report_last_x;
    reg        report_x_valid;
    reg [31:0] report_raw_valid_word;
    reg [31:0] report_final_valid_word;
    reg        report_timeout;
    reg        report_div_active;
    reg        report_div_load;
    reg [7:0]  report_div_index;
    reg [15:0] report_divisor;
    reg [15:0] report_div_quotient;
    reg [31:0] report_div_remainder;
    reg [31:0] report_div_sum;
    reg [31:0] report_accept_count;
    reg [31:0] report_capture_count;
    reg [15:0] report_y_min;
    reg [15:0] report_y_max;
    reg [31:0] report_input_y_sum;
    reg [31:0] report_bin_count_sum;
    reg [31:0] report_bin_y_sum;
    reg [31:0] report_p7f_sum;
    reg [15:0] report_p7f_count;
    reg [15:0] report_p7f_raw_y;
    reg [31:0] report_pre_div_sum [0:2];
    reg [15:0] report_pre_div_count [0:2];
    reg        report_pre_div_valid [0:2];
    reg [31:0] report_dbg_sum [0:2];
    reg [15:0] report_dbg_count [0:2];
    reg [15:0] report_dbg_avg [0:2];
    reg        report_dbg_valid [0:2];
    reg [8:0]  report_post_state;
    reg        report_div_busy;
    reg [5:0]  report_div_bit;
    reg [2:0]  report_fill_stage;
    reg        report_frame_toggle;
    wire [8:0] post_state_video = {frame_ready_pending, fill_active,
                                   filter_active, divide_bin_busy, divide_load,
                                   divide_active, frame_finalize_pending,
                                   frame_end_pending, capture_active};
    integer report_snapshot_index;
    integer point_index;
    integer point_offset;
    integer point_field;
    integer report_point_y;
    integer report_raw_point_y;
    integer debug_offset;
    integer debug_point_index;
    integer debug_point_field;
    reg report_final_point_valid;
    reg report_raw_point_valid;

    wire frame_event = (frame_toggle_sync != frame_toggle_seen);
    wire report_start = frame_event && capture_pending && !report_active;
    // R-2 event / timeout control.  done_valid/done_req are video-domain bits that were written
    // before frame_toggle flipped and are only rewritten by a later frame (see CDC proof).
    wire evt_ready  = frame_event && !report_active && !report_snapshot_active;
    wire evt_valid  = capture_pending && done_valid && (done_req == req_gray_sys);
    wire tq_ack_new = (tq_ack_sync != tq_ack_seen);
    wire tmo_start  = capture_pending && !timeout_reported && !report_active &&
                      (tmo_state == 2'd0) && (capture_wait_count >= FRAME_WAIT_TIMEOUT_CYCLES);
    wire tmo_go     = (tmo_state == 2'd1) && capture_pending && !report_active &&
                      (tq_ack_new || (tmo_cnt >= STATUS_ACK_LIMIT));
    wire req_busy_now = (evt_ready && evt_valid) || tmo_start || tmo_go;
    function [7:0] hex_ascii;
        input [3:0] value;
        begin
            hex_ascii = (value < 10) ? (8'h30 + value) : (8'h41 + value - 10);
        end
    endfunction

    always @* begin
        case (key_ack_pos)
            3'd0: key_ack_byte = "K";
            3'd1: key_ack_byte = "E";
            3'd2: key_ack_byte = "Y";
            3'd3: key_ack_byte = 8'h0d;
            3'd4: key_ack_byte = 8'h0a;
            default: key_ack_byte = 8'h20;
        endcase
    end

    // Report format:
    // FRAME_START\r\n
    // FIRST_X=xxxx\r\n
    // LAST_X=xxxx\r\n
    // RAW_VALID=xxxxxxxx\r\n
    // C14=xxxx\r\n
    // C24=xxxx\r\n
    // FINAL_VALID=xxxxxxxx\r\n
    // P7F_S=ssssssss / P7F_C=cccc / P7F_R=rrrr are same-frame raw diagnostics.
    // P00=yyyy,C=cccc,S=ssssssss,R=rrrr\r\n ... P7F=...\r\n
    // FRAME_END\r\n
    always @* begin
        tx_byte = 8'h20;
        point_index = 0;
        point_offset = 0;
        point_field = 0;
        debug_offset = 0;
        debug_point_index = 0;
        debug_point_field = 0;
        report_point_y = (ROI_Y_START + ROI_Y_END) / 2;
        report_final_point_valid = 1'b0;
        report_raw_point_y = 16'hffff;
        report_raw_point_valid = 1'b0;

        if (report_pos < 13) begin
            case (report_pos)
                0: tx_byte = "F";  1: tx_byte = "R";  2: tx_byte = "A";
                3: tx_byte = "M";  4: tx_byte = "E";  5: tx_byte = "_";
                6: tx_byte = "S";  7: tx_byte = "T";  8: tx_byte = "A";
                9: tx_byte = "R"; 10: tx_byte = "T"; 11: tx_byte = 8'h0d;
                12: tx_byte = 8'h0a;
                default: tx_byte = 8'h20;
            endcase
        end else if (report_pos < 21) begin
            // R-2 report format marker: "FMT=02" (baseline format has no FMT line = version 01)
            case (report_pos - 13)
                0: tx_byte = "F"; 1: tx_byte = "M"; 2: tx_byte = "T"; 3: tx_byte = "=";
                4: tx_byte = "0"; 5: tx_byte = "2";
                6: tx_byte = 8'h0d; 7: tx_byte = 8'h0a;
                default: tx_byte = 8'h20;
            endcase
        end else if (report_pos < DEBUG_OFFSET) begin
            if (report_pos < 35) begin
                case (report_pos - 8)
                    13: tx_byte = "F"; 14: tx_byte = "I"; 15: tx_byte = "R";
                    16: tx_byte = "S"; 17: tx_byte = "T"; 18: tx_byte = "_";
                    19: tx_byte = "X"; 20: tx_byte = "=";
                    21: tx_byte = report_x_valid ? hex_ascii(report_first_x[15:12]) : "F";
                    22: tx_byte = report_x_valid ? hex_ascii(report_first_x[11:8])  : "F";
                    23: tx_byte = report_x_valid ? hex_ascii(report_first_x[7:4])   : "F";
                    24: tx_byte = report_x_valid ? hex_ascii(report_first_x[3:0])   : "F";
                    25: tx_byte = 8'h0d; 26: tx_byte = 8'h0a;
                    default: tx_byte = 8'h20;
                endcase
            end else begin
                case (report_pos - 8)
                    27: tx_byte = "L"; 28: tx_byte = "A"; 29: tx_byte = "S";
                    30: tx_byte = "T"; 31: tx_byte = "_"; 32: tx_byte = "X";
                    33: tx_byte = "=";
                    34: tx_byte = report_x_valid ? hex_ascii(report_last_x[15:12]) : "F";
                    35: tx_byte = report_x_valid ? hex_ascii(report_last_x[11:8])  : "F";
                    36: tx_byte = report_x_valid ? hex_ascii(report_last_x[7:4])   : "F";
                    37: tx_byte = report_x_valid ? hex_ascii(report_last_x[3:0])   : "F";
                    38: tx_byte = 8'h0d; 39: tx_byte = 8'h0a;
                    default: tx_byte = 8'h20;
                endcase
            end
        end else if (report_pos < POINTS_OFFSET) begin
            // 调试字段总长�?2字节�?0 + 10 + 10 + 22�?
            case (report_pos - DEBUG_OFFSET)
                // RAW_VALID=xxxxxxxx\r\n
                0: tx_byte = "R"; 1: tx_byte = "A"; 2: tx_byte = "W";
                3: tx_byte = "_"; 4: tx_byte = "V"; 5: tx_byte = "A";
                6: tx_byte = "L"; 7: tx_byte = "I"; 8: tx_byte = "D";
                9: tx_byte = "=";
                10: tx_byte = hex_ascii(report_raw_valid_word[31:28]);
                11: tx_byte = hex_ascii(report_raw_valid_word[27:24]);
                12: tx_byte = hex_ascii(report_raw_valid_word[23:20]);
                13: tx_byte = hex_ascii(report_raw_valid_word[19:16]);
                14: tx_byte = hex_ascii(report_raw_valid_word[15:12]);
                15: tx_byte = hex_ascii(report_raw_valid_word[11:8]);
                16: tx_byte = hex_ascii(report_raw_valid_word[7:4]);
                17: tx_byte = hex_ascii(report_raw_valid_word[3:0]);
                18: tx_byte = 8'h0d; 19: tx_byte = 8'h0a;

                // C14=xxxx\r\n，C14对应UART中的P0E（数组下�?4）�?
                20: tx_byte = "C"; 21: tx_byte = "1"; 22: tx_byte = "4";
                23: tx_byte = "=";
                24: tx_byte = hex_ascii(report_count_mem[14][15:12]);
                25: tx_byte = hex_ascii(report_count_mem[14][11:8]);
                26: tx_byte = hex_ascii(report_count_mem[14][7:4]);
                27: tx_byte = hex_ascii(report_count_mem[14][3:0]);
                28: tx_byte = 8'h0d; 29: tx_byte = 8'h0a;

                // C24=xxxx\r\n，C24对应UART中的P18（数组下�?4）�?
                30: tx_byte = "C"; 31: tx_byte = "2"; 32: tx_byte = "4";
                33: tx_byte = "=";
                34: tx_byte = hex_ascii(report_count_mem[24][15:12]);
                35: tx_byte = hex_ascii(report_count_mem[24][11:8]);
                36: tx_byte = hex_ascii(report_count_mem[24][7:4]);
                37: tx_byte = hex_ascii(report_count_mem[24][3:0]);
                38: tx_byte = 8'h0d; 39: tx_byte = 8'h0a;

                // FINAL_VALID=xxxxxxxx\r\n
                40: tx_byte = "F"; 41: tx_byte = "I"; 42: tx_byte = "N";
                43: tx_byte = "A"; 44: tx_byte = "L"; 45: tx_byte = "_";
                46: tx_byte = "V"; 47: tx_byte = "A"; 48: tx_byte = "L";
                49: tx_byte = "I"; 50: tx_byte = "D"; 51: tx_byte = "=";
                52: tx_byte = hex_ascii(report_final_valid_word[31:28]);
                53: tx_byte = hex_ascii(report_final_valid_word[27:24]);
                54: tx_byte = hex_ascii(report_final_valid_word[23:20]);
                55: tx_byte = hex_ascii(report_final_valid_word[19:16]);
                56: tx_byte = hex_ascii(report_final_valid_word[15:12]);
                57: tx_byte = hex_ascii(report_final_valid_word[11:8]);
                58: tx_byte = hex_ascii(report_final_valid_word[7:4]);
                59: tx_byte = hex_ascii(report_final_valid_word[3:0]);
                60: tx_byte = 8'h0d; 61: tx_byte = 8'h0a;
                62: tx_byte = "T"; 63: tx_byte = "I";
                64: tx_byte = "M"; 65: tx_byte = "E";
                66: tx_byte = "O"; 67: tx_byte = "U";
                68: tx_byte = "T"; 69: tx_byte = "=";
                70: tx_byte = report_timeout ? "1" : "0";
                71: tx_byte = 8'h0d; 72: tx_byte = 8'h0a;
                // Divider progress snapshot. These values are captured from
                // the video-clock domain through two-stage synchronizers.
                73: tx_byte = "D"; 74: tx_byte = "I"; 75: tx_byte = "V";
                76: tx_byte = "_"; 77: tx_byte = "A"; 78: tx_byte = "C";
                79: tx_byte = "T"; 80: tx_byte = "I"; 81: tx_byte = "V";
                82: tx_byte = "E"; 83: tx_byte = "=";
                84: tx_byte = report_div_active ? "1" : "0";
                85: tx_byte = 8'h0d; 86: tx_byte = 8'h0a;
                87: tx_byte = "D"; 88: tx_byte = "I"; 89: tx_byte = "V";
                90: tx_byte = "_"; 91: tx_byte = "I"; 92: tx_byte = "D";
                93: tx_byte = "X"; 94: tx_byte = "=";
                95: tx_byte = hex_ascii(report_div_index[7:4]);
                96: tx_byte = hex_ascii(report_div_index[3:0]);
                97: tx_byte = 8'h0d; 98: tx_byte = 8'h0a;
                99: tx_byte = "D"; 100: tx_byte = "I"; 101: tx_byte = "V";
                102: tx_byte = "_"; 103: tx_byte = "L"; 104: tx_byte = "O";
                105: tx_byte = "A"; 106: tx_byte = "D"; 107: tx_byte = "=";
                108: tx_byte = report_div_load ? "1" : "0";
                109: tx_byte = 8'h0d; 110: tx_byte = 8'h0a;
                111: tx_byte = "D"; 112: tx_byte = "I"; 113: tx_byte = "V";
                114: tx_byte = "_"; 115: tx_byte = "D"; 116: tx_byte = "E";
                117: tx_byte = "N"; 118: tx_byte = "=";
                119: tx_byte = hex_ascii(report_divisor[15:12]);
                120: tx_byte = hex_ascii(report_divisor[11:8]);
                121: tx_byte = hex_ascii(report_divisor[7:4]);
                122: tx_byte = hex_ascii(report_divisor[3:0]);
                123: tx_byte = 8'h0d; 124: tx_byte = 8'h0a;
                125: tx_byte = "D"; 126: tx_byte = "I"; 127: tx_byte = "V";
                128: tx_byte = "_"; 129: tx_byte = "Q"; 130: tx_byte = "=";
                131: tx_byte = hex_ascii(report_div_quotient[15:12]);
                132: tx_byte = hex_ascii(report_div_quotient[11:8]);
                133: tx_byte = hex_ascii(report_div_quotient[7:4]);
                134: tx_byte = hex_ascii(report_div_quotient[3:0]);
                135: tx_byte = 8'h0d; 136: tx_byte = 8'h0a;
                137: tx_byte = "D"; 138: tx_byte = "I"; 139: tx_byte = "V";
                140: tx_byte = "_"; 141: tx_byte = "R"; 142: tx_byte = "E";
                143: tx_byte = "M"; 144: tx_byte = "=";
                145: tx_byte = hex_ascii(report_div_remainder[31:28]);
                146: tx_byte = hex_ascii(report_div_remainder[27:24]);
                147: tx_byte = hex_ascii(report_div_remainder[23:20]);
                148: tx_byte = hex_ascii(report_div_remainder[19:16]);
                149: tx_byte = hex_ascii(report_div_remainder[15:12]);
                150: tx_byte = hex_ascii(report_div_remainder[11:8]);
                151: tx_byte = hex_ascii(report_div_remainder[7:4]);
                152: tx_byte = hex_ascii(report_div_remainder[3:0]);
                153: tx_byte = 8'h0d; 154: tx_byte = 8'h0a;
                155: tx_byte = "D"; 156: tx_byte = "I"; 157: tx_byte = "V";
                158: tx_byte = "_"; 159: tx_byte = "S"; 160: tx_byte = "U";
                161: tx_byte = "M"; 162: tx_byte = "=";
                163: tx_byte = hex_ascii(report_div_sum[31:28]);
                164: tx_byte = hex_ascii(report_div_sum[27:24]);
                165: tx_byte = hex_ascii(report_div_sum[23:20]);
                166: tx_byte = hex_ascii(report_div_sum[19:16]);
                167: tx_byte = hex_ascii(report_div_sum[15:12]);
                168: tx_byte = hex_ascii(report_div_sum[11:8]);
                169: tx_byte = hex_ascii(report_div_sum[7:4]);
                170: tx_byte = hex_ascii(report_div_sum[3:0]);
                171: tx_byte = 8'h0d; 172: tx_byte = 8'h0a;
                default: begin
                    debug_offset = report_pos - DEBUG_OFFSET;
                    if ((debug_offset >= 173) && (debug_offset < 192)) begin
                        case (debug_offset)
                            173: tx_byte = "A"; 174: tx_byte = "C";
                            175: tx_byte = "C"; 176: tx_byte = "_";
                            177: tx_byte = "H"; 178: tx_byte = "I";
                            179: tx_byte = "T"; 180: tx_byte = "S";
                            181: tx_byte = "=";
                            182: tx_byte = hex_ascii(report_accept_count[31:28]);
                            183: tx_byte = hex_ascii(report_accept_count[27:24]);
                            184: tx_byte = hex_ascii(report_accept_count[23:20]);
                            185: tx_byte = hex_ascii(report_accept_count[19:16]);
                            186: tx_byte = hex_ascii(report_accept_count[15:12]);
                            187: tx_byte = hex_ascii(report_accept_count[11:8]);
                            188: tx_byte = hex_ascii(report_accept_count[7:4]);
                            189: tx_byte = hex_ascii(report_accept_count[3:0]);
                            190: tx_byte = 8'h0d; 191: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 192) && (debug_offset < 208)) begin
                        case (debug_offset - 192)
                            0: tx_byte = "A"; 1: tx_byte = "C";
                            2: tx_byte = "C"; 3: tx_byte = "_";
                            4: tx_byte = "Y"; 5: tx_byte = "_";
                            6: tx_byte = "M"; 7: tx_byte = "I";
                            8: tx_byte = "N"; 9: tx_byte = "=";
                            10: tx_byte = hex_ascii(report_y_min[15:12]);
                            11: tx_byte = hex_ascii(report_y_min[11:8]);
                            12: tx_byte = hex_ascii(report_y_min[7:4]);
                            13: tx_byte = hex_ascii(report_y_min[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 208) && (debug_offset < 224)) begin
                        case (debug_offset - 208)
                            0: tx_byte = "A"; 1: tx_byte = "C";
                            2: tx_byte = "C"; 3: tx_byte = "_";
                            4: tx_byte = "Y"; 5: tx_byte = "_";
                            6: tx_byte = "M"; 7: tx_byte = "A";
                            8: tx_byte = "X"; 9: tx_byte = "=";
                            10: tx_byte = hex_ascii(report_y_max[15:12]);
                            11: tx_byte = hex_ascii(report_y_max[11:8]);
                            12: tx_byte = hex_ascii(report_y_max[7:4]);
                            13: tx_byte = hex_ascii(report_y_max[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 224) && (debug_offset < 323)) begin
                        debug_point_index = (debug_offset - 224) / 33;
                        debug_point_field = (debug_offset - 224) % 33;
                        case (debug_point_field)
                            0: tx_byte = "B";
                            1: tx_byte = (debug_point_index == 0) ? "0" :
                                         (debug_point_index == 1) ? "1" : "6";
                            2: tx_byte = (debug_point_index == 0) ? "1" :
                                         (debug_point_index == 1) ? "5" : "2";
                            3: tx_byte = "=";
                            4: tx_byte = "V";
                            5: tx_byte = report_dbg_valid[debug_point_index] ? "1" : "0";
                            6: tx_byte = ","; 7: tx_byte = "C"; 8: tx_byte = "=";
                            9: tx_byte = hex_ascii(report_dbg_count[debug_point_index][15:12]);
                            10: tx_byte = hex_ascii(report_dbg_count[debug_point_index][11:8]);
                            11: tx_byte = hex_ascii(report_dbg_count[debug_point_index][7:4]);
                            12: tx_byte = hex_ascii(report_dbg_count[debug_point_index][3:0]);
                            13: tx_byte = ","; 14: tx_byte = "S"; 15: tx_byte = "=";
                            16: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][31:28]);
                            17: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][27:24]);
                            18: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][23:20]);
                            19: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][19:16]);
                            20: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][15:12]);
                            21: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][11:8]);
                            22: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][7:4]);
                            23: tx_byte = hex_ascii(report_dbg_sum[debug_point_index][3:0]);
                            24: tx_byte = ","; 25: tx_byte = "A"; 26: tx_byte = "=";
                            27: tx_byte = hex_ascii(report_dbg_avg[debug_point_index][15:12]);
                            28: tx_byte = hex_ascii(report_dbg_avg[debug_point_index][11:8]);
                            29: tx_byte = hex_ascii(report_dbg_avg[debug_point_index][7:4]);
                            30: tx_byte = hex_ascii(report_dbg_avg[debug_point_index][3:0]);
                            31: tx_byte = 8'h0d; 32: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 323) && (debug_offset < 343)) begin
                        case (debug_offset - 323)
                            0: tx_byte = "B"; 1: tx_byte = "I"; 2: tx_byte = "N";
                            3: tx_byte = "_"; 4: tx_byte = "C"; 5: tx_byte = "_";
                            6: tx_byte = "S"; 7: tx_byte = "U"; 8: tx_byte = "M";
                            9: tx_byte = "=";
                            10: tx_byte = hex_ascii(report_bin_count_sum[31:28]);
                            11: tx_byte = hex_ascii(report_bin_count_sum[27:24]);
                            12: tx_byte = hex_ascii(report_bin_count_sum[23:20]);
                            13: tx_byte = hex_ascii(report_bin_count_sum[19:16]);
                            14: tx_byte = hex_ascii(report_bin_count_sum[15:12]);
                            15: tx_byte = hex_ascii(report_bin_count_sum[11:8]);
                            16: tx_byte = hex_ascii(report_bin_count_sum[7:4]);
                            17: tx_byte = hex_ascii(report_bin_count_sum[3:0]);
                            18: tx_byte = 8'h0d; 19: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 343) && (debug_offset < 427)) begin
                        debug_point_index = (debug_offset - 343) / 28;
                        debug_point_field = (debug_offset - 343) % 28;
                        case (debug_point_field)
                            0: tx_byte = "P"; 1: tx_byte = "R"; 2: tx_byte = "E";
                            3: tx_byte = (debug_point_index == 0) ? "0" :
                                         (debug_point_index == 1) ? "1" : "6";
                            4: tx_byte = (debug_point_index == 0) ? "1" :
                                         (debug_point_index == 1) ? "5" : "2";
                            5: tx_byte = "=";
                            6: tx_byte = "V";
                            7: tx_byte = report_pre_div_valid[debug_point_index] ? "1" : "0";
                            8: tx_byte = ","; 9: tx_byte = "C"; 10: tx_byte = "=";
                            11: tx_byte = hex_ascii(report_pre_div_count[debug_point_index][15:12]);
                            12: tx_byte = hex_ascii(report_pre_div_count[debug_point_index][11:8]);
                            13: tx_byte = hex_ascii(report_pre_div_count[debug_point_index][7:4]);
                            14: tx_byte = hex_ascii(report_pre_div_count[debug_point_index][3:0]);
                            15: tx_byte = ","; 16: tx_byte = "S"; 17: tx_byte = "=";
                            18: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][31:28]);
                            19: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][27:24]);
                            20: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][23:20]);
                            21: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][19:16]);
                            22: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][15:12]);
                            23: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][11:8]);
                            24: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][7:4]);
                            25: tx_byte = hex_ascii(report_pre_div_sum[debug_point_index][3:0]);
                            26: tx_byte = 8'h0d; 27: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 427) && (debug_offset < 449)) begin
                        case (debug_offset - 427)
                            0: tx_byte = "I"; 1: tx_byte = "N"; 2: tx_byte = "P";
                            3: tx_byte = "U"; 4: tx_byte = "T"; 5: tx_byte = "_";
                            6: tx_byte = "Y"; 7: tx_byte = "_"; 8: tx_byte = "S";
                            9: tx_byte = "U"; 10: tx_byte = "M"; 11: tx_byte = "=";
                            12: tx_byte = hex_ascii(report_input_y_sum[31:28]);
                            13: tx_byte = hex_ascii(report_input_y_sum[27:24]);
                            14: tx_byte = hex_ascii(report_input_y_sum[23:20]);
                            15: tx_byte = hex_ascii(report_input_y_sum[19:16]);
                            16: tx_byte = hex_ascii(report_input_y_sum[15:12]);
                            17: tx_byte = hex_ascii(report_input_y_sum[11:8]);
                            18: tx_byte = hex_ascii(report_input_y_sum[7:4]);
                            19: tx_byte = hex_ascii(report_input_y_sum[3:0]);
                            20: tx_byte = 8'h0d; 21: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 449) && (debug_offset < 469)) begin
                        case (debug_offset - 449)
                            0: tx_byte = "B"; 1: tx_byte = "I"; 2: tx_byte = "N";
                            3: tx_byte = "_"; 4: tx_byte = "Y"; 5: tx_byte = "_";
                            6: tx_byte = "S"; 7: tx_byte = "U"; 8: tx_byte = "M";
                            9: tx_byte = "=";
                            10: tx_byte = hex_ascii(report_bin_y_sum[31:28]);
                            11: tx_byte = hex_ascii(report_bin_y_sum[27:24]);
                            12: tx_byte = hex_ascii(report_bin_y_sum[23:20]);
                            13: tx_byte = hex_ascii(report_bin_y_sum[19:16]);
                            14: tx_byte = hex_ascii(report_bin_y_sum[15:12]);
                            15: tx_byte = hex_ascii(report_bin_y_sum[11:8]);
                            16: tx_byte = hex_ascii(report_bin_y_sum[7:4]);
                            17: tx_byte = hex_ascii(report_bin_y_sum[3:0]);
                            18: tx_byte = 8'h0d; 19: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 469) && (debug_offset < 539)) begin
                        case (debug_offset - 469)
                            0: tx_byte = 8'h50; 1: tx_byte = 8'h4f; 2: tx_byte = 8'h53;
                            3: tx_byte = 8'h54; 4: tx_byte = 8'h5f; 5: tx_byte = 8'h53;
                            6: tx_byte = 8'h54; 7: tx_byte = 8'h41; 8: tx_byte = 8'h54;
                            9: tx_byte = 8'h45; 10: tx_byte = 8'h3d;
                            11: tx_byte = hex_ascii({3'b000, report_post_state[8]});
                            12: tx_byte = hex_ascii(report_post_state[7:4]);
                            13: tx_byte = hex_ascii(report_post_state[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            16: tx_byte = 8'h44; 17: tx_byte = 8'h49; 18: tx_byte = 8'h56;
                            19: tx_byte = 8'h5f; 20: tx_byte = 8'h42; 21: tx_byte = 8'h55;
                            22: tx_byte = 8'h53; 23: tx_byte = 8'h59; 24: tx_byte = 8'h3d;
                            25: tx_byte = report_div_busy ? 8'h31 : 8'h30;
                            26: tx_byte = 8'h0d; 27: tx_byte = 8'h0a;
                            28: tx_byte = 8'h44; 29: tx_byte = 8'h49; 30: tx_byte = 8'h56;
                            31: tx_byte = 8'h5f; 32: tx_byte = 8'h42; 33: tx_byte = 8'h49;
                            34: tx_byte = 8'h54; 35: tx_byte = 8'h3d;
                            36: tx_byte = hex_ascii({2'b00, report_div_bit[5:4]});
                            37: tx_byte = hex_ascii(report_div_bit[3:0]);
                            38: tx_byte = 8'h0d; 39: tx_byte = 8'h0a;
                            40: tx_byte = 8'h46; 41: tx_byte = 8'h49; 42: tx_byte = 8'h4c;
                            43: tx_byte = 8'h4c; 44: tx_byte = 8'h5f; 45: tx_byte = 8'h53;
                            46: tx_byte = 8'h54; 47: tx_byte = 8'h41; 48: tx_byte = 8'h47;
                            49: tx_byte = 8'h45; 50: tx_byte = 8'h3d;
                            51: tx_byte = hex_ascii({1'b0, report_fill_stage});
                            52: tx_byte = 8'h0d; 53: tx_byte = 8'h0a;
                            54: tx_byte = 8'h46; 55: tx_byte = 8'h52; 56: tx_byte = 8'h41;
                            57: tx_byte = 8'h4d; 58: tx_byte = 8'h45; 59: tx_byte = 8'h5f;
                            60: tx_byte = 8'h54; 61: tx_byte = 8'h4f; 62: tx_byte = 8'h47;
                            63: tx_byte = 8'h47; 64: tx_byte = 8'h4c; 65: tx_byte = 8'h45;
                            66: tx_byte = 8'h3d;
                            67: tx_byte = report_frame_toggle ? 8'h31 : 8'h30;
                            68: tx_byte = 8'h0d; 69: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 539) && (debug_offset < 579)) begin
                        case (debug_offset - 539)
                            0: tx_byte = "P"; 1: tx_byte = "7"; 2: tx_byte = "F";
                            3: tx_byte = "_"; 4: tx_byte = "S"; 5: tx_byte = "=";
                            6: tx_byte = hex_ascii(report_p7f_sum[31:28]);
                            7: tx_byte = hex_ascii(report_p7f_sum[27:24]);
                            8: tx_byte = hex_ascii(report_p7f_sum[23:20]);
                            9: tx_byte = hex_ascii(report_p7f_sum[19:16]);
                            10: tx_byte = hex_ascii(report_p7f_sum[15:12]);
                            11: tx_byte = hex_ascii(report_p7f_sum[11:8]);
                            12: tx_byte = hex_ascii(report_p7f_sum[7:4]);
                            13: tx_byte = hex_ascii(report_p7f_sum[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            16: tx_byte = "P"; 17: tx_byte = "7"; 18: tx_byte = "F";
                            19: tx_byte = "_"; 20: tx_byte = "C"; 21: tx_byte = "=";
                            22: tx_byte = hex_ascii(report_p7f_count[15:12]);
                            23: tx_byte = hex_ascii(report_p7f_count[11:8]);
                            24: tx_byte = hex_ascii(report_p7f_count[7:4]);
                            25: tx_byte = hex_ascii(report_p7f_count[3:0]);
                            26: tx_byte = 8'h0d; 27: tx_byte = 8'h0a;
                            28: tx_byte = "P"; 29: tx_byte = "7"; 30: tx_byte = "F";
                            31: tx_byte = "_"; 32: tx_byte = "R"; 33: tx_byte = "=";
                            34: tx_byte = hex_ascii(report_p7f_raw_y[15:12]);
                            35: tx_byte = hex_ascii(report_p7f_raw_y[11:8]);
                            36: tx_byte = hex_ascii(report_p7f_raw_y[7:4]);
                            37: tx_byte = hex_ascii(report_p7f_raw_y[3:0]);
                            38: tx_byte = 8'h0d; 39: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 579) && (debug_offset < 602)) begin
                        case (debug_offset - 579)
                            0: tx_byte = "C"; 1: tx_byte = "A"; 2: tx_byte = "P";
                            3: tx_byte = "T"; 4: tx_byte = "U"; 5: tx_byte = "R";
                            6: tx_byte = "E"; 7: tx_byte = "_"; 8: tx_byte = "H";
                            9: tx_byte = "I"; 10: tx_byte = "T"; 11: tx_byte = "S";
                            12: tx_byte = "=";
                            13: tx_byte = hex_ascii(report_capture_count[31:28]);
                            14: tx_byte = hex_ascii(report_capture_count[27:24]);
                            15: tx_byte = hex_ascii(report_capture_count[23:20]);
                            16: tx_byte = hex_ascii(report_capture_count[19:16]);
                            17: tx_byte = hex_ascii(report_capture_count[15:12]);
                            18: tx_byte = hex_ascii(report_capture_count[11:8]);
                            19: tx_byte = hex_ascii(report_capture_count[7:4]);
                            20: tx_byte = hex_ascii(report_capture_count[3:0]);
                            21: tx_byte = 8'h0d; 22: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 602) && (debug_offset < 624)) begin
                        case (debug_offset - 602)
                            0: tx_byte = "Z"; 1: tx_byte = "E"; 2: tx_byte = "R";
                            3: tx_byte = "O"; 4: tx_byte = "_"; 5: tx_byte = "C";
                            6: tx_byte = "_"; 7: tx_byte = "S"; 8: tx_byte = "U";
                            9: tx_byte = "M"; 10: tx_byte = "=";
                            11: tx_byte = hex_ascii(report_zero_count_sum_errors[7:4]);
                            12: tx_byte = hex_ascii(report_zero_count_sum_errors[3:0]);
                            13: tx_byte = 8'h0d; 14: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 624) && (debug_offset < 646)) begin
                        case (debug_offset - 624)
                            0: tx_byte = "Z"; 1: tx_byte = "E"; 2: tx_byte = "R";
                            3: tx_byte = "O"; 4: tx_byte = "_"; 5: tx_byte = "C";
                            6: tx_byte = "_"; 7: tx_byte = "I"; 8: tx_byte = "D";
                            9: tx_byte = "X"; 10: tx_byte = "=";
                            11: tx_byte = hex_ascii(report_first_zero_count_sum_error[7:4]);
                            12: tx_byte = hex_ascii(report_first_zero_count_sum_error[3:0]);
                            13: tx_byte = 8'h0d; 14: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 646) && (debug_offset < 668)) begin
                        case (debug_offset - 646)
                            0: tx_byte = "C"; 1: tx_byte = "_"; 2: tx_byte = "N";
                            3: tx_byte = "Z"; 4: tx_byte = "_"; 5: tx_byte = "S";
                            6: tx_byte = "0"; 7: tx_byte = "=";
                            8: tx_byte = hex_ascii(report_nonzero_count_zero_sum_errors[7:4]);
                            9: tx_byte = hex_ascii(report_nonzero_count_zero_sum_errors[3:0]);
                            10: tx_byte = 8'h0d; 11: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 668) && (debug_offset < 690)) begin
                        case (debug_offset - 668)
                            0: tx_byte = "C"; 1: tx_byte = "_"; 2: tx_byte = "N";
                            3: tx_byte = "Z"; 4: tx_byte = "_"; 5: tx_byte = "S";
                            6: tx_byte = "0"; 7: tx_byte = "_"; 8: tx_byte = "I";
                            9: tx_byte = "D"; 10: tx_byte = "X"; 11: tx_byte = "=";
                            12: tx_byte = hex_ascii(report_first_nonzero_count_zero_sum_error[7:4]);
                            13: tx_byte = hex_ascii(report_first_nonzero_count_zero_sum_error[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 690) && (debug_offset < 712)) begin
                        case (debug_offset - 690)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "E"; 5: tx_byte = "R";
                            6: tx_byte = "R"; 7: tx_byte = "=";
                            8: tx_byte = hex_ascii(report_division_errors[7:4]);
                            9: tx_byte = hex_ascii(report_division_errors[3:0]);
                            10: tx_byte = 8'h0d; 11: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 712) && (debug_offset < 734)) begin
                        case (debug_offset - 712)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "E"; 5: tx_byte = "R";
                            6: tx_byte = "R"; 7: tx_byte = "_"; 8: tx_byte = "I";
                            9: tx_byte = "D"; 10: tx_byte = "X"; 11: tx_byte = "=";
                            12: tx_byte = hex_ascii(report_first_division_error[7:4]);
                            13: tx_byte = hex_ascii(report_first_division_error[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 734) && (debug_offset < 754)) begin
                        case (debug_offset - 734)
                            0: tx_byte = 8'h44; 1: tx_byte = 8'h49; 2: tx_byte = 8'h56;
                            3: tx_byte = 8'h5f; 4: tx_byte = 8'h42; 5: tx_byte = 8'h41;
                            6: tx_byte = 8'h44; 7: tx_byte = 8'h5f; 8: tx_byte = 8'h53;
                            9: tx_byte = 8'h3d;
                            10: tx_byte = hex_ascii(report_first_division_error_sum[31:28]);
                            11: tx_byte = hex_ascii(report_first_division_error_sum[27:24]);
                            12: tx_byte = hex_ascii(report_first_division_error_sum[23:20]);
                            13: tx_byte = hex_ascii(report_first_division_error_sum[19:16]);
                            14: tx_byte = hex_ascii(report_first_division_error_sum[15:12]);
                            15: tx_byte = hex_ascii(report_first_division_error_sum[11:8]);
                            16: tx_byte = hex_ascii(report_first_division_error_sum[7:4]);
                            17: tx_byte = hex_ascii(report_first_division_error_sum[3:0]);
                            18: tx_byte = 8'h0d; 19: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 754) && (debug_offset < 770)) begin
                        case (debug_offset - 754)
                            0: tx_byte = 8'h44; 1: tx_byte = 8'h49; 2: tx_byte = 8'h56;
                            3: tx_byte = 8'h5f; 4: tx_byte = 8'h42; 5: tx_byte = 8'h41;
                            6: tx_byte = 8'h44; 7: tx_byte = 8'h5f; 8: tx_byte = 8'h43;
                            9: tx_byte = 8'h3d;
                            10: tx_byte = hex_ascii(report_first_division_error_count_value[15:12]);
                            11: tx_byte = hex_ascii(report_first_division_error_count_value[11:8]);
                            12: tx_byte = hex_ascii(report_first_division_error_count_value[7:4]);
                            13: tx_byte = hex_ascii(report_first_division_error_count_value[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 770) && (debug_offset < 786)) begin
                        case (debug_offset - 770)
                            0: tx_byte = 8'h44; 1: tx_byte = 8'h49; 2: tx_byte = 8'h56;
                            3: tx_byte = 8'h5f; 4: tx_byte = 8'h42; 5: tx_byte = 8'h41;
                            6: tx_byte = 8'h44; 7: tx_byte = 8'h5f; 8: tx_byte = 8'h51;
                            9: tx_byte = 8'h3d;
                            10: tx_byte = hex_ascii(report_first_division_error_quotient[15:12]);
                            11: tx_byte = hex_ascii(report_first_division_error_quotient[11:8]);
                            12: tx_byte = hex_ascii(report_first_division_error_quotient[7:4]);
                            13: tx_byte = hex_ascii(report_first_division_error_quotient[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 786) && (debug_offset < 805)) begin
                        case (debug_offset - 786)
                            0: tx_byte = 8'h44; 1: tx_byte = 8'h49; 2: tx_byte = 8'h56;
                            3: tx_byte = 8'h5f; 4: tx_byte = 8'h42; 5: tx_byte = 8'h41;
                            6: tx_byte = 8'h44; 7: tx_byte = 8'h5f; 8: tx_byte = 8'h52;
                            9: tx_byte = 8'h45; 10: tx_byte = 8'h4d; 11: tx_byte = 8'h3d;
                            12: tx_byte = hex_ascii({3'b000, report_first_division_error_remainder[16]});
                            13: tx_byte = hex_ascii(report_first_division_error_remainder[15:12]);
                            14: tx_byte = hex_ascii(report_first_division_error_remainder[11:8]);
                            15: tx_byte = hex_ascii(report_first_division_error_remainder[7:4]);
                            16: tx_byte = hex_ascii(report_first_division_error_remainder[3:0]);
                            17: tx_byte = 8'h0d; 18: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 805) && (debug_offset < 821)) begin
                        case (debug_offset - 805)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "B";
                            9: tx_byte = "I"; 10: tx_byte = "T"; 11: tx_byte = "=";
                            12: tx_byte = hex_ascii({2'b0, report_first_division_error_bit[5:4]});
                            13: tx_byte = hex_ascii(report_first_division_error_bit[3:0]);
                            14: tx_byte = 8'h0d; 15: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 821) && (debug_offset < 845)) begin
                        case (debug_offset - 821)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "N";
                            9: tx_byte = "U"; 10: tx_byte = "M"; 11: tx_byte = "=";
                            12: tx_byte = hex_ascii(report_first_division_error_shift[31:28]);
                            13: tx_byte = hex_ascii(report_first_division_error_shift[27:24]);
                            14: tx_byte = hex_ascii(report_first_division_error_shift[23:20]);
                            15: tx_byte = hex_ascii(report_first_division_error_shift[19:16]);
                            16: tx_byte = hex_ascii(report_first_division_error_shift[15:12]);
                            17: tx_byte = hex_ascii(report_first_division_error_shift[11:8]);
                            18: tx_byte = hex_ascii(report_first_division_error_shift[7:4]);
                            19: tx_byte = hex_ascii(report_first_division_error_shift[3:0]);
                            20: tx_byte = 8'h0d; 21: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 845) && (debug_offset < 868)) begin
                        case (debug_offset - 845)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "P";
                            9: tx_byte = "R"; 10: tx_byte = "E"; 11: tx_byte = "_";
                            12: tx_byte = "R"; 13: tx_byte = "E"; 14: tx_byte = "M";
                            15: tx_byte = "=";
                            16: tx_byte = hex_ascii({3'b000, report_first_division_error_pre_rem[16]});
                            17: tx_byte = hex_ascii(report_first_division_error_pre_rem[15:12]);
                            18: tx_byte = hex_ascii(report_first_division_error_pre_rem[11:8]);
                            19: tx_byte = hex_ascii(report_first_division_error_pre_rem[7:4]);
                            20: tx_byte = hex_ascii(report_first_division_error_pre_rem[3:0]);
                            21: tx_byte = 8'h0d; 22: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 868) && (debug_offset < 892)) begin
                        case (debug_offset - 868)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "P";
                            9: tx_byte = "R"; 10: tx_byte = "E"; 11: tx_byte = "_";
                            12: tx_byte = "Q"; 13: tx_byte = "=";
                            14: tx_byte = hex_ascii(report_first_division_error_pre_q[31:28]);
                            15: tx_byte = hex_ascii(report_first_division_error_pre_q[27:24]);
                            16: tx_byte = hex_ascii(report_first_division_error_pre_q[23:20]);
                            17: tx_byte = hex_ascii(report_first_division_error_pre_q[19:16]);
                            18: tx_byte = hex_ascii(report_first_division_error_pre_q[15:12]);
                            19: tx_byte = hex_ascii(report_first_division_error_pre_q[11:8]);
                            20: tx_byte = hex_ascii(report_first_division_error_pre_q[7:4]);
                            21: tx_byte = hex_ascii(report_first_division_error_pre_q[3:0]);
                            22: tx_byte = 8'h0d; 23: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 892) && (debug_offset < 913)) begin
                        case (debug_offset - 892)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "T";
                            9: tx_byte = "R"; 10: tx_byte = "I"; 11: tx_byte = "A";
                            12: tx_byte = "L"; 13: tx_byte = "=";
                            14: tx_byte = hex_ascii({3'b000, report_first_division_error_trial[16]});
                            15: tx_byte = hex_ascii(report_first_division_error_trial[15:12]);
                            16: tx_byte = hex_ascii(report_first_division_error_trial[11:8]);
                            17: tx_byte = hex_ascii(report_first_division_error_trial[7:4]);
                            18: tx_byte = hex_ascii(report_first_division_error_trial[3:0]);
                            19: tx_byte = 8'h0d; 20: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 913) && (debug_offset < 942)) begin
                        case (debug_offset - 913)
                            0: tx_byte = "D"; 1: tx_byte = "I"; 2: tx_byte = "V";
                            3: tx_byte = "_"; 4: tx_byte = "B"; 5: tx_byte = "A";
                            6: tx_byte = "D"; 7: tx_byte = "_"; 8: tx_byte = "N";
                            9: tx_byte = "E"; 10: tx_byte = "X"; 11: tx_byte = "T";
                            12: tx_byte = "_"; 13: tx_byte = "Q"; 14: tx_byte = "=";
                            15: tx_byte = hex_ascii(report_first_division_error_next_q[31:28]);
                            16: tx_byte = hex_ascii(report_first_division_error_next_q[27:24]);
                            17: tx_byte = hex_ascii(report_first_division_error_next_q[23:20]);
                            18: tx_byte = hex_ascii(report_first_division_error_next_q[19:16]);
                            19: tx_byte = hex_ascii(report_first_division_error_next_q[15:12]);
                            20: tx_byte = hex_ascii(report_first_division_error_next_q[11:8]);
                            21: tx_byte = hex_ascii(report_first_division_error_next_q[7:4]);
                            22: tx_byte = hex_ascii(report_first_division_error_next_q[3:0]);
                            23: tx_byte = 8'h0d; 24: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 942) && (debug_offset < 983)) begin
                        // R-2 additions: ignored key presses, discarded frame events, status snapshot valid
                        case (debug_offset - 942)
                            0: tx_byte = "R"; 1: tx_byte = "E"; 2: tx_byte = "Q"; 3: tx_byte = "_";
                            4: tx_byte = "D"; 5: tx_byte = "R"; 6: tx_byte = "O"; 7: tx_byte = "P";
                            8: tx_byte = "=";
                            9: tx_byte = hex_ascii(report_req_drop[7:4]);
                            10: tx_byte = hex_ascii(report_req_drop[3:0]);
                            11: tx_byte = 8'h0d; 12: tx_byte = 8'h0a;
                            13: tx_byte = "S"; 14: tx_byte = "T"; 15: tx_byte = "A"; 16: tx_byte = "L";
                            17: tx_byte = "E"; 18: tx_byte = "_"; 19: tx_byte = "D"; 20: tx_byte = "R";
                            21: tx_byte = "O"; 22: tx_byte = "P"; 23: tx_byte = "=";
                            24: tx_byte = hex_ascii(report_stale_drop[7:4]);
                            25: tx_byte = hex_ascii(report_stale_drop[3:0]);
                            26: tx_byte = 8'h0d; 27: tx_byte = 8'h0a;
                            28: tx_byte = "S"; 29: tx_byte = "T"; 30: tx_byte = "A"; 31: tx_byte = "T";
                            32: tx_byte = "U"; 33: tx_byte = "S"; 34: tx_byte = "_"; 35: tx_byte = "O";
                            36: tx_byte = "K"; 37: tx_byte = "=";
                            38: tx_byte = report_status_ok ? 8'h31 : 8'h30;
                            39: tx_byte = 8'h0d; 40: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else if ((debug_offset >= 983) && (debug_offset < 1003)) begin
                        // R-2: I_video_clk edges counted in the gate window: HS_RX_CNT=xxxxxxxx
                        case (debug_offset - 983)
                            0: tx_byte = "H"; 1: tx_byte = "S"; 2: tx_byte = "_"; 3: tx_byte = "R";
                            4: tx_byte = "X"; 5: tx_byte = "_"; 6: tx_byte = "C"; 7: tx_byte = "N";
                            8: tx_byte = "T"; 9: tx_byte = "=";
                            10: tx_byte = hex_ascii(report_hs_cnt[31:28]);
                            11: tx_byte = hex_ascii(report_hs_cnt[27:24]);
                            12: tx_byte = hex_ascii(report_hs_cnt[23:20]);
                            13: tx_byte = hex_ascii(report_hs_cnt[19:16]);
                            14: tx_byte = hex_ascii(report_hs_cnt[15:12]);
                            15: tx_byte = hex_ascii(report_hs_cnt[11:8]);
                            16: tx_byte = hex_ascii(report_hs_cnt[7:4]);
                            17: tx_byte = hex_ascii(report_hs_cnt[3:0]);
                            18: tx_byte = 8'h0d; 19: tx_byte = 8'h0a;
                            default: tx_byte = 8'h20;
                        endcase
                    end else begin
                        tx_byte = 8'h20;
                    end
                end
            endcase
        end else if (report_pos < (POINTS_OFFSET + SAMPLE_COUNT * POINT_RECORD_BYTES)) begin
            point_offset = report_pos - POINTS_OFFSET;
            point_index  = point_offset / POINT_RECORD_BYTES;
            point_field  = point_offset % POINT_RECORD_BYTES;
            report_point_y = report_final_y_mem[point_index];
            report_final_point_valid = report_final_valid_mem[point_index] &&
                                       (report_point_y >= ROI_Y_START) &&
                                       (report_point_y <= ROI_Y_END);
            report_raw_point_y = report_raw_y_mem[point_index];
            // Show the actual average whenever a bin had hits; RAW_VALID
            // separately indicates whether it passed the ROI/edge checks.
            report_raw_point_valid = (report_count_mem[point_index] != 0);
            case (point_field)
                0: tx_byte = "P";
                1: tx_byte = hex_ascii(point_index[7:4]);
                2: tx_byte = hex_ascii(point_index[3:0]);
                3: tx_byte = "=";
                4: tx_byte = report_final_point_valid ?
                             hex_ascii(report_point_y[15:12]) : "F";
                5: tx_byte = report_final_point_valid ?
                             hex_ascii(report_point_y[11:8]) : "F";
                6: tx_byte = report_final_point_valid ?
                             hex_ascii(report_point_y[7:4]) : "F";
                7: tx_byte = report_final_point_valid ?
                             hex_ascii(report_point_y[3:0]) : "F";
                8: tx_byte = ",";
                9: tx_byte = "C";
                10: tx_byte = "=";
                11: tx_byte = hex_ascii(report_count_mem[point_index][15:12]);
                12: tx_byte = hex_ascii(report_count_mem[point_index][11:8]);
                13: tx_byte = hex_ascii(report_count_mem[point_index][7:4]);
                14: tx_byte = hex_ascii(report_count_mem[point_index][3:0]);
                15: tx_byte = ",";
                16: tx_byte = "S";
                17: tx_byte = "=";
                18: tx_byte = hex_ascii(report_sum_mem[point_index][31:28]);
                19: tx_byte = hex_ascii(report_sum_mem[point_index][27:24]);
                20: tx_byte = hex_ascii(report_sum_mem[point_index][23:20]);
                21: tx_byte = hex_ascii(report_sum_mem[point_index][19:16]);
                22: tx_byte = hex_ascii(report_sum_mem[point_index][15:12]);
                23: tx_byte = hex_ascii(report_sum_mem[point_index][11:8]);
                24: tx_byte = hex_ascii(report_sum_mem[point_index][7:4]);
                25: tx_byte = hex_ascii(report_sum_mem[point_index][3:0]);
                26: tx_byte = ",";
                27: tx_byte = "R";
                28: tx_byte = "=";
                29: tx_byte = report_raw_point_valid ?
                             hex_ascii(report_raw_point_y[15:12]) : "F";
                30: tx_byte = report_raw_point_valid ?
                             hex_ascii(report_raw_point_y[11:8]) : "F";
                31: tx_byte = report_raw_point_valid ?
                             hex_ascii(report_raw_point_y[7:4]) : "F";
                32: tx_byte = report_raw_point_valid ?
                             hex_ascii(report_raw_point_y[3:0]) : "F";
                33: tx_byte = 8'h0d;
                34: tx_byte = 8'h0a;
                default: tx_byte = 8'h20;
            endcase
        end else begin
            case (report_pos - (POINTS_OFFSET + SAMPLE_COUNT * POINT_RECORD_BYTES))
                0: tx_byte = "F"; 1: tx_byte = "R"; 2: tx_byte = "A";
                3: tx_byte = "M"; 4: tx_byte = "E"; 5: tx_byte = "_";
                6: tx_byte = "E"; 7: tx_byte = "N"; 8: tx_byte = "D";
                9: tx_byte = 8'h0d; 10: tx_byte = 8'h0a;
                default: tx_byte = 8'h20;
            endcase
        end
    end

    always @(posedge I_sys_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_toggle_meta <= 1'b0;
            frame_toggle_sync <= 1'b0;
            frame_toggle_seen <= 1'b0;
            req_id_sys <= 2'd0;
            req_gray_sys <= 2'd0;
            tq_req_sys <= 1'b0; tq_ack_meta <= 1'b0; tq_ack_sync <= 1'b0; tq_ack_seen <= 1'b0;
            tmo_state <= 2'd0; tmo_cnt <= 16'd0; req_drop <= 8'd0; stale_drop <= 8'd0;
            report_req_drop <= 8'd0; report_stale_drop <= 8'd0; report_status_ok <= 1'b1;
            report_hs_cnt <= 32'd0; fm_gate_ctr <= 32'd0; fm_gate_sys <= 1'b0;
            fm_done_meta <= 1'b0; fm_done_sync <= 1'b0; fm_done_seen <= 1'b0; fm_report <= 32'd0;
            key_meta          <= 1'b1;
            key_sync          <= 1'b1;
            key_armed         <= 1'b1;
            key_count         <= {DB_WIDTH{1'b0}};
            capture_pending   <= 1'b0;
            timeout_reported  <= 1'b0;
            capture_wait_count <= {WAIT_WIDTH{1'b0}};
            report_active     <= 1'b0;
            report_snapshot_active <= 1'b0;
            report_snapshot_wait <= 1'b0;
            report_snapshot_bin_index <= 8'd0;
            report_snapshot_count_hold <= 16'd0;
            report_snapshot_sum_hold <= 32'd0;
            report_snapshot_raw_y_hold <= 16'hffff;
            report_snapshot_final_y_hold <= 16'hffff;
            report_snapshot_final_valid_hold <= 1'b0;
            dac_valid_points <= 8'd0;
            dac_hold_code <= 14'h2000;
            dac_reject_count <= 8'd0;
            dac_frame_ok <= 1'b0;
            O_dac_sample_we <= 1'b0;
            O_dac_sample_addr <= 8'd0;
            O_dac_sample_code <= 14'h2000;
            O_dac_frame_commit <= 1'b0;
            O_dac_frame_valid <= 1'b0;
            report_pos        <= {REPORT_POS_WIDTH{1'b0}};
            baud_count        <= 16'd0;
            tx_bit_count      <= 4'd0;
            tx_shift          <= 10'h3ff;
            tx_active         <= 1'b0;
            key_ack_active    <= 1'b0;
            key_ack_pending   <= 1'b0;
            tx_is_ack         <= 1'b0;
            key_ack_pos       <= 3'd0;
            report_first_x <= 16'hffff;
            report_last_x <= 16'hffff;
            report_x_valid <= 1'b0;
            report_raw_valid_word <= 32'd0;
            report_final_valid_word <= 32'd0;
            report_timeout <= 1'b0;
            report_div_active <= 1'b0;
            report_div_load <= 1'b0;
            report_post_state <= 9'd0;
            report_div_busy <= 1'b0;
            report_div_bit <= 6'd0;
            report_fill_stage <= 2'd0;
            report_frame_toggle <= 1'b0;
            report_div_index <= 8'd0;
            report_divisor <= 16'd0;
            report_div_quotient <= 16'd0;
            report_div_remainder <= 32'd0;
            report_div_sum <= 32'd0;
            report_accept_count <= 32'd0;
            report_capture_count <= 32'd0;
            report_y_min <= 16'hffff;
            report_y_max <= 16'd0;
            report_input_y_sum <= 32'd0;
            report_bin_count_sum <= 32'd0;
            report_bin_y_sum <= 32'd0;
            report_zero_count_sum_errors <= 8'd0;
            report_first_zero_count_sum_error <= 8'hff;
            report_nonzero_count_zero_sum_errors <= 8'd0;
            report_first_nonzero_count_zero_sum_error <= 8'hff;
            report_division_errors <= 8'd0;
            report_first_division_error <= 8'hff;
            report_first_division_error_sum <= 32'd0;
            report_first_division_error_count_value <= 16'd0;
            report_first_division_error_quotient <= 16'd0;
            report_first_division_error_remainder <= 17'd0;
            report_first_division_error_bit <= 6'd0;
            report_first_division_error_shift <= 32'd0;
            report_first_division_error_pre_rem <= 17'd0;
            report_first_division_error_pre_q <= 32'd0;
            report_first_division_error_trial <= 17'd0;
            report_first_division_error_next_q <= 32'd0;
            report_p7f_sum <= 32'd0;
            report_p7f_count <= 16'd0;
            report_p7f_raw_y <= 16'hffff;
            for (report_snapshot_index = 0;
                 report_snapshot_index < SAMPLE_COUNT;
                 report_snapshot_index = report_snapshot_index + 1) begin
                report_count_mem[report_snapshot_index] <= 16'd0;
                report_sum_mem[report_snapshot_index] <= 32'd0;
                report_raw_y_mem[report_snapshot_index] <= 16'hffff;
                report_final_y_mem[report_snapshot_index] <= 16'hffff;
                report_raw_valid_mem[report_snapshot_index] <= 1'b0;
                report_final_valid_mem[report_snapshot_index] <= 1'b0;
            end
            for (report_snapshot_index = 0; report_snapshot_index < 3;
                 report_snapshot_index = report_snapshot_index + 1) begin
                report_dbg_sum[report_snapshot_index] <= 32'd0;
                report_dbg_count[report_snapshot_index] <= 16'd0;
                report_dbg_avg[report_snapshot_index] <= 16'hffff;
                report_dbg_valid[report_snapshot_index] <= 1'b0;
                report_pre_div_sum[report_snapshot_index] <= 32'd0;
                report_pre_div_count[report_snapshot_index] <= 16'd0;
                report_pre_div_valid[report_snapshot_index] <= 1'b0;
            end
        end else begin
            O_dac_sample_we <= 1'b0;
            O_dac_frame_commit <= 1'b0;
            O_dac_frame_valid <= 1'b0;
            frame_toggle_meta <= frame_toggle;
            frame_toggle_sync <= frame_toggle_meta;
            tq_ack_meta <= tq_ack;
            tq_ack_sync <= tq_ack_meta;
            // R-2: I_video_clk frequency meter, sys side
            fm_gate_ctr <= (fm_gate_ctr >= (2 * FREQ_GATE_CYCLES - 1)) ? 32'd0 : fm_gate_ctr + 1'b1;
            fm_gate_sys <= (fm_gate_ctr < FREQ_GATE_CYCLES);
            fm_done_meta <= fm_done;
            fm_done_sync <= fm_done_meta;
            if (fm_done_sync != fm_done_seen) begin
                fm_done_seen <= fm_done_sync;
                fm_report    <= fm_result;
            end
            // 按键三来自外部管脚，先同步到系统时钟域�?
            key_meta <= I_capture_key_n;
            key_sync <= key_meta;

            if (!key_sync) begin
                if (key_count < DEBOUNCE_LIMIT)
                    key_count <= key_count + 1'b1;
                else if (key_armed) begin
                    key_armed <= 1'b0;
                    // R-2 interlock: a press is accepted only while no snapshot read and no UART report
                    // is running.  A press that arrives on the very edge on which the event / timeout logic
                    // starts a report is retried on the next edge (key_armed stays 1).  Every ignored press
                    // is counted in req_drop and reported.  Accepting a press discards any latched frame
                    // event, the timeout flag and a running status handshake, so only a frame that STARTS
                    // after the press can answer it.
                    if (req_busy_now) begin
                        key_armed <= 1'b1;
                    end else if (!report_snapshot_active && !report_active) begin
                        capture_pending <= 1'b1;
                        timeout_reported <= 1'b0;
                        req_id_sys <= req_id_next;
                        req_gray_sys <= req_gray_next;
                        capture_wait_count <= {WAIT_WIDTH{1'b0}};
                        frame_toggle_seen <= frame_toggle_sync;
                        tmo_state <= 2'd0;
                    end else if (req_drop != 8'hff) begin
                        req_drop <= req_drop + 1'b1;
                    end
                    // Do not drop the acknowledgement while a previous
                    // report is still being serialized. Queue it instead.
                    if (!tx_active && !report_active && !key_ack_active &&
                        !key_ack_pending) begin
                        key_ack_active <= 1'b1;
                        key_ack_pos <= 3'd0;
                    end else begin
                        key_ack_pending <= 1'b1;
                    end
                end
            end else begin
                key_count <= {DB_WIDTH{1'b0}};
                key_armed <= 1'b1;
            end

            if (capture_pending && !timeout_reported && !report_active) begin
                // 固定窗口看门狗：从按键（或被重启）起 FRAME_WAIT_TIMEOUT_CYCLES
                // 内没有完成采集就必报 TIMEOUT。不再用 progress_signature 重启
                // 窗口——视频域一旦卡在"信号还在抖"的中间态，原实现可能永远
                // 不触发，板上就完全失去可观测性（报告 §10）。
                if (capture_wait_count < FRAME_WAIT_TIMEOUT_CYCLES) begin
                    capture_wait_count <= capture_wait_count + 1'b1;
                end
            end

            if (report_snapshot_active) begin
                // Issue a registered read first, then commit its held data
                // on the following system clock. This handles synchronous
                // RAM inference for the completed-frame snapshot arrays.
                if (!report_snapshot_wait) begin
                    report_snapshot_count_hold <=
                        done_count_mem[report_snapshot_bin_index];
                    report_snapshot_sum_hold <=
                        done_sum_mem[report_snapshot_bin_index];
                    report_snapshot_raw_y_hold <=
                        done_raw_y_mem[report_snapshot_bin_index];
                    report_snapshot_final_y_hold <=
                        done_frame_y_mem[report_snapshot_bin_index];
                    report_snapshot_final_valid_hold <=
                        done_frame_valid_mem[report_snapshot_bin_index];
                    report_snapshot_wait <= 1'b1;
                end else begin
                    report_snapshot_wait <= 1'b0;
                    O_dac_sample_we <= 1'b1;
                    O_dac_sample_addr <= report_snapshot_bin_index;
                    // 无效点不再一律映射成 0（那会在图上打出一根到屏幕底部的尖刺），
                    // 改为保持上一个有效点的码值；帧首无有效点时用中值。
                    if (dac_snapshot_point_valid) begin
                        O_dac_sample_code <= dac_point_code;
                        dac_hold_code <= dac_point_code;
                    end else if (report_snapshot_bin_index == 0) begin
                        O_dac_sample_code <= 14'h2000;
                        dac_hold_code <= 14'h2000;
                    end else begin
                        O_dac_sample_code <= dac_hold_code;
                    end
                    if (report_snapshot_bin_index == 0)
                        dac_valid_points <= dac_snapshot_point_valid ? 8'd1 : 8'd0;
                    else
                        dac_valid_points <= dac_valid_points +
                            (dac_snapshot_point_valid ? 8'd1 : 8'd0);
                    report_count_mem[report_snapshot_bin_index] <=
                        report_snapshot_count_hold;
                    report_sum_mem[report_snapshot_bin_index] <=
                        report_snapshot_sum_hold;
                    report_raw_y_mem[report_snapshot_bin_index] <=
                        report_snapshot_raw_y_hold;
                    report_final_y_mem[report_snapshot_bin_index] <=
                        report_snapshot_final_y_hold;
                    report_raw_valid_mem[report_snapshot_bin_index] <=
                        (report_snapshot_count_hold != 0) &&
                        (report_snapshot_raw_y_hold >= ROI_Y_START) &&
                        (report_snapshot_raw_y_hold <= ROI_Y_END);
                    report_final_valid_mem[report_snapshot_bin_index] <=
                        report_snapshot_final_valid_hold &&
                        (report_snapshot_final_y_hold >= ROI_Y_START) &&
                        (report_snapshot_final_y_hold <= ROI_Y_END);
                    if (report_snapshot_bin_index < 32) begin
                        report_raw_valid_word[report_snapshot_bin_index] <=
                            (report_snapshot_count_hold != 0) &&
                            (report_snapshot_raw_y_hold >= ROI_Y_START) &&
                            (report_snapshot_raw_y_hold <= ROI_Y_END);
                        report_final_valid_word[report_snapshot_bin_index] <=
                            report_snapshot_final_valid_hold &&
                            (report_snapshot_final_y_hold <= ROI_Y_END) &&
                            (report_snapshot_final_y_hold >= ROI_Y_START);
                    end
                    if (report_snapshot_bin_index == SAMPLE_COUNT - 1) begin
                        // 严格守恒门控：任何一项不一致，本帧就不提交。
                        // dac904_wave_replay 在 I_frame_commit=0 时不动 bank，
                        // DAC 会继续播上一帧好的数据——宁可短暂冻结，也不要把
                        // 带坏 bin 的帧画到模拟输出上。
                        // 注意 report_x_valid 不参与门控：DAC 只用 y，x 追踪坏掉
                        // 不应该把显示一起关掉（那是 2026-10-30 之前踩过的坑）。
                        dac_frame_ok =
                            ((dac_valid_points + (dac_snapshot_point_valid ? 8'd1 : 8'd0))
                             == SAMPLE_COUNT) &&
                            (done_capture_count == done_accept_count) &&
                            (done_input_y_sum == done_bin_y_sum) &&
                            (done_zero_count_sum_errors == 0) &&
                            (done_nonzero_count_zero_sum_errors == 0) &&
                            (done_division_errors == 0);
                        O_dac_frame_commit <= dac_frame_ok;
                        O_dac_frame_valid  <= dac_frame_ok;
                        if (!dac_frame_ok && (dac_reject_count != 8'hff))
                            dac_reject_count <= dac_reject_count + 1'b1;
                        report_snapshot_active <= 1'b0;
                        report_active <= 1'b1;
                        report_pos <= {REPORT_POS_WIDTH{1'b0}};
                    end else begin
                        report_snapshot_bin_index <= report_snapshot_bin_index + 1'b1;
                    end
                end
            end

            // R-2: tmo_cnt runs while the status acknowledge is awaited; a late acknowledge that no
            // handshake is waiting for is consumed here.
            if (tmo_state == 2'd1 && !tmo_go) tmo_cnt <= tmo_cnt + 1'b1;
            if (tq_ack_new && tmo_state == 2'd0) tq_ack_seen <= tq_ack_sync;

            if (evt_ready && evt_valid) begin
                // R-2: the event answers the pending request only if the frame was started after the
                // accepted key press (done_valid / done_req, written before the toggle flipped).
                frame_toggle_seen <= frame_toggle_sync;
                tmo_state <= 2'd0;
                report_req_drop <= req_drop;
                report_stale_drop <= stale_drop;
                report_hs_cnt <= fm_report;
                report_status_ok <= 1'b1;
                // A timeout may start UART while the corresponding frame is
                // still being processed. Keep the event pending while UART is
                // busy so the completed frame can be reported afterward.
                if (capture_pending) begin
                    report_timeout <= 1'b0;
                    timeout_reported <= 1'b0;
                    report_post_state <= st_post_state;
                    report_div_busy <= st_div_busy;
                    report_div_bit <= st_div_bit;
                    report_fill_stage <= st_fill_stage;
                    report_frame_toggle <= frame_toggle_sync;
                    report_div_active <= st_div_active;
                    report_div_load <= st_div_load;
                    report_div_index <= st_div_index;
                    report_divisor <= st_divisor;
                    report_div_quotient <= st_div_quotient;
                    report_div_remainder <= st_div_remainder;
                    report_div_sum <= st_div_sum;
                    report_accept_count <= done_accept_count;
                    report_capture_count <= done_capture_count;
                    report_y_min <= done_y_min;
                    report_y_max <= done_y_max;
                    report_input_y_sum <= done_input_y_sum;
                    report_bin_count_sum <= done_bin_count_sum;
                    report_bin_y_sum <= done_bin_y_sum;
                    report_zero_count_sum_errors <= done_zero_count_sum_errors;
                    report_first_zero_count_sum_error <= done_first_zero_count_sum_error;
                    report_nonzero_count_zero_sum_errors <=
                        done_nonzero_count_zero_sum_errors;
                    report_first_nonzero_count_zero_sum_error <=
                        done_first_nonzero_count_zero_sum_error;
                    report_division_errors <= done_division_errors;
                    report_first_division_error <= done_first_division_error;
                    report_first_division_error_sum <= done_first_division_error_sum;
                    report_first_division_error_count_value <=
                        done_first_division_error_count_value;
                    report_first_division_error_quotient <=
                        done_first_division_error_quotient;
                    report_first_division_error_remainder <=
                        done_first_division_error_remainder;
                    report_first_division_error_bit <= done_first_division_error_bit;
                    report_first_division_error_shift <= done_first_division_error_shift;
                    report_first_division_error_pre_rem <= done_first_division_error_pre_rem;
                    report_first_division_error_pre_q <= done_first_division_error_pre_q;
                    report_first_division_error_trial <= done_first_division_error_trial;
                    report_first_division_error_next_q <= done_first_division_error_next_q;
                    report_p7f_sum <= done_p7f_sum;
                    report_p7f_count <= done_p7f_count;
                    report_p7f_raw_y <= done_p7f_raw_y;
                    for (report_snapshot_index = 0; report_snapshot_index < 3;
                         report_snapshot_index = report_snapshot_index + 1) begin
                        report_dbg_sum[report_snapshot_index] <= done_dbg_sum[report_snapshot_index];
                        report_dbg_count[report_snapshot_index] <= done_dbg_count[report_snapshot_index];
                        report_dbg_avg[report_snapshot_index] <= done_dbg_avg[report_snapshot_index];
                        report_dbg_valid[report_snapshot_index] <= done_dbg_valid[report_snapshot_index];
                        report_pre_div_sum[report_snapshot_index] <= done_pre_div_sum[report_snapshot_index];
                        report_pre_div_count[report_snapshot_index] <= done_pre_div_count[report_snapshot_index];
                        report_pre_div_valid[report_snapshot_index] <= done_pre_div_valid[report_snapshot_index];
                    end
                    report_x_valid <= done_x_valid &&
                                      (done_first_x >= ROI_X_START) &&
                                      (done_first_x <= done_last_x) &&
                                      (done_last_x <= ROI_X_END);
                    report_first_x <= (done_x_valid &&
                                       (done_first_x >= ROI_X_START) &&
                                       (done_first_x <= done_last_x) &&
                                       (done_last_x <= ROI_X_END)) ?
                                      done_first_x : 16'hffff;
                    report_last_x <= (done_x_valid &&
                                      (done_first_x >= ROI_X_START) &&
                                      (done_first_x <= done_last_x) &&
                                      (done_last_x <= ROI_X_END)) ?
                                     done_last_x : 16'hffff;
                    report_snapshot_active <= 1'b1;
                    report_snapshot_wait <= 1'b0;
                    report_snapshot_bin_index <= 8'd0;
                    capture_pending <= 1'b0;
                    capture_wait_count <= {WAIT_WIDTH{1'b0}};
                end
            end else if (evt_ready) begin
                // R-2: a frame event that does not answer the pending request (stale frame, frame of an
                // abandoned request, or no request pending) is consumed and counted, never reported.
                frame_toggle_seen <= frame_toggle_sync;
                if (stale_drop != 8'hff) stale_drop <= stale_drop + 1'b1;
            end else if (tmo_start) begin
                // R-2: ask the video domain for a coherent status snapshot instead of sampling live buses.
                timeout_reported <= 1'b1;
                tq_req_sys <= ~tq_req_sys;
                tmo_state <= 2'd1;
                tmo_cnt <= 16'd0;
            end else if (tmo_go) begin
                // Always emit timeout diagnostics so a stalled post-process cannot silence UART.  If the
                // video domain does not acknowledge in time (no video clock) the status fields are zero
                // and STATUS_OK=0 is reported.
                tmo_state <= 2'd0;
                if (tq_ack_new) tq_ack_seen <= tq_ack_sync;
                report_req_drop <= req_drop;
                report_stale_drop <= stale_drop;
                report_hs_cnt <= fm_report;
                report_status_ok <= tq_ack_new;
                capture_pending <= 1'b0;
                capture_wait_count <= {WAIT_WIDTH{1'b0}};
                report_timeout <= 1'b1;
                report_post_state <= tq_ack_new ? tq_post_state : ~9'd0;
                report_div_busy <= tq_ack_new ? tq_div_busy : ~1'd0;
                report_div_bit <= tq_ack_new ? tq_div_bit : ~6'd0;
                report_fill_stage <= tq_ack_new ? tq_fill_stage : ~3'd0;
                report_frame_toggle <= frame_toggle_sync;
                report_div_active <= tq_ack_new ? tq_div_active : ~1'd0;
                report_div_load <= tq_ack_new ? tq_div_load : ~1'd0;
                report_div_index <= tq_ack_new ? tq_div_index : ~8'd0;
                report_divisor <= tq_ack_new ? tq_divisor : ~16'd0;
                report_div_quotient <= tq_ack_new ? tq_div_quotient : ~16'd0;
                report_div_remainder <= tq_ack_new ? tq_div_remainder : ~32'd0;
                report_div_sum <= tq_ack_new ? tq_div_sum : ~32'd0;
                report_accept_count <= tq_ack_new ? tq_capture_count : ~32'd0;
                report_capture_count <= tq_ack_new ? tq_capture_count : ~32'd0;
                report_y_min <= tq_ack_new ? tq_y_min : ~16'd0;
                report_y_max <= tq_ack_new ? tq_y_max : ~16'd0;
                report_input_y_sum <= tq_ack_new ? tq_y_sum : ~32'd0;
                report_bin_count_sum <= tq_ack_new ? tq_bin_count_sum : ~32'd0;
                report_bin_y_sum <= tq_ack_new ? tq_bin_y_sum : ~32'd0;
                report_zero_count_sum_errors <= 8'hff;
                report_first_zero_count_sum_error <= 8'hff;
                report_nonzero_count_zero_sum_errors <= 8'hff;
                report_first_nonzero_count_zero_sum_error <= 8'hff;
                report_division_errors <= 8'hff;
                report_first_division_error <= 8'hff;
                report_first_division_error_sum <= 32'd0;
                report_first_division_error_count_value <= 16'd0;
                report_first_division_error_quotient <= 16'd0;
                report_first_division_error_remainder <= 17'd0;
                report_first_division_error_bit <= 6'd0;
                report_first_division_error_shift <= 32'd0;
                report_first_division_error_pre_rem <= 17'd0;
                report_first_division_error_pre_q <= 32'd0;
                report_first_division_error_trial <= 17'd0;
                report_first_division_error_next_q <= 32'd0;
                if (TIMEOUT_LIVE_DUMP != 0) begin
                report_p7f_sum <= bin_sum_y[127];
                report_p7f_count <= bin_count_y[127];
                report_p7f_raw_y <= raw_average_y_mem[127];
                report_pre_div_sum[0] <= pre_div_sum[0];
                report_pre_div_sum[1] <= pre_div_sum[1];
                report_pre_div_sum[2] <= pre_div_sum[2];
                report_pre_div_count[0] <= pre_div_count[0];
                report_pre_div_count[1] <= pre_div_count[1];
                report_pre_div_count[2] <= pre_div_count[2];
                report_pre_div_valid[0] <= pre_div_valid[0];
                report_pre_div_valid[1] <= pre_div_valid[1];
                report_pre_div_valid[2] <= pre_div_valid[2];
                report_dbg_sum[0] <= bin_sum_y[1];
                report_dbg_sum[1] <= bin_sum_y[15];
                report_dbg_sum[2] <= bin_sum_y[62];
                report_dbg_count[0] <= bin_count_y[1];
                report_dbg_count[1] <= bin_count_y[15];
                report_dbg_count[2] <= bin_count_y[62];
                report_dbg_avg[0] <= raw_average_y_mem[1];
                report_dbg_avg[1] <= raw_average_y_mem[15];
                report_dbg_avg[2] <= raw_average_y_mem[62];
                report_dbg_valid[0] <= (bin_count_y[1] != 0);
                report_dbg_valid[1] <= (bin_count_y[15] != 0);
                report_dbg_valid[2] <= (bin_count_y[62] != 0);
                report_x_valid <= capture_x_valid &&
                                  (capture_first_x >= ROI_X_START) &&
                                  (capture_first_x <= capture_last_x) &&
                                  (capture_last_x <= ROI_X_END);
                report_first_x <= (capture_x_valid &&
                                   (capture_first_x >= ROI_X_START) &&
                                   (capture_first_x <= capture_last_x) &&
                                   (capture_last_x <= ROI_X_END)) ?
                                  capture_first_x : 16'hffff;
                report_last_x <= (capture_x_valid &&
                                  (capture_first_x >= ROI_X_START) &&
                                  (capture_first_x <= capture_last_x) &&
                                  (capture_last_x <= ROI_X_END)) ?
                                 capture_last_x : 16'hffff;
                for (report_snapshot_index = 0;
                     report_snapshot_index < SAMPLE_COUNT;
                     report_snapshot_index = report_snapshot_index + 1) begin
                    report_count_mem[report_snapshot_index] <=
                        bin_count_y[report_snapshot_index];
                    report_sum_mem[report_snapshot_index] <=
                        bin_sum_y[report_snapshot_index];
                    report_raw_y_mem[report_snapshot_index] <=
                        raw_average_y_mem[report_snapshot_index];
                    // No completed frame result exists; do not report stale data.
                    report_final_y_mem[report_snapshot_index] <= 16'hffff;
                    report_raw_valid_mem[report_snapshot_index] <=
                        (bin_count_y[report_snapshot_index] != 0) &&
                        (raw_average_y_mem[report_snapshot_index] >= ROI_Y_START) &&
                        (raw_average_y_mem[report_snapshot_index] <= ROI_Y_END);
                    report_final_valid_mem[report_snapshot_index] <= 1'b0;
                    if (report_snapshot_index < 32) begin
                        report_raw_valid_word[report_snapshot_index] <=
                            (bin_count_y[report_snapshot_index] != 0) &&
                            (raw_average_y_mem[report_snapshot_index] >= ROI_Y_START) &&
                            (raw_average_y_mem[report_snapshot_index] <= ROI_Y_END);
                        report_final_valid_word[report_snapshot_index] <= 1'b0;
                    end
                end
                end else begin
                report_p7f_sum <= 32'hffffffff;
                report_p7f_count <= 16'hffff;
                report_p7f_raw_y <= 16'hffff;
                for (report_snapshot_index = 0; report_snapshot_index < 3;
                     report_snapshot_index = report_snapshot_index + 1) begin
                    report_pre_div_sum[report_snapshot_index] <= 32'hffffffff;
                    report_pre_div_count[report_snapshot_index] <= 16'hffff;
                    report_pre_div_valid[report_snapshot_index] <= 1'b0;
                    report_dbg_sum[report_snapshot_index] <= 32'hffffffff;
                    report_dbg_count[report_snapshot_index] <= 16'hffff;
                    report_dbg_avg[report_snapshot_index] <= 16'hffff;
                    report_dbg_valid[report_snapshot_index] <= 1'b0;
                end
                report_x_valid <= 1'b0;
                report_first_x <= 16'hffff;
                report_last_x <= 16'hffff;
                for (report_snapshot_index = 0; report_snapshot_index < SAMPLE_COUNT;
                     report_snapshot_index = report_snapshot_index + 1) begin
                    report_count_mem[report_snapshot_index] <= 16'hffff;
                    report_sum_mem[report_snapshot_index] <= 32'hffffffff;
                    report_raw_y_mem[report_snapshot_index] <= 16'hffff;
                    report_final_y_mem[report_snapshot_index] <= 16'hffff;
                    report_raw_valid_mem[report_snapshot_index] <= 1'b0;
                    report_final_valid_mem[report_snapshot_index] <= 1'b0;
                    if (report_snapshot_index < 32) begin
                        report_raw_valid_word[report_snapshot_index] <= 1'b0;
                        report_final_valid_word[report_snapshot_index] <= 1'b0;
                    end
                end
                end
                report_active <= 1'b1;
                report_pos <= {REPORT_POS_WIDTH{1'b0}};
            end

            if (!tx_active) begin
                baud_count <= 16'd0;
                if (key_ack_active) begin
                    tx_is_ack <= 1'b1;
                    tx_shift <= {1'b1, key_ack_byte, 1'b0};
                    tx_bit_count <= 4'd0;
                    tx_active <= 1'b1;
                    if (key_ack_pos == 3'd4)
                        key_ack_active <= 1'b0;
                    else
                        key_ack_pos <= key_ack_pos + 1'b1;
                end else if (report_active) begin
                    tx_is_ack <= 1'b0;
                    tx_shift <= {1'b1, tx_byte, 1'b0};
                    tx_bit_count <= 4'd0;
                    tx_active <= 1'b1;
                    if (report_pos == REPORT_BYTES - 1) begin
                        report_active <= 1'b0;
                    end else begin
                        report_pos <= report_pos + 1'b1;
                    end
                end else if (key_ack_pending) begin
                    key_ack_active <= 1'b1;
                    key_ack_pending <= 1'b0;
                    key_ack_pos <= 3'd0;
                end
            end else if (BYTE_TAP != 0) begin
                if (I_byte_ready) tx_active <= 1'b0;   // C-06: byte taken by the mux
            end else if (baud_count == BAUD_DIV - 1) begin
                baud_count <= 16'd0;
                if (tx_bit_count == 4'd9) begin
                    tx_active <= 1'b0;
                    tx_bit_count <= 4'd0;
                end else begin
                    tx_shift <= {1'b1, tx_shift[9:1]};
                    tx_bit_count <= tx_bit_count + 1'b1;
                end
            end else begin
                baud_count <= baud_count + 1'b1;
            end
        end
    end

    assign O_uart_tx = (BYTE_TAP != 0) ? 1'b1 : (tx_active ? tx_shift[0] : 1'b1);
    // C-06 tap interface.  Report and acknowledge are presented to the mux as two sources, strictly in the order A's engine emits them
    // (the engine gives the acknowledge priority over a report that started meanwhile): a request rises only when its bytes are next,
    // so the mux can never grant the source whose bytes are not at the head of the single byte slot.
    wire tap_ack_busy = key_ack_active | (tx_active & tx_is_ack);
    assign O_tap_valid     = (BYTE_TAP != 0) & tx_active;
    assign O_tap_data      = tx_shift[8:1];
    assign O_tap_is_ack    = tx_is_ack;
    assign O_tap_rpt_req   = (BYTE_TAP != 0) & report_active & ~tap_ack_busy;
    assign O_tap_ack_req   = (BYTE_TAP != 0) & tap_ack_busy;
    assign O_tap_rpt_len   = REPORT_BYTES;
    assign O_tap_req_drop  = req_drop;
    assign O_tap_stale_drop = stale_drop;
    assign O_report_busy = report_active | tx_active | key_ack_active;

endmodule
