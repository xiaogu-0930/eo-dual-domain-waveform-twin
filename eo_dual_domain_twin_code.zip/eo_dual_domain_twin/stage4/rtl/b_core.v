`timescale 1ns/1ps
// Automatic-frequency streaming I/Q detection. TX only, no external F0 command.
module b_core #(
 parameter integer SYSCLK_HZ=25000000,
 parameter integer ADC_HALF_DIV=4,
 parameter integer UART_BAUD=115200,
 parameter integer MIN_FREQUENCY_HZ=200,
 parameter integer MAX_FREQUENCY_HZ=50000,
 parameter integer FREQUENCY_PERIODS=64,
 parameter integer CAL_LOG2=16,
 parameter integer ANALYSIS_PERIODS=16,
 parameter integer MIN_ANALYSIS_SAMPLES=SYSCLK_HZ/(2*ADC_HALF_DIV*50),
 parameter integer REPORT_CYCLES=37500000,
 parameter integer PEAK_TO_CENTIVOLT_Q16=63015,
 parameter integer REVERSE_BIT_ORDER=1,
 parameter integer SERVO_POINT_GAP_CYCLES=1250000)(
 input wire sys_clk, input wire rst_n, input wire key4, output wire adc_clk,
 input wire [11:0] adc_d,
 output wire servo_tx, input wire servo_rx,
 // Stage 7: work mode (0 camera->DAC, 1 AD->servo, 2 camera->servo) and the camera one-period table (cam_period_table)
 input wire [1:0] i_mode, input wire [383:0] i_cam_points_flat, input wire i_cam_new, input wire i_cam_valid,
 // C-07: byte taps for the shared T25 UART (packet request = generator busy, rising edge = new packet; lengths are constants in the top)
 output wire sum_req, output wire sum_valid, output wire [7:0] sum_data, input wire sum_ready,
 output wire trc_req, output wire trc_valid, output wire [7:0] trc_data, input wire trc_ready,
 // C-07: scope data (sys_clk domain registers; published with bank/toggle exactly as in B) -> b_scope_core
 output wire [767:0] o_scope_wave0_flat, output wire [767:0] o_scope_wave1_flat, output wire o_scope_bank, output wire o_scope_toggle,
 output wire [23:0] o_scope_frequency_x10, output wire [15:0] o_scope_amplitude_cv, output wire [79:0] o_scope_harmonics_cv,
 output wire [39:0] o_scope_harmonic_heights, output wire [2:0] o_scope_wave_type, output wire [2:0] o_scope_status);
 localparam integer SAMPLE_HZ=SYSCLK_HZ/(2*ADC_HALF_DIV);
 wire run_rst_n=rst_n;   // C-07: was a local power-up shift register; now merge_reset O_b_rst_n
 reg key4_meta,key4_sync,key4_stable;
 reg [19:0] key4_count;
 reg plot_mode;
 wire key4_press=key4_stable && !key4_sync && (key4_count==20'd499999);
 always @(posedge sys_clk) begin
  if(!run_rst_n) begin
   key4_meta<=1'b1; key4_sync<=1'b1; key4_stable<=1'b1;
   key4_count<=0; plot_mode<=1'b0;
  end else begin
   key4_meta<=key4;
   key4_sync<=key4_meta;
   if(key4_sync==key4_stable) key4_count<=0;
   else if(key4_count==20'd499999) begin
    key4_stable<=key4_sync;
    key4_count<=0;
   end else key4_count<=key4_count+1'b1;
   if(key4_press) plot_mode<=~plot_mode;
  end
 end
 wire sample_valid;
 wire [11:0] sample_data;
 adc_interface #(.HALF_DIV(ADC_HALF_DIV),.REVERSE_BIT_ORDER(REVERSE_BIT_ORDER)) adc
 (.sys_clk(sys_clk),.rst_n(run_rst_n),.adc_d(adc_d),.adc_clk(adc_clk),
  .sample_valid(sample_valid),.sample_data(sample_data));
 reg [11:0] scope_wave0[0:63],scope_wave1[0:63];
 reg [63:0] scope_valid0,scope_valid1;
 reg scope_capture_bank,scope_published_bank,scope_capture_ready;
 wire [767:0] scope_wave0_flat,scope_wave1_flat,scope_wave_flat;
 reg [11:0] scope_dc_mean;
 genvar scope_g;
 generate for(scope_g=0;scope_g<64;scope_g=scope_g+1) begin: pack_scope_wave
  assign scope_wave0_flat[scope_g*12 +: 12]=scope_valid0[scope_g]?
   scope_wave0[scope_g]:scope_dc_mean;
  assign scope_wave1_flat[scope_g*12 +: 12]=scope_valid1[scope_g]?
   scope_wave1[scope_g]:scope_dc_mean;
 end endgenerate
 assign scope_wave_flat=scope_published_bank?scope_wave1_flat:scope_wave0_flat;
 reg [23:0] scope_frequency_x10;
 reg [15:0] scope_amplitude_cv;
 reg [79:0] scope_harmonics_cv;
 reg [39:0] scope_harmonic_heights;
 reg [2:0] scope_wave_type,scope_status;
 reg scope_commit_toggle;
 wire [15:0] scope_h1_cv,scope_h2_cv,scope_h3_cv,scope_h4_cv,scope_h5_cv;
 function [15:0] counts_to_cv;
  input [15:0] counts;
  reg [31:0] product;
  begin
   product=counts*PEAK_TO_CENTIVOLT_Q16;
   counts_to_cv=(product+32'd32768)>>16;
  end
 endfunction
 function [7:0] cv_to_bar_height;
  input [15:0] value;
  reg [18:0] scaled;
  begin
   // About 36 pixels per volt, capped to the 240-pixel spectrum plot.
   scaled=(value*8'd23)>>6;
   cv_to_bar_height=(scaled>230)?8'd230:scaled[7:0];
  end
 endfunction
 // C-07: B's own HDMI PLL, pixel/serial reset logic, hdmi_scope_fast and hdmi_tx removed here: the merged display top owns them.
 assign o_scope_wave0_flat=scope_wave0_flat; assign o_scope_wave1_flat=scope_wave1_flat;
 assign o_scope_bank=scope_published_bank; assign o_scope_toggle=scope_commit_toggle;
 assign o_scope_frequency_x10=scope_frequency_x10; assign o_scope_amplitude_cv=scope_amplitude_cv;
 assign o_scope_harmonics_cv=scope_harmonics_cv; assign o_scope_harmonic_heights=scope_harmonic_heights;
 assign o_scope_wave_type=scope_wave_type; assign o_scope_status=scope_status;
 localparam WARM=0,FREQ_START=1,FREQ_WAIT=2,CLEAR=3,ANALYZE=4,
  FINISH_IQ=5,MAG_START=6,MAG_WAIT=7,CLASSIFY_START=8,
  CLASSIFY_WAIT=9,PRINT_START=10,PRINT_WAIT=11,WAIT_FRAME=12,
  BUILD_TRACE=13,TRACE_START=14,TRACE_WAIT=15;
 reg [3:0] state;
 reg [4:0] warm_count;
 reg [31:0] report_count;
 wire frequency_busy,frequency_done;
 wire [2:0] frequency_status;
 wire [23:0] measured_frequency;
 wire [31:0] increment;
 wire [11:0] dc_mean;
 auto_frequency #(.SAMPLE_HZ(SAMPLE_HZ),.MIN_HZ(MIN_FREQUENCY_HZ),
  .MAX_HZ(MAX_FREQUENCY_HZ),.CAL_LOG2(CAL_LOG2),.PERIODS(FREQUENCY_PERIODS)) frequency
 (.clk(sys_clk),.rst_n(run_rst_n),.start(state==FREQ_START),
  .sample_valid(sample_valid),.sample_data(sample_data),.busy(frequency_busy),
  .done(frequency_done),.status(frequency_status),.frequency_x10(measured_frequency),
  .phase_increment(increment),.dc_mean(dc_mean));
 reg [2:0] status;
 reg [23:0] frequency_x10,sample_count;
 reg [15:0] completed_periods;
 reg [11:0] wave_min,wave_max;
 reg [15:0] wave_pp;
 reg clipped;
 reg [2:0] harmonic_index;
 reg [15:0] h1_amplitude,h2_amplitude,h3_amplitude,h4_amplitude,h5_amplitude;
 assign scope_h1_cv=counts_to_cv(h1_amplitude);
 assign scope_h2_cv=counts_to_cv(h2_amplitude);
 assign scope_h3_cv=counts_to_cv(h3_amplitude);
 assign scope_h4_cv=counts_to_cv(h4_amplitude);
 assign scope_h5_cv=counts_to_cv(h5_amplitude);
 reg [11:0] raw_points[0:31],fund_points[0:31];
 reg [31:0] raw_seen;
 reg [4:0] trace_build_index;
 reg frame_mode;
 // Retain internal phase for future reconstruction, but do not print it.
 reg [11:0] h1_phase,h2_phase,h3_phase,h4_phase,h5_phase;
 wire iq_clear=(state==CLEAR);
 wire iq_valid=(state==ANALYZE && sample_valid);
 wire signed [12:0] centered_sample=$signed({1'b0,sample_data})-$signed({1'b0,dc_mean});
 wire [31:0] phase1,phase2,phase3,phase4,phase5;
 wire [32:0] next_phase={1'b0,phase1}+{1'b0,increment};
 wire signed [15:0] trace_sine,trace_cosine;
 sincos_rom trace_sine_rom(.address({trace_build_index,3'b000}),
  .sine(trace_sine),.cosine(trace_cosine));
 wire signed [32:0] trace_sine_product=$signed({1'b0,h1_amplitude})*trace_sine;
 wire signed [31:0] trace_sum=$signed({1'b0,dc_mean})+(trace_sine_product>>>15);
 wire [11:0] fund_trace_value=(trace_sum<0)?12'd0:
  (trace_sum>4095)?12'd4095:trace_sum[11:0];
 nco osc1 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),.enable(iq_valid),
  .phase_increment(increment),.phase(phase1));
 nco osc2 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),.enable(iq_valid),
  .phase_increment(increment<<1),.phase(phase2));
 nco osc3 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),.enable(iq_valid),
  .phase_increment(increment+(increment<<1)),.phase(phase3));
 nco osc4 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),.enable(iq_valid),
  .phase_increment(increment<<2),.phase(phase4));
 nco osc5 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),.enable(iq_valid),
  .phase_increment(increment+(increment<<2)),.phase(phase5));
 wire signed [47:0] i1,q1,i2,q2,i3,q3,i4,q4,i5,q5;
 iq_detector det1 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),
  .sample_valid(iq_valid),.sample(centered_sample),.phase(phase1),.i_acc(i1),.q_acc(q1));
 iq_detector det2 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),
  .sample_valid(iq_valid),.sample(centered_sample),.phase(phase2),.i_acc(i2),.q_acc(q2));
 iq_detector det3 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),
  .sample_valid(iq_valid),.sample(centered_sample),.phase(phase3),.i_acc(i3),.q_acc(q3));
 iq_detector det4 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),
  .sample_valid(iq_valid),.sample(centered_sample),.phase(phase4),.i_acc(i4),.q_acc(q4));
 iq_detector det5 (.clk(sys_clk),.rst_n(run_rst_n),.clear(iq_clear),
  .sample_valid(iq_valid),.sample(centered_sample),.phase(phase5),.i_acc(i5),.q_acc(q5));
 wire signed [47:0] selected_i=(harmonic_index==0)?i1:(harmonic_index==1)?i2:
  (harmonic_index==2)?i3:(harmonic_index==3)?i4:i5;
 wire signed [47:0] selected_q=(harmonic_index==0)?q1:(harmonic_index==1)?q2:
  (harmonic_index==2)?q3:(harmonic_index==3)?q4:q5;
 wire mag_busy,mag_done;
 wire [15:0] mag_amplitude;
 wire [11:0] mag_phase;
 wire classifier_valid;
 wire [2:0] classified_type;
 wire [2:0] report_type=(status==0)?classified_type:3'd4;
 waveform_classifier classifier (.clk(sys_clk),.rst_n(run_rst_n),
  .analyze(state==CLASSIFY_START),.metrics_valid(status==0),.clipped(clipped),
  .h1(h1_amplitude),.h2(h2_amplitude),.h3(h3_amplitude),
  .h4(h4_amplitude),.h5(h5_amplitude),
  .result_valid(classifier_valid),.wave_type(classified_type));
 magnitude_dynamic polar (.clk(sys_clk),.rst_n(run_rst_n),.start(state==MAG_START),
  .i_value(selected_i),.q_value(selected_q),.sample_count(sample_count),
  .busy(mag_busy),.done(mag_done),.amplitude(mag_amplitude),.phase_tenths(mag_phase));
 wire print_busy,print_done,trace_busy,trace_done;
 wire servo_busy,servo_done;
 reg trace_done_latched,servo_done_latched;
 assign sum_req=print_busy; assign trc_req=trace_busy;   // C-07: the two generators are separate sources of the T25 mux
 wire [383:0] trace_points_flat;
 genvar trace_g;
 generate for(trace_g=0;trace_g<32;trace_g=trace_g+1) begin: pack_trace_points
  assign trace_points_flat[trace_g*12 +: 12]=frame_mode?raw_points[trace_g]:fund_points[trace_g];
 end endgenerate
 uart_printf #(.CLK_HZ(SYSCLK_HZ),.BAUD(UART_BAUD),
  .PEAK_TO_CENTIVOLT_Q16(PEAK_TO_CENTIVOLT_Q16)) printer
 (.clk(sys_clk),.rst_n(run_rst_n),.start(state==PRINT_START),.status(status),
  .wave_type(report_type),
  .plot_mode(plot_mode),
  .frequency_x10(frequency_x10),.wave_pp(wave_pp),
  .h1_a(h1_amplitude),.h2_a(h2_amplitude),.h3_a(h3_amplitude),
  .h4_a(h4_amplitude),.h5_a(h5_amplitude),
  .byte_valid(sum_valid),.byte_data(sum_data),.byte_ready(sum_ready),.busy(print_busy),.done(print_done));
 trajectory_uart #(.CLK_HZ(SYSCLK_HZ),.BAUD(UART_BAUD)) trace_printer
 (.clk(sys_clk),.rst_n(run_rst_n),.start(state==TRACE_START),
  .plot_mode(frame_mode),.points_flat(trace_points_flat),
  .byte_valid(trc_valid),.byte_data(trc_data),.byte_ready(trc_ready),.busy(trace_busy),.done(trace_done));
 // Stage 7: servo source select.  mode 1 (AD) = B original; mode 2 (camera) = draw the camera one-period table after every new capture
 // (and once when the mode is entered with a valid table), as soon as the servo is idle; mode 0 = servo not driven.
 wire servo_mode_ad  = (i_mode==2'd1);
 wire servo_mode_cam = (i_mode==2'd2);
 reg cam_pending; reg [1:0] mode_d;
 wire cam_start_pulse = servo_mode_cam && cam_pending && !servo_busy;
 wire mode_enter_cam  = servo_mode_cam && (mode_d!=2'd2);
 always @(posedge sys_clk) begin
  if(!run_rst_n) begin cam_pending<=1'b0; mode_d<=2'd0; end
  else begin
   mode_d<=i_mode;
   if(!servo_mode_cam) cam_pending<=1'b0;
   else if(i_cam_valid && (i_cam_new || mode_enter_cam)) cam_pending<=1'b1;
   else if(cam_start_pulse) cam_pending<=1'b0;
  end
 end
 wire servo_start = servo_mode_ad ? (state==TRACE_START) : cam_start_pulse;
 wire [383:0] servo_points = servo_mode_cam ? i_cam_points_flat : trace_points_flat;
 wire [11:0] servo_dc = servo_mode_cam ? 12'd2048 : dc_mean;
 servo_plot_uart #(.CLK_HZ(SYSCLK_HZ),.BAUD(UART_BAUD),
  .POINT_GAP_CYCLES(SERVO_POINT_GAP_CYCLES)) servo_plotter
 (.clk(sys_clk),.rst_n(run_rst_n),.start(servo_start),
  .points_flat(servo_points),.dc_mean(servo_dc),.servo_rx(servo_rx),
  .tx(servo_tx),.busy(servo_busy),.done(servo_done));
 always @(posedge sys_clk) begin
  if(!run_rst_n) begin
   state<=WARM; warm_count<=0; report_count<=0; status<=0;
   trace_done_latched<=0; servo_done_latched<=0;
   raw_seen<=0; trace_build_index<=0; frame_mode<=0;
   scope_valid0<=0; scope_valid1<=0; scope_capture_bank<=1'b1;
   scope_published_bank<=1'b0; scope_capture_ready<=1'b0; scope_dc_mean<=12'd2048;
   scope_frequency_x10<=0; scope_amplitude_cv<=0; scope_harmonics_cv<=0;
   scope_harmonic_heights<=0;
   scope_wave_type<=3'd4; scope_status<=3'd4; scope_commit_toggle<=0;
   frequency_x10<=0; sample_count<=0; completed_periods<=0;
   wave_min<=4095; wave_max<=0; wave_pp<=0; clipped<=0; harmonic_index<=0;
   h1_amplitude<=0; h2_amplitude<=0; h3_amplitude<=0;
   h4_amplitude<=0; h5_amplitude<=0;
   h1_phase<=0; h2_phase<=0; h3_phase<=0; h4_phase<=0; h5_phase<=0;
  end else begin
   if(report_count<REPORT_CYCLES-1) report_count<=report_count+1'b1;
   case(state)
    WARM: if(sample_valid) begin
     if(warm_count==15) state<=FREQ_START;
     else warm_count<=warm_count+1'b1;
    end
    FREQ_START: begin
     report_count<=0; frequency_x10<=0; wave_pp<=0; status<=0;
     h1_amplitude<=0; h2_amplitude<=0; h3_amplitude<=0;
     h4_amplitude<=0; h5_amplitude<=0;
     h1_phase<=0; h2_phase<=0; h3_phase<=0; h4_phase<=0; h5_phase<=0;
     state<=FREQ_WAIT;
    end
    FREQ_WAIT: if(frequency_done) begin
     status<=frequency_status;
     if(frequency_status==0) begin frequency_x10<=measured_frequency; state<=CLEAR; end
     else state<=PRINT_START;
    end
    CLEAR: begin
     sample_count<=0; completed_periods<=0; wave_min<=4095; wave_max<=0;
     raw_seen<=0; clipped<=0; scope_capture_bank<=~scope_published_bank;
     scope_capture_ready<=1'b1;
     if(scope_published_bank) scope_valid0<=0;
     else scope_valid1<=0;
     state<=ANALYZE;
    end
    ANALYZE: if(sample_valid) begin
     sample_count<=sample_count+1'b1;
     if(scope_capture_bank) begin
      scope_wave1[phase1[31:26]]<=sample_data;
      scope_valid1[phase1[31:26]]<=1'b1;
     end else begin
      scope_wave0[phase1[31:26]]<=sample_data;
      scope_valid0[phase1[31:26]]<=1'b1;
     end
     if(!raw_seen[phase1[31:27]]) begin
      raw_points[phase1[31:27]]<=sample_data;
      raw_seen[phase1[31:27]]<=1'b1;
     end
     if(sample_data<wave_min) wave_min<=sample_data;
     if(sample_data>wave_max) wave_max<=sample_data;
     if(sample_data<=2 || sample_data>=4093) clipped<=1;
     if(next_phase[32]) begin
      completed_periods<=completed_periods+1'b1;
      // Minimum 16 periods AND 20 ms. End at the next NCO wrap.
      // The remaining noninteger-cycle boundary is <= one ADC sample.
      if(completed_periods>=ANALYSIS_PERIODS-1 && sample_count>=MIN_ANALYSIS_SAMPLES-1)
       state<=FINISH_IQ;
     end
    end
    FINISH_IQ: begin
      if(clipped) begin status<=4; wave_pp<=0; state<=PRINT_START; end
     else begin wave_pp<={4'b0,wave_max}-{4'b0,wave_min}; harmonic_index<=0; state<=MAG_START; end
    end
    MAG_START: state<=MAG_WAIT;
    MAG_WAIT: if(mag_done) begin
     case(harmonic_index)
      0: begin h1_amplitude<=mag_amplitude; h1_phase<=mag_phase; end
      1: begin h2_amplitude<=mag_amplitude; h2_phase<=mag_phase; end
      2: begin h3_amplitude<=mag_amplitude; h3_phase<=mag_phase; end
      3: begin h4_amplitude<=mag_amplitude; h4_phase<=mag_phase; end
      4: begin h5_amplitude<=mag_amplitude; h5_phase<=mag_phase; end
     endcase
     if(harmonic_index==4) state<=CLASSIFY_START;
     else begin harmonic_index<=harmonic_index+1'b1; state<=MAG_START; end
    end
    CLASSIFY_START: state<=CLASSIFY_WAIT;
    CLASSIFY_WAIT: if(classifier_valid) begin
     frame_mode<=plot_mode; trace_build_index<=0; state<=BUILD_TRACE;
    end
    BUILD_TRACE: begin
     fund_points[trace_build_index]<=fund_trace_value;
     if(trace_build_index==31) state<=PRINT_START;
     else trace_build_index<=trace_build_index+1'b1;
    end
    PRINT_START: state<=PRINT_WAIT;
    PRINT_WAIT: if(print_done) begin
     scope_frequency_x10<=frequency_x10;
     // Match the serial AMP field: both report the measured fundamental (H1).
     scope_amplitude_cv<=counts_to_cv(h1_amplitude);
     scope_harmonics_cv<={scope_h5_cv,scope_h4_cv,scope_h3_cv,
                          scope_h2_cv,scope_h1_cv};
     scope_harmonic_heights<={cv_to_bar_height(scope_h5_cv),
      cv_to_bar_height(scope_h4_cv),cv_to_bar_height(scope_h3_cv),
      cv_to_bar_height(scope_h2_cv),cv_to_bar_height(scope_h1_cv)};
     scope_wave_type<=report_type;
     scope_status<=status;
     scope_dc_mean<=dc_mean;
     scope_commit_toggle<=~scope_commit_toggle;
     if(scope_capture_ready) begin
      scope_published_bank<=scope_capture_bank;
      scope_capture_ready<=1'b0;
     end
     if(status==0) state<=TRACE_START;
     else state<=WAIT_FRAME;
    end
    TRACE_START: begin
     trace_done_latched<=0; servo_done_latched<=0; state<=TRACE_WAIT;
    end
    TRACE_WAIT: begin
     if(trace_done) trace_done_latched<=1'b1;
     if(servo_done) servo_done_latched<=1'b1;
     if((trace_done_latched || trace_done) &&
        (servo_done_latched || servo_done || !servo_mode_ad)) state<=servo_mode_ad ? FREQ_START : WAIT_FRAME;   // Stage 7: only mode 1 waits for the servo; other modes keep B's 1.5 s loop pace (UART load)
    end
    WAIT_FRAME: if(report_count>=REPORT_CYCLES-1) state<=FREQ_START;
    default: state<=WARM;
   endcase
  end
 end
endmodule


// C-07: module trajectory_uart removed from this file (byte-tap version: b_trajectory_uart_tap.v)

// Sends only actuator commands. Each target is held long enough to move.
module servo_plot_uart #(parameter integer CLK_HZ=25000000,
 parameter integer BAUD=115200, parameter integer POINT_GAP_CYCLES=1250000)(
 input wire clk,rst_n,start,
 input wire [383:0] points_flat,
 input wire [11:0] dc_mean,
 input wire servo_rx,
 output wire tx, output reg busy,done);
 reg [10:0] point_index;
 reg [10:0] cache_index;
 reg [5:0] character_index;
 reg [31:0] gap_count;
 reg uart_send;
 reg [7:0] uart_data;
 reg [2:0] state;
 reg reverse_scan;
 reg return_active;
 reg return_gap_start;
 reg [6:0] return_index;
 reg [13:0] forward_x_cache[0:1024];
 reg [13:0] forward_y_cache[0:1024];
 localparam [13:0] PAPER_CENTER_Y=14'd1575;
 wire uart_busy;
 wire [10:0] trajectory_index=reverse_scan?(11'd1024-point_index):point_index;
 wire [10:0] coordinate_index=(state==3'd5)?cache_index:trajectory_index;
 wire [7:0] cycle_phase_index=coordinate_index[7:0];
 wire [4:0] sample_index=cycle_phase_index[7:3];
 wire [4:0] next_sample_index=(sample_index==5'd31)?5'd0:(sample_index+1'b1);
 wire [4:0] prev_sample_index=(sample_index==5'd0)?5'd31:(sample_index-1'b1);
 wire [4:0] after_next_sample_index=(next_sample_index==5'd31)?5'd0:(next_sample_index+1'b1);
 wire [11:0] current_point=points_flat[sample_index*12 +: 12];
 wire [11:0] next_point=points_flat[next_sample_index*12 +: 12];
 wire [11:0] prev_point=points_flat[prev_sample_index*12 +: 12];
 wire [11:0] after_next_point=points_flat[after_next_sample_index*12 +: 12];
 function signed [31:0] catmull_interp;
  input [11:0] p0,p1,p2,p3;
  input [2:0] frac;
  reg signed [31:0] p0s,p1s,p2s,p3s;
  reg signed [31:0] a,b,c,k,numerator;
  begin
   p0s=$signed({1'b0,p0}); p1s=$signed({1'b0,p1});
   p2s=$signed({1'b0,p2}); p3s=$signed({1'b0,p3});
   a=-p0s+p2s;
   b=(2*p0s)-(5*p1s)+(4*p2s)-p3s;
   c=-p0s+(3*p1s)-(3*p2s)+p3s;
   k=$signed({29'd0,frac});
   numerator=(32'sd1024*p1s)+(32'sd64*a*k)+
    (32'sd8*b*k*k)+(c*k*k*k);
   catmull_interp=numerator/32'sd1024;
  end
 endfunction
 wire signed [31:0] cubic_point=catmull_interp(
  prev_point,current_point,next_point,after_next_point,cycle_phase_index[2:0]);
 wire [11:0] segment_min=(current_point<next_point)?current_point:next_point;
 wire [11:0] segment_max=(current_point>next_point)?current_point:next_point;
 wire [11:0] interpolated_point=(cubic_point<$signed({1'b0,segment_min}))?segment_min:
  (cubic_point>$signed({1'b0,segment_max}))?segment_max:cubic_point[11:0];
 // Map all 1024 intervals uniformly: each 256-interval period spans 115 units.
 wire [17:0] horizontal_uniform_product=coordinate_index*18'd230+18'd256;
 wire [9:0] horizontal_uniform_offset=horizontal_uniform_product[17:9];
 wire [13:0] calculated_servo_x=14'd1280+horizontal_uniform_offset;
 wire signed [13:0] y_delta=$signed({1'b0,interpolated_point})-$signed({1'b0,dc_mean});
 wire signed [13:0] y_scaled=y_delta/14'sd4;
 wire signed [13:0] y_limited=(y_scaled>14'sd195)?14'sd195:
  (y_scaled< -14'sd180)?-14'sd180:y_scaled;
 wire [13:0] calculated_servo_y=PAPER_CENTER_Y-y_limited;
 // Divide before multiplying to keep the intermediate below 32-bit overflow.
 localparam integer RETURN_GAP_CYCLES=(CLK_HZ/1000)*70;
 wire [5:0] return_local_step=(return_index<7'd6)?(return_index+7'd1):
  (return_index<7'd24)?(return_index-7'd5):
  (return_index<7'd31)?(return_index-7'd23):(return_index-7'd30);
 wire signed [31:0] return_y0_delta=32'sd1335-$signed({18'd0,forward_y_cache[0]});
 wire signed [31:0] return_y0_offset=(return_y0_delta*$signed({26'd0,return_local_step}))/32'sd6;
 wire signed [31:0] return_y0_position=$signed({18'd0,forward_y_cache[0]})+return_y0_offset;
 wire [13:0] return_y2_position=14'd1335+
  (((forward_y_cache[1024]-14'd1335)*return_local_step)/14'd7);
 wire [13:0] return_servo_x=(return_index<7'd6)?
  (forward_x_cache[0]-(((forward_x_cache[0]-14'd1260)*return_local_step)/14'd6)):
  (return_index<7'd24)?(14'd1260+((14'd540*return_local_step)/14'd18)):
  (return_index<7'd31)?14'd1800:forward_x_cache[1024];
 wire [13:0] return_servo_y=(return_index<7'd6)?return_y0_position[13:0]:
  (return_index<7'd24)?14'd1335:
  (return_index<7'd31)?return_y2_position:forward_y_cache[1024];
 wire [13:0] servo_x=return_active?return_servo_x:forward_x_cache[trajectory_index];
 wire [13:0] servo_y=return_active?return_servo_y:forward_y_cache[trajectory_index];
 wire unused_rx=servo_rx;
 uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) transmitter
  (.clk(clk),.rst_n(rst_n),.send(uart_send),.data(uart_data),.tx(tx),.busy(uart_busy));
 function [7:0] command_character;
  input [5:0] position;
  input [13:0] x_pos;
  input [12:0] y_pos;
  input slow_move;
  begin
   case(position)
    0: command_character="#"; 1: command_character="0";
    2: command_character="0"; 3: command_character="1";
    4: command_character="P";
    5: command_character=8'h30+(x_pos/1000);
    6: command_character=8'h30+((x_pos%1000)/100);
    7: command_character=8'h30+((x_pos%100)/10);
    8: command_character=8'h30+(x_pos%10);
    9: command_character="T";
    10: command_character="0"; 11: command_character="0";
    12: command_character=slow_move?"7":"5"; 13: command_character="0";
    14: command_character="!";
    15: command_character="#"; 16: command_character="0";
    17: command_character="0"; 18: command_character="2";
    19: command_character="P";
    20: command_character=8'h30+(y_pos/1000);
    21: command_character=8'h30+((y_pos%1000)/100);
    22: command_character=8'h30+((y_pos%100)/10);
    23: command_character=8'h30+(y_pos%10);
    24: command_character="T";
    25: command_character="0"; 26: command_character="0";
    27: command_character=slow_move?"7":"5"; 28: command_character="0";
    29: command_character="!";
    default: command_character=" ";
   endcase
  end
 endfunction
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0; busy<=0; done<=0; uart_send<=0; uart_data<=0; reverse_scan<=1;
   return_active<=0; return_gap_start<=0; return_index<=0;
   point_index<=0; cache_index<=0; character_index<=0; gap_count<=0;
  end else begin
   uart_send<=0; done<=0;
   case(state)
    0: if(start) begin
     point_index<=0; cache_index<=0; character_index<=0; gap_count<=0;
     return_active<=0; return_gap_start<=0; return_index<=0; busy<=1; state<=5;
    end
    1: if(!uart_busy) begin
     uart_data<=command_character(character_index,servo_x,servo_y,return_active);
     uart_send<=1; state<=2;
    end
    2: if(uart_busy) state<=3;
    3: if(!uart_busy) begin
     if(character_index==29) begin
      character_index<=0;
      if(return_active) begin
       if(return_index==7'd31) begin
        return_active<=0; return_gap_start<=0; busy<=0; done<=1; state<=0;
       end else begin gap_count<=0; return_gap_start<=0; state<=4; end
      end else if(point_index==11'd1024) begin
       return_active<=1; return_index<=0; return_gap_start<=1;
       gap_count<=0; state<=4;
      end
      else begin gap_count<=0; state<=4; end
     end else begin character_index<=character_index+1'b1; state<=1; end
    end
    4: if(gap_count>=(return_active?RETURN_GAP_CYCLES:POINT_GAP_CYCLES)-1) begin
     gap_count<=0;
     if(return_active) begin
      if(return_gap_start) return_gap_start<=0;
      else return_index<=return_index+1'b1;
     end else point_index<=point_index+1'b1;
     state<=1;
    end else gap_count<=gap_count+1'b1;
    5: begin
     forward_x_cache[cache_index]<=calculated_servo_x;
     forward_y_cache[cache_index]<=calculated_servo_y;
     if(cache_index==11'd1024) begin
      cache_index<=0; point_index<=0; character_index<=0; state<=1;
     end else cache_index<=cache_index+1'b1;
    end
    default: begin state<=0; busy<=0; end
   endcase
  end
 end
endmodule


// -----------------------------------------------------------------------------
// Bundled synthesis dependencies.
// TD 6.2 may keep an already-open project's old source-file list and rewrite
// AD_FFT.al before synthesis. Keeping these module definitions in the top-level
// source makes the design self-contained even in that situation. The separate
// files remain as readable/test sources and are excluded by run_sim.ps1.
// -----------------------------------------------------------------------------

// Unsigned restoring division: one compare/subtract per clock, no / operator.
// Inputs are latched on start. Zero denominator returns all ones.
module serial_divider #(parameter integer WIDTH=64)(
 input wire clk,rst_n,start,
 input wire [WIDTH-1:0] numerator,denominator,
 output reg busy,done, output reg [WIDTH-1:0] quotient);
 reg [WIDTH-1:0] dividend,divisor;
 reg [WIDTH:0] remainder;
 reg [7:0] remaining;
 wire [WIDTH:0] trial={remainder[WIDTH-1:0],dividend[WIDTH-1]};
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   dividend<=0; divisor<=0; remainder<=0; remaining<=0;
   quotient<=0; busy<=0; done<=0;
  end else begin
   done<=0;
   if(start && !busy) begin
    dividend<=numerator; divisor<=denominator; remainder<=0;
    remaining<=WIDTH; quotient<=0; busy<=1;
   end else if(busy) begin
    dividend<={dividend[WIDTH-2:0],1'b0};
    if(trial>={1'b0,divisor}) begin
     remainder<=trial-{1'b0,divisor};
     quotient<={quotient[WIDTH-2:0],1'b1};
    end else begin
     remainder<=trial; quotient<={quotient[WIDTH-2:0],1'b0};
    end
    if(remaining==1) begin busy<=0; done<=1; end
    else remaining<=remaining-1'b1;
   end
  end
 end
endmodule


// Automatic period estimator for a stationary, fundamental-dominated signal.
// Four-point smoothing, adaptive hysteresis, Q8 interpolated rising crossings,
// 64-period averaging and interval consistency checks. Not an FFT/search bank:
// a waveform with several consistent rising crossings per fundamental can alias.
// status: 0=OK, 1=low signal, 2=no stable period, 3=out of range, 4=clipped.
module auto_frequency #(
 parameter integer SAMPLE_HZ=3125000, MIN_HZ=200, MAX_HZ=50000,
 parameter integer CAL_LOG2=16, PERIODS=64,
 parameter integer TIMEOUT_SAMPLES=SAMPLE_HZ)(
 input wire clk,rst_n,start,sample_valid, input wire [11:0] sample_data,
 output reg busy,done, output reg [2:0] status,
 output reg [23:0] frequency_x10, output reg [31:0] phase_increment,
 output reg [11:0] dc_mean);
 localparam IDLE=0,CAL=1,FIND=2,FREQ_START=3,FREQ_WAIT=4,
  INC_START=5,INC_WAIT=6;
 reg [2:0] state;
 reg [11:0] d1,d2,d3;
 wire [13:0] smooth_sum={2'b0,sample_data}+{2'b0,d1}+{2'b0,d2}+{2'b0,d3};
 wire [11:0] smooth=smooth_sum[13:2];
 reg [CAL_LOG2-1:0] cal_count;
 reg [CAL_LOG2+11:0] cal_sum;
 reg [11:0] cal_min,cal_max;
 wire [CAL_LOG2+11:0] cal_total=cal_sum+smooth;
 wire [11:0] span=cal_max-cal_min;
 reg clipped,armed,seen;
 reg [11:0] hysteresis;
 wire signed [12:0] delta=$signed({1'b0,smooth})-$signed({1'b0,dc_mean});
 reg signed [12:0] previous;
 wire signed [12:0] neg_hysteresis=-$signed({1'b0,hysteresis});
 wire crossing=(state==FIND && sample_valid && armed && previous<0 && delta>=0);
 reg [23:0] sample_index,timeout_count;
 reg [31:0] cross_base,first_cross,last_cross,reference_period,period_span;
 reg [7:0] period_count;
 wire [12:0] negative_previous=-previous;
 wire [13:0] crossing_delta=$signed({delta[12],delta})-$signed({previous[12],previous});
 wire interpolation_busy,interpolation_done;
 wire [31:0] fraction;
 serial_divider #(.WIDTH(32)) interpolate
 (.clk(clk),.rst_n(rst_n),.start(crossing && !interpolation_busy),
  .numerator({11'b0,negative_previous,8'b0}),
  .denominator({18'b0,crossing_delta}),.busy(interpolation_busy),
  .done(interpolation_done),.quotient(fraction));
 wire [31:0] crossing_time=cross_base+fraction;
 wire [31:0] period_now=crossing_time-last_cross;
 // +/-25% individual period tolerance rejects many noise/double crossings.
 wire consistent=(period_now>=(reference_period-(reference_period>>2)) &&
                  period_now<=(reference_period+(reference_period>>2)));
 wire period_in_range=(period_now >= (SAMPLE_HZ*256/(MAX_HZ+MAX_HZ/4)) &&
                       period_now <= (SAMPLE_HZ*256/(MIN_HZ-MIN_HZ/4)));
 wire divide_done,divide_busy;
 wire [63:0] quotient;
 wire [63:0] numerator=(state==FREQ_START)?
  (64'd1*SAMPLE_HZ*PERIODS*256*10+(period_span>>1)):
  ((64'd1<<32)*PERIODS*256+(period_span>>1));
 serial_divider #(.WIDTH(64)) calculate
 (.clk(clk),.rst_n(rst_n),.start(state==FREQ_START || state==INC_START),
  .numerator(numerator),.denominator({32'b0,period_span}),
  .busy(divide_busy),.done(divide_done),.quotient(quotient));
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=IDLE; busy<=0; done<=0; status<=0; frequency_x10<=0;
   phase_increment<=0; dc_mean<=0; d1<=0; d2<=0; d3<=0;
   cal_count<=0; cal_sum<=0; cal_min<=4095; cal_max<=0; clipped<=0;
   armed<=0; seen<=0; hysteresis<=4; previous<=0;
   sample_index<=0; timeout_count<=0; cross_base<=0; first_cross<=0;
   last_cross<=0; reference_period<=0; period_span<=0; period_count<=0;
  end else begin
   done<=0;
   if(sample_valid) begin d1<=sample_data; d2<=d1; d3<=d2; end
   case(state)
    IDLE: if(start) begin
     busy<=1; status<=0; frequency_x10<=0; phase_increment<=0;
     cal_count<=0; cal_sum<=0; cal_min<=4095; cal_max<=0; clipped<=0;
     state<=CAL;
    end
    CAL: if(sample_valid) begin
     cal_sum<=cal_total;
     if(smooth<cal_min) cal_min<=smooth;
     if(smooth>cal_max) cal_max<=smooth;
     if(sample_data<=2 || sample_data>=4093) clipped<=1;
     if(&cal_count) begin
      dc_mean<=cal_total[CAL_LOG2+11:CAL_LOG2];
      hysteresis<=(span>>3)<4?12'd4:(span>>3);
      sample_index<=0; timeout_count<=0; armed<=0; seen<=0;
      previous<=0; period_count<=0;
      if(clipped || sample_data<=2 || sample_data>=4093) begin
       status<=4; busy<=0; done<=1; state<=IDLE;
      end else if(span<32) begin
       status<=1; busy<=0; done<=1; state<=IDLE;
      end else state<=FIND;
     end else cal_count<=cal_count+1'b1;
    end
    FIND: begin
     if(sample_valid) begin
      sample_index<=sample_index+1'b1; timeout_count<=timeout_count+1'b1;
      previous<=delta;
      if(delta<neg_hysteresis) armed<=1;
      if(crossing) begin
       armed<=0; cross_base<={(sample_index-24'd1),8'b0};
      end
     end
     if(sample_valid && timeout_count>=TIMEOUT_SAMPLES-1) begin
      status<=2; busy<=0; done<=1; state<=IDLE;
     end else if(interpolation_done) begin
      last_cross<=crossing_time;
      if(!seen) begin
       seen<=1; first_cross<=crossing_time; period_count<=0;
      end else if(!period_in_range || (period_count!=0 && !consistent)) begin
       // Restart from this crossing. Never label an unstable train as locked.
       first_cross<=crossing_time; period_count<=0;
      end else begin
       if(period_count==0) reference_period<=period_now;
       if(period_count==PERIODS-1) begin
        period_span<=crossing_time-first_cross; state<=FREQ_START;
       end else period_count<=period_count+1'b1;
      end
     end
    end
    FREQ_START: state<=FREQ_WAIT;
    FREQ_WAIT: if(divide_done) begin
     // 2% boundary guard prevents measurement noise at 200 Hz/50 kHz
     // from alternating OK/out-of-range. The supported nominal band is fixed.
     if(quotient<MIN_HZ*10-MIN_HZ/5 || quotient>MAX_HZ*10+MAX_HZ/5) begin
      status<=3; busy<=0; done<=1; state<=IDLE;
     end else begin frequency_x10<=quotient[23:0]; state<=INC_START; end
    end
    INC_START: state<=INC_WAIT;
    INC_WAIT: if(divide_done) begin
     phase_increment<=quotient[31:0]; busy<=0; done<=1; state<=IDLE;
    end
    default: begin state<=IDLE; busy<=0; end
   endcase
  end
 end
endmodule


// Full-precision vectoring CORDIC, then serial restoring normalization
// using the actual sample count. Round only at the final amplitude output.
module magnitude_dynamic(
 input wire clk,rst_n,start,
 input wire signed [47:0] i_value,q_value,
 input wire [23:0] sample_count,
 output reg busy,done, output reg [15:0] amplitude,
 output reg [11:0] phase_tenths);
 reg [2:0] state;
 reg [4:0] iteration;
 reg signed [49:0] x,y;
 reg [31:0] angle;
 reg [23:0] count_latched;
 wire signed [49:0] ie={{2{i_value[47]}},i_value};
 wire signed [49:0] qe={{2{q_value[47]}},q_value};
 // 39797/65536 is the reciprocal CORDIC gain (0.60725).
 // Corrected numerator = 2*|IQ|/32768 = A * sample_count.
 wire [65:0] product=$unsigned(x)*16'd39797;
 wire [65:0] rounded_product=product+66'd536870912;
 wire [39:0] area={4'b0,rounded_product[65:30]};
 wire div_done,div_busy;
 wire [39:0] quotient;
 serial_divider #(.WIDTH(40)) normalize
 (.clk(clk),.rst_n(rst_n),.start(state==3),
  .numerator(area+{17'b0,count_latched[23:1]}),
  .denominator({16'b0,count_latched}),.busy(div_busy),
  .done(div_done),.quotient(quotient));
 wire [47:0] angle_product=angle*16'd3600;
 wire [47:0] angle_rounded=angle_product+48'd2147483648;
 function [31:0] arctan_turns;
  input [4:0] k;
  begin case(k)
   0: arctan_turns=32'h20000000; 1: arctan_turns=32'h12e4051e;
   2: arctan_turns=32'h09fb385b; 3: arctan_turns=32'h051111d4;
   4: arctan_turns=32'h028b0d43; 5: arctan_turns=32'h0145d7e1;
   6: arctan_turns=32'h00a2f61e; 7: arctan_turns=32'h00517c55;
   8: arctan_turns=32'h0028be53; 9: arctan_turns=32'h00145f2f;
   10: arctan_turns=32'h000a2f98; 11: arctan_turns=32'h000517cc;
   12: arctan_turns=32'h00028be6; 13: arctan_turns=32'h000145f3;
   14: arctan_turns=32'h0000a2fa; 15: arctan_turns=32'h0000517d;
   default: arctan_turns=0;
  endcase end
 endfunction
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0; iteration<=0; x<=0; y<=0; angle<=0; count_latched<=0;
   busy<=0; done<=0; amplitude<=0; phase_tenths<=0;
  end else begin
   done<=0;
   case(state)
    0: if(start) begin
     busy<=1; iteration<=0; count_latched<=sample_count;
     if(q_value<0) begin x<=-qe; y<=-ie; angle<=32'h80000000; end
     else begin x<=qe; y<=ie; angle<=0; end
     state<=1;
    end
    1: begin
     if(y>=0) begin
      x<=x+(y>>>iteration); y<=y-(x>>>iteration);
      angle<=angle+arctan_turns(iteration);
     end else begin
      x<=x-(y>>>iteration); y<=y+(x>>>iteration);
      angle<=angle-arctan_turns(iteration);
     end
     if(iteration==15) state<=2; else iteration<=iteration+1'b1;
    end
    2: begin
     phase_tenths<=(angle_rounded[47:32]>=3600)?12'd0:angle_rounded[43:32];
     state<=3;
    end
    3: state<=4;
    4: if(div_done) begin
     amplitude<=(|quotient[39:16])?16'hffff:quotient[15:0];
     if(quotient==0) phase_tenths<=0;
     busy<=0; done<=1; state<=0;
    end
    default: begin state<=0; busy<=0; end
   endcase
  end
 end
endmodule

// -----------------------------------------------------------------------------
// Stage 7 (2026-11-03) additions, bundled here (same reason as the dependencies above: the TD project keeps its old source list).
//   mode_ctrl        : D9 button (I_button[1], active low) cycles the work mode, LED0..2 show it.
//   cam_period_table : mode 3 helper.  Listens to the camera waveform that A's sampler writes to the DAC replay (we/addr/code/commit/valid),
//                      cuts out ONE period (two rising crossings), resamples it to 32 points (12 bit) for B's servo_plot_uart.
// Mode numbering inside the RTL:  0 = "mode 1" camera -> DAC,  1 = "mode 2" AD -> servo,  2 = "mode 3" camera -> servo.
// -----------------------------------------------------------------------------
module mode_ctrl #(parameter integer CLK_HZ=25000000, parameter integer LED_ACTIVE_LOW=1)(
 input wire I_clk, input wire I_rst_n, input wire I_key_n,     // I_key_n: pin level, low = pressed (PULLUP)
 output reg [1:0] O_mode, output wire [5:0] O_led);
 localparam integer T10MS = CLK_HZ/100 - 1;
 reg [3:0] kr;
 reg [1:0] st;
 reg [23:0] cnt;
 wire tick = (cnt == T10MS);
 always @(posedge I_clk or negedge I_rst_n) begin
  if(!I_rst_n) begin
   kr <= 4'hF; st <= 2'd0; cnt <= 24'd0; O_mode <= 2'd0;
  end else begin
   kr <= {kr[2:0], I_key_n};
   cnt <= tick ? 24'd0 : (cnt + 1'b1);
   if(tick) begin
    case(st)
     2'd0: if(!kr[3]) st <= 2'd1;
     2'd1: if(!kr[3]) begin st <= 2'd2; O_mode <= (O_mode == 2'd2) ? 2'd0 : (O_mode + 1'b1); end
           else st <= 2'd0;
     2'd2: if(kr[3]) st <= 2'd3;
     2'd3: if(kr[3]) st <= 2'd0; else st <= 2'd2;
     default: st <= 2'd0;
    endcase
   end
  end
 end
 wire [5:0] led_on = (O_mode == 2'd0) ? 6'b000001 : (O_mode == 2'd1) ? 6'b000010 : 6'b000100;
 assign O_led = LED_ACTIVE_LOW ? ~led_on : led_on;
endmodule

module cam_period_table #(
 parameter integer MIN_PP     = 256,   // codes: peak-to-peak below this = no usable waveform (8 px at 32 codes/px)
 parameter integer MIN_PERIOD = 16,    // samples: crossings closer than this are noise
 parameter integer GAIN_NUM   = 3,     // 12-bit servo input = 2048 + ((code - mid) * GAIN_NUM >>> GAIN_SHIFT).  One screen pixel = 32 DAC codes (DAC_SIMPLE_MODE)
 parameter integer GAIN_SHIFT = 4)(    // and servo_plot_uart divides by 4  ->  servo units per px = 8*GAIN_NUM/2^GAIN_SHIFT = 1.5 with the defaults (tune on the board)
 input wire I_clk, input wire I_rst_n,
 input wire I_we, input wire [7:0] I_addr, input wire [13:0] I_code,
 input wire I_commit, input wire I_valid,
 output reg [383:0] O_points_flat,
 output reg O_table_valid, output reg O_new, output reg O_fallback, output reg O_reject,
 output reg O_busy, output reg [7:0] O_period);
 localparam [3:0] ST_IDLE=4'd0, ST_MM=4'd1, ST_MID=4'd2, ST_MID2=4'd3, ST_X=4'd4, ST_SETUP=4'd5, ST_RS=4'd6, ST_DONE=4'd7;
 reg [13:0] mem [0:127];
 reg [6:0] rd_addr;
 reg [13:0] rd_data;
 wire we_ok = I_we && !O_busy && !I_addr[7];
 always @(posedge I_clk) begin
  if(we_ok) mem[I_addr[6:0]] <= I_code;
  rd_data <= mem[rd_addr];
 end
 reg [3:0] st;
 reg [3:0] ph;
 reg [6:0] idx;
 reg [13:0] mn, mx, mid, lo_th, hi_th, pp;
 reg armed, farm, sel;
 reg [1:0] ncross, fncross;
 reg [6:0] r1, r2, f1, f2;
 reg [6:0] base;
 reg [7:0] per;
 reg fb;
 reg [4:0] k;
 reg [12:0] pos;
 reg [13:0] s0;
 reg [19:0] acc;
 reg signed [16:0] dif;
 reg signed [20:0] scl;
 reg [383:0] tmp;
 integer pt_i;
 wire [4:0] frac = pos[4:0];
 wire [6:0] pidx = pos[11:5];
 always @(posedge I_clk or negedge I_rst_n) begin
  if(!I_rst_n) begin
   st <= ST_IDLE; ph <= 4'd0; idx <= 7'd0; mn <= 14'd0; mx <= 14'd0; mid <= 14'd0; lo_th <= 14'd0; hi_th <= 14'd0; pp <= 14'd0;
   armed <= 1'b0; farm <= 1'b0; sel <= 1'b0; ncross <= 2'd0; fncross <= 2'd0; r1 <= 7'd0; r2 <= 7'd0; f1 <= 7'd0; f2 <= 7'd0; base <= 7'd0; per <= 8'd128; fb <= 1'b0; k <= 5'd0; pos <= 13'd0;
   s0 <= 14'd0; acc <= 20'd0; dif <= 17'sd0; scl <= 21'sd0; tmp <= 384'd0; rd_addr <= 7'd0;
   O_points_flat <= 384'd0; O_table_valid <= 1'b0; O_new <= 1'b0; O_fallback <= 1'b0; O_reject <= 1'b0; O_busy <= 1'b0; O_period <= 8'd0;
  end else begin
   O_new <= 1'b0; O_reject <= 1'b0;
   case(st)
    ST_IDLE: if(I_commit && I_valid) begin
     O_busy <= 1'b1; idx <= 7'd0; ph <= 4'd0; st <= ST_MM;
    end
    // ---- pass 1: min / max of the 128 samples
    ST_MM: begin
     case(ph)
      4'd0: begin rd_addr <= idx; ph <= 4'd1; end
      4'd1: ph <= 4'd2;
      default: begin
       if(idx == 7'd0) begin mn <= rd_data; mx <= rd_data; end
       else begin
        if(rd_data < mn) mn <= rd_data;
        if(rd_data > mx) mx <= rd_data;
       end
       ph <= 4'd0;
       if(idx == 7'd127) st <= ST_MID; else idx <= idx + 1'b1;
      end
     endcase
    end
    ST_MID: begin
     pp  <= mx - mn;
     mid <= ({1'b0, mx} + {1'b0, mn}) >> 1;
     st  <= ST_MID2;
    end
    ST_MID2: begin
     lo_th <= mid - {3'b000, pp[13:3]};
     hi_th <= mid + {3'b000, pp[13:3]};
     if(pp < MIN_PP) begin O_reject <= 1'b1; O_busy <= 1'b0; st <= ST_IDLE; end
     else begin idx <= 7'd0; ph <= 4'd0; armed <= 1'b0; farm <= 1'b0; sel <= 1'b0; ncross <= 2'd0; fncross <= 2'd0; st <= ST_X; end
    end
    // ---- pass 2: first two rising OR first two falling crossings of the mid level, whichever pair completes first (hysteresis pp/8)
    //      any window of >= 1.5 periods contains one of the two pairs
    ST_X: begin
     case(ph)
      4'd0: begin rd_addr <= idx; ph <= 4'd1; end
      4'd1: ph <= 4'd2;
      default: begin
       ph <= 4'd0;
       if(rd_data < lo_th) armed <= 1'b1;
       else if(armed && rd_data >= mid) begin
        armed <= 1'b0;
        if(ncross == 2'd0) begin r1 <= idx; ncross <= 2'd1; end
        else begin r2 <= idx; ncross <= 2'd2; sel <= 1'b0; st <= ST_SETUP; end
       end
       if(rd_data > hi_th) farm <= 1'b1;
       else if(farm && rd_data <= mid) begin
        farm <= 1'b0;
        if(fncross == 2'd0) begin f1 <= idx; fncross <= 2'd1; end
        else begin f2 <= idx; fncross <= 2'd2; sel <= 1'b1; st <= ST_SETUP; end
       end
       if(idx == 7'd127) st <= ST_SETUP; else idx <= idx + 1'b1;
      end
     endcase
    end
    ST_SETUP: begin
     if(!sel && ncross == 2'd2 && (r2 - r1) >= MIN_PERIOD) begin base <= r1; per <= {1'b0, r2 - r1}; fb <= 1'b0; end
     else if(sel && fncross == 2'd2 && (f2 - f1) >= MIN_PERIOD) begin base <= f1; per <= {1'b0, f2 - f1}; fb <= 1'b0; end
     else begin base <= 7'd0; per <= 8'd128; fb <= 1'b1; end
     k <= 5'd0; ph <= 4'd0; st <= ST_RS;
    end
    // ---- pass 3: 32 points over [base, base+per) with linear interpolation, then scale to the 12-bit servo input
    ST_RS: begin
     case(ph)
      4'd0: begin pos <= {base, 5'd0} + k * per; ph <= 4'd1; end
      4'd1: begin rd_addr <= pidx; ph <= 4'd2; end
      4'd2: ph <= 4'd3;
      4'd3: begin s0 <= rd_data; rd_addr <= (pidx == 7'd127) ? 7'd127 : (pidx + 1'b1); ph <= 4'd4; end
      4'd4: ph <= 4'd5;
      4'd5: begin acc <= s0 * (6'd32 - frac) + rd_data * frac; ph <= 4'd6; end
      4'd6: begin dif <= $signed({3'b000, acc[18:5]}) - $signed({3'b000, mid}); ph <= 4'd7; end
      4'd7: begin scl <= (dif * GAIN_NUM) >>> GAIN_SHIFT; ph <= 4'd8; end
      default: begin
       pt_i = 2048 + scl;
       if(pt_i < 0) pt_i = 0;
       if(pt_i > 4095) pt_i = 4095;
       tmp[k*12 +: 12] <= pt_i[11:0];
       ph <= 4'd0;
       if(k == 5'd31) st <= ST_DONE; else k <= k + 1'b1;
      end
     endcase
    end
    ST_DONE: begin
     O_points_flat <= tmp; O_table_valid <= 1'b1; O_new <= 1'b1; O_fallback <= fb; O_period <= per;
     O_busy <= 1'b0; st <= ST_IDLE;
    end
    default: st <= ST_IDLE;
   endcase
  end
 end
endmodule
