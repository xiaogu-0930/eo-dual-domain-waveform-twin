`timescale 1ns/1ps
// Byte tap: drop-in replacement for B's uart_tx inside the packet generators (same send/data/busy handshake), but the byte goes to a
// valid/ready port instead of a baud shifter.  busy = a byte is waiting (full); it stays high until the consumer takes it, so a
// generator that waits "!busy, send, busy, !busy" before the next character is back-pressured by the consumer exactly like by a real uart_tx.
module uart_byte_tap (
 input  wire clk, input wire rst_n,
 input  wire send, input wire [7:0] data, output wire busy,
 output wire byte_valid, output wire [7:0] byte_data, input wire byte_ready
);
 reg full; reg [7:0] d;
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin full <= 1'b0; d <= 8'd0; end
  else begin
   if (full && byte_ready) full <= 1'b0;
   if (send && !full) begin d <= data; full <= 1'b1; end   // send is only issued while !busy (generator protocol)
  end
 end
 assign busy = full; assign byte_valid = full; assign byte_data = d;
endmodule
