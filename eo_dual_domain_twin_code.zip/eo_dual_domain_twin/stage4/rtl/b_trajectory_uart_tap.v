`timescale 1ns/1ps
// Stage 4 / C-06: B's trajectory_uart copied UNCHANGED from baseline_B/rtl/wave_harmonic.v except the uart_tx -> uart_byte_tap swap and the 3 byte-port signals (replacing tx).
module trajectory_uart #(parameter integer CLK_HZ=25000000,
 parameter integer BAUD=115200)(
 input wire clk,rst_n,start,
 input wire plot_mode,
 input wire [383:0] points_flat,
 output wire byte_valid, output wire [7:0] byte_data, input wire byte_ready, output reg busy,done);   // C-06: byte tap replaces tx
 reg mode_latched;
reg [1:0] record_index;
reg [5:0] character_index;
 reg [4:0] point_index;
 reg uart_send;
 reg [7:0] uart_data;
 reg [2:0] state;
 wire uart_busy;
wire [5:0] record_length=(record_index==0)?6'd22:
  (record_index==1)?6'd11:6'd5;
 wire [11:0] current_point=points_flat[point_index*12 +: 12];
 uart_byte_tap transmitter   // C-06: was uart_tx (baud shifter); same send/data/busy handshake
  (.clk(clk),.rst_n(rst_n),.send(uart_send),.data(uart_data),.busy(uart_busy),.byte_valid(byte_valid),.byte_data(byte_data),.byte_ready(byte_ready));
 function [7:0] stream_character;
  input [5:0] position;
  input [1:0] record;
  input [4:0] point;
  input [11:0] value;
  input mode;
  begin
   stream_character=" ";
   if(record==0) begin
    case(position)
     0: stream_character="B"; 1: stream_character="E";
     2: stream_character="G"; 3: stream_character="I";
     4: stream_character="N"; 5: stream_character=",";
     6: stream_character="M"; 7: stream_character="O";
     8: stream_character="D"; 9: stream_character="E";
     10: stream_character="=";
     11: stream_character=mode?"R":"F";
     12: stream_character=mode?"A":"U";
     13: stream_character=mode?"W":"N";
     14: stream_character=mode?" ":"D";
     15: stream_character=","; 16: stream_character="N";
     17: stream_character="="; 18: stream_character="3";
     19: stream_character="2"; 20: stream_character=8'h0d;
     21: stream_character=8'h0a;
     default: stream_character=" ";
    endcase
   end else if(record==1) begin
    case(position)
     0: stream_character="P"; 1: stream_character=",";
     2: stream_character=8'h30+(point/10);
     3: stream_character=8'h30+(point%10);
     4: stream_character=",";
     5: stream_character=8'h30+(value/1000);
     6: stream_character=8'h30+((value%1000)/100);
     7: stream_character=8'h30+((value%100)/10);
     8: stream_character=8'h30+(value%10);
     9: stream_character=8'h0d; 10: stream_character=8'h0a;
     default: stream_character=" ";
    endcase
   end else if(record==2) begin
    case(position)
     0: stream_character="E"; 1: stream_character="N";
     2: stream_character="D"; 3: stream_character=8'h0d;
     4: stream_character=8'h0a;
     default: stream_character=" ";
    endcase
   end
  end
 endfunction
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   state<=0; busy<=0; done<=0; uart_send<=0; uart_data<=0;
   mode_latched<=0; record_index<=0; character_index<=0; point_index<=0;
  end else begin
   uart_send<=0; done<=0;
   case(state)
    0: if(start) begin
     mode_latched<=plot_mode; record_index<=0; character_index<=0;
     point_index<=0; busy<=1; state<=1;
    end
    1: if(!uart_busy) begin
     uart_data<=stream_character(character_index,record_index,point_index,
      current_point,mode_latched);
     uart_send<=1; state<=2;
    end
    2: if(uart_busy) state<=3;
    3: if(!uart_busy) begin
     if(character_index==record_length-1'b1) begin
      character_index<=0;
      if(record_index==0) begin record_index<=1; point_index<=0; state<=1; end
      else if(record_index==1 && point_index<31) begin
       point_index<=point_index+1'b1; state<=1;
      end else if(record_index==1) begin
       record_index<=2; state<=1;
      end else begin busy<=0; done<=1; state<=0; end
     end else begin character_index<=character_index+1'b1; state<=1; end
    end
    default: begin state<=0; busy<=0; end
   endcase
  end
 end
endmodule
