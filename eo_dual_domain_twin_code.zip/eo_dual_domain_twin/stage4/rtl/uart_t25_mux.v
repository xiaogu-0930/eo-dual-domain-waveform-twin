`timescale 1ns/1ps
// Stage 4 / D2: shared T25 UART.  Streaming framer + arbiter (no packet store), loss-free by construction (back-pressure).
// Frame (exact):  0x7E | SRC | SEQ | LEN_L | LEN_H | PAYLOAD[LEN] | CRC_L | CRC_H | 0x7E
//   escape (HDLC): inside the frame 0x7E and 0x7D are sent as 0x7D, byte^0x20.  CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection,
//   xorout 0) over SRC,SEQ,LEN_L,LEN_H,PAYLOAD (before escaping), sent little-endian (the CRC bytes are escaped like any other).
//   Abort: a source that stops delivering for STALL_LIMIT clocks inside a frame is cut with 0x7D 0x7E (HDLC abort); the receiver discards the frame.
// SRC: 01 A wave report, 02 B summary, 03 B trajectory, 04 A key acknowledge, 10 merged-design status (generated here).
// Source interface (4 sources): reqN = the source has a packet to send (RISING edge = new packet; the source may keep it high until its last byte);
//   lenN = payload bytes of that packet (constant per source); validN/dataN = next payload byte, held until readyN (ready = the byte is taken this clock).
// Arbitration: round robin over the 4 sources + the status packet, decided only between frames; a granted source keeps the line until its frame ends.
module uart_t25_mux #(
 parameter integer SYS_CLK_HZ = 25000000,
 parameter integer BAUD = 115200,
 parameter integer STATUS_PERIOD_CYCLES = 25000000,
 parameter integer STALL_LIMIT = 12500000,          // 0.5 s at 25 MHz
 parameter [15:0] MAX_LEN = 16'd8192
)(
 input  wire clk, input wire rst_n,
 input  wire s0_req, input wire [15:0] s0_len, input wire s0_valid, input wire [7:0] s0_data, output wire s0_ready,
 input  wire s1_req, input wire [15:0] s1_len, input wire s1_valid, input wire [7:0] s1_data, output wire s1_ready,
 input  wire s2_req, input wire [15:0] s2_len, input wire s2_valid, input wire [7:0] s2_data, output wire s2_ready,
 input  wire s3_req, input wire [15:0] s3_len, input wire s3_valid, input wire [7:0] s3_data, output wire s3_ready,
 input  wire [7:0] a_req_drop, input wire [7:0] a_stale_drop,
 output wire tx
);
 localparam [15:0] STATUS_LEN = 16'd29;
 localparam [3:0] F_IDLE=4'd0, F_FLAG0=4'd1, F_SRC=4'd2, F_SEQ=4'd3, F_LENL=4'd4, F_LENH=4'd5, F_PAY=4'd6, F_CRCL=4'd7, F_CRCH=4'd8, F_FLAG1=4'd9, F_ABORT=4'd10, F_ABORT2=4'd11, F_DRAIN=4'd12;
 function [15:0] crc_byte; input [15:0] c; input [7:0] d; integer i; reg [15:0] x;
  begin x = c ^ {d, 8'h00}; for (i = 0; i < 8; i = i + 1) x = x[15] ? ((x << 1) ^ 16'h1021) : (x << 1); crc_byte = x; end
 endfunction

 // ------------------------------------------------------------ pending requests
 reg [3:0] req_d; reg [4:0] pend; reg [31:0] age0, age1, age2, age3, age4; reg [31:0] stat_timer;
 wire [3:0] req_raw = {s3_req, s2_req, s1_req, s0_req};
 wire [3:0] req_rise = req_raw & ~req_d;
 wire stat_tick = (stat_timer == STATUS_PERIOD_CYCLES - 1);
 reg [4:0] clr;                       // temporary (blocking) inside the clocked block, never read in another block
 // ------------------------------------------------------------ framer state
 reg [3:0] fs; reg [2:0] cur, rr; reg [15:0] len, cnt, crc; reg [7:0] seq_cur;
 reg [7:0] seq0, seq1, seq2, seq3, seq4;
 reg [15:0] pk0, pk1, pk2, pk3, pk4;
 reg [31:0] esc_cnt, wait_max, stall_cur, uptime, sec_ctr; reg [15:0] stall_max; reg [7:0] len_err, abort_cnt;
 reg [255:0] snap;
 // ------------------------------------------------------------ output byte stage
 reg [7:0] lb; reg lb_valid, lb_esc, esc_done, send; reg [7:0] sdata; wire txbusy;
 uart_tx #(.CLK_HZ(SYS_CLK_HZ), .BAUD(BAUD)) u_tx (.clk(clk), .rst_n(rst_n), .send(send), .data(sdata), .tx(tx), .busy(txbusy));

 // ------------------------------------------------------------ arbitration (combinational pick)
 reg any; reg [2:0] pick; integer k, idx;
 always @* begin
  any = 1'b0; pick = 3'd0;
  for (k = 1; k <= 5; k = k + 1) begin
   idx = rr + k; if (idx >= 5) idx = idx - 5;
   if (!any && pend[idx]) begin any = 1'b1; pick = idx[2:0]; end
  end
 end
 wire [15:0] pick_len = (pick == 3'd0) ? s0_len : (pick == 3'd1) ? s1_len : (pick == 3'd2) ? s2_len : (pick == 3'd3) ? s3_len : STATUS_LEN;
 wire [31:0] pick_age = (pick == 3'd0) ? age0 : (pick == 3'd1) ? age1 : (pick == 3'd2) ? age2 : (pick == 3'd3) ? age3 : age4;
 wire [7:0]  pick_seq = (pick == 3'd0) ? seq0 : (pick == 3'd1) ? seq1 : (pick == 3'd2) ? seq2 : (pick == 3'd3) ? seq3 : seq4;
 wire [7:0]  pick_src = (pick == 3'd0) ? 8'h01 : (pick == 3'd1) ? 8'h02 : (pick == 3'd2) ? 8'h03 : (pick == 3'd3) ? 8'h04 : 8'h10;
 reg [7:0] cur_src;

 wire sel_valid = (cur == 3'd0) ? s0_valid : (cur == 3'd1) ? s1_valid : (cur == 3'd2) ? s2_valid : (cur == 3'd3) ? s3_valid : 1'b1;
 wire [7:0] stat_byte = snap[cnt[4:0]*8 +: 8];
 wire [7:0] sel_data  = (cur == 3'd0) ? s0_data : (cur == 3'd1) ? s1_data : (cur == 3'd2) ? s2_data : (cur == 3'd3) ? s3_data : stat_byte;
 wire take = ((fs == F_PAY) && !lb_valid && sel_valid) || ((fs == F_DRAIN) && sel_valid && (cur != 3'd4));   // F_DRAIN: discard the rest of an aborted packet
 assign s0_ready = take && (cur == 3'd0);
 assign s1_ready = take && (cur == 3'd1);
 assign s2_ready = take && (cur == 3'd2);
 assign s3_ready = take && (cur == 3'd3);

 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
   req_d <= 4'd0; pend <= 5'd0; age0 <= 0; age1 <= 0; age2 <= 0; age3 <= 0; age4 <= 0; stat_timer <= 0;
   fs <= F_IDLE; cur <= 3'd0; rr <= 3'd4; len <= 16'd0; cnt <= 16'd0; crc <= 16'hFFFF; seq_cur <= 8'd0; cur_src <= 8'd0;
   seq0 <= 0; seq1 <= 0; seq2 <= 0; seq3 <= 0; seq4 <= 0; pk0 <= 0; pk1 <= 0; pk2 <= 0; pk3 <= 0; pk4 <= 0;
   esc_cnt <= 0; wait_max <= 0; stall_cur <= 0; uptime <= 0; sec_ctr <= 0; stall_max <= 0; len_err <= 0; abort_cnt <= 0; snap <= 256'd0;
   lb <= 8'd0; lb_valid <= 1'b0; lb_esc <= 1'b0; esc_done <= 1'b0; send <= 1'b0; sdata <= 8'd0;
  end else begin
   req_d <= req_raw; send <= 1'b0; clr = 5'd0;   // clr: blocking temporary, one-hot grant/drop this clock
   // ---- uptime / status timer
   if (sec_ctr == SYS_CLK_HZ - 1) begin sec_ctr <= 0; if (uptime != 32'hffffffff) uptime <= uptime + 1'b1; end else sec_ctr <= sec_ctr + 1'b1;
   if (stat_tick) stat_timer <= 0; else stat_timer <= stat_timer + 1'b1;
   // ---- ages of pending requests
   if (pend[0] && age0 != 32'hffffffff) age0 <= age0 + 1'b1;
   if (pend[1] && age1 != 32'hffffffff) age1 <= age1 + 1'b1;
   if (pend[2] && age2 != 32'hffffffff) age2 <= age2 + 1'b1;
   if (pend[3] && age3 != 32'hffffffff) age3 <= age3 + 1'b1;
   if (pend[4] && age4 != 32'hffffffff) age4 <= age4 + 1'b1;

   // ---- output engine: one byte at a time into uart_tx, with escaping
   if (lb_valid && !txbusy && !send) begin
    if (lb_esc && !esc_done && (lb == 8'h7e || lb == 8'h7d)) begin
     send <= 1'b1; sdata <= 8'h7d; esc_done <= 1'b1; if (esc_cnt != 32'hffffffff) esc_cnt <= esc_cnt + 1'b1;
    end else begin
     send <= 1'b1; sdata <= esc_done ? (lb ^ 8'h20) : lb; lb_valid <= 1'b0; esc_done <= 1'b0;
    end
   end

   // ---- framer
   case (fs)
    F_IDLE: if (any) begin
     if (pick_len == 16'd0 || pick_len > MAX_LEN) begin          // invalid length: drop the request, count it
      clr[pick] = 1'b1; rr <= pick; if (len_err != 8'hff) len_err <= len_err + 1'b1;
     end else begin
      cur <= pick; rr <= pick; len <= pick_len; seq_cur <= pick_seq; cur_src <= pick_src; crc <= 16'hFFFF; cnt <= 16'd0; stall_cur <= 0;
      clr[pick] = 1'b1; if (pick_age > wait_max) wait_max <= pick_age;
      if (pick == 3'd4)
       snap <= {24'd0, abort_cnt, len_err, uptime, wait_max, stall_max, esc_cnt, pk4, pk3, pk2, pk1, pk0, a_stale_drop, a_req_drop, 8'h01};
      fs <= F_FLAG0;
     end
    end
    F_FLAG0: if (!lb_valid) begin lb <= 8'h7e; lb_esc <= 1'b0; lb_valid <= 1'b1; fs <= F_SRC; end
    F_SRC:   if (!lb_valid) begin lb <= cur_src; lb_esc <= 1'b1; lb_valid <= 1'b1; crc <= crc_byte(crc, cur_src); fs <= F_SEQ; end
    F_SEQ:   if (!lb_valid) begin lb <= seq_cur; lb_esc <= 1'b1; lb_valid <= 1'b1; crc <= crc_byte(crc, seq_cur); fs <= F_LENL; end
    F_LENL:  if (!lb_valid) begin lb <= len[7:0]; lb_esc <= 1'b1; lb_valid <= 1'b1; crc <= crc_byte(crc, len[7:0]); fs <= F_LENH; end
    F_LENH:  if (!lb_valid) begin lb <= len[15:8]; lb_esc <= 1'b1; lb_valid <= 1'b1; crc <= crc_byte(crc, len[15:8]); fs <= F_PAY; stall_cur <= 0; end
    F_PAY: begin
     if (take) begin
      lb <= sel_data; lb_esc <= 1'b1; lb_valid <= 1'b1; crc <= crc_byte(crc, sel_data); cnt <= cnt + 1'b1; stall_cur <= 0;
      if (cnt == len - 1'b1) fs <= F_CRCL;
     end else if (!lb_valid) begin                               // waiting for the source: back-pressure
      stall_cur <= stall_cur + 1'b1;
      if (stall_cur + 1 > stall_max && stall_cur < 32'h0000ffff) stall_max <= stall_cur[15:0] + 1'b1;
      if (stall_cur >= STALL_LIMIT) begin fs <= F_ABORT; if (abort_cnt != 8'hff) abort_cnt <= abort_cnt + 1'b1; end
     end
    end
    F_CRCL:  if (!lb_valid) begin lb <= crc[7:0];  lb_esc <= 1'b1; lb_valid <= 1'b1; fs <= F_CRCH; end
    F_CRCH:  if (!lb_valid) begin lb <= crc[15:8]; lb_esc <= 1'b1; lb_valid <= 1'b1; fs <= F_FLAG1; end
    F_FLAG1: if (!lb_valid) begin
     lb <= 8'h7e; lb_esc <= 1'b0; lb_valid <= 1'b1; fs <= F_IDLE;
     case (cur)
      3'd0: begin seq0 <= seq0 + 1'b1; pk0 <= pk0 + 1'b1; end
      3'd1: begin seq1 <= seq1 + 1'b1; pk1 <= pk1 + 1'b1; end
      3'd2: begin seq2 <= seq2 + 1'b1; pk2 <= pk2 + 1'b1; end
      3'd3: begin seq3 <= seq3 + 1'b1; pk3 <= pk3 + 1'b1; end
      default: begin seq4 <= seq4 + 1'b1; pk4 <= pk4 + 1'b1; end
     endcase
    end
    F_ABORT: if (!lb_valid) begin                                // HDLC abort: 0x7D 0x7E, raw (no escaping); the SEQ is not consumed
     lb <= 8'h7d; lb_esc <= 1'b0; lb_valid <= 1'b1; fs <= F_ABORT2;
    end
    F_ABORT2: if (!lb_valid) begin lb <= 8'h7e; lb_esc <= 1'b0; lb_valid <= 1'b1; stall_cur <= 0; fs <= (cur == 3'd4) ? F_IDLE : F_DRAIN; end
    F_DRAIN: begin                                                // swallow what the aborted source still delivers so it can finish its own packet
     if (take) begin
      cnt <= cnt + 1'b1; stall_cur <= 0;
      if (cnt >= len - 1'b1) fs <= F_IDLE;
     end else begin
      stall_cur <= stall_cur + 1'b1;
      if (stall_cur >= STALL_LIMIT) fs <= F_IDLE;
     end
    end
    default: fs <= F_IDLE;
   endcase

   // ---- pending set/clear (clear wins only for the pick granted this clock; a rising edge of the same source cannot occur inside its packet)
   pend <= (pend | {stat_tick, req_rise}) & ~clr;
   if (clr[0]) age0 <= 0; if (clr[1]) age1 <= 0; if (clr[2]) age2 <= 0; if (clr[3]) age3 <= 0; if (clr[4]) age4 <= 0;
  end
 end
endmodule
