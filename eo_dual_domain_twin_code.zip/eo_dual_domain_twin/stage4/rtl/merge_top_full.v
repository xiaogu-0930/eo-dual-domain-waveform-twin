`timescale 1ns / 1ns
// STAGE 4b full merged top.  A (camera / ISP / DDR / ui_dbuf / waveform extract / wave_sample32_uart / DAC) + B (ADC / wave core / servo) +
// display (B scope UI left, A camera right, one HDMI) + ONE shared T25 UART (uart_t25_mux).
// Hierarchy: u_disp = merge_top_s3 (proven display top: ui_pll, merge_reset, ui_vtc_xy, B scope core, cam_right_path, compositor, hdmi_tx).
// Instance names of A's blocks are kept as in A's system_top (SDC / ChipWatcher names).  Decisions: D1 serial reset STAGES=8 (inside hdmi), D2 UART framing,
// D3 per-signal CDC, D4 2:1 squeeze, D5 divider x=959, R-1(a) display decoupled from DDR/camera (merge_reset).
// Resets (merge_reset, Stage 3):  sys_rst_n -> everything on I_sys_clk / clk_25m;  hsrx_rst_n -> everything on hs_rx_clk;  b_rst_n -> b_core;  A's DDR/dbuf/FDMA resets
// stay exactly as in A (S_ddr_init_cal_done / raw PLL lock); mipi PHY keeps ~pll_lock.
module merge_top_full #(
 parameter integer DAC_SAMPLE_COUNT = 128,
 parameter integer DAC_ROI_TIME_NS  = 608000,   // 2026-11-02 from A: 2 periods of the measured 3.289 kHz test signal (HOLD 119 -> 609.28 us frame)
 parameter integer DAC_SIMPLE_MODE = 1,         // 2026-11-02 from A: 1 = no NUM/DEN amplitude calibration (code = 8192 + (DAC_Y_MID_PX - y)*32)
 parameter integer DAC_Y_SCALE_NUM      = 16383,
 parameter integer DAC_Y_SCALE_DEN      = 400,
 parameter integer DAC_Y_SCALE_OFFSET   = 0,
 parameter integer DAC_Y_ACTIVE_PX      = 400,
 parameter integer DAC_Y_MID_PX         = 480,
 parameter integer DAC_CAL_ENABLE       = 0,
 parameter integer DAC_TEST_WAVE_ENABLE = 0,
 parameter integer DAC_INTERP_UPDATE_DIV = 1,
 parameter integer LED_ACTIVE_LOW = 1          // Stage 7: board LEDs (official key_led demo): 1 = low level lights the LED
)(
 input  wire         I_sys_clk,
 input  wire         I_ddr_clk,
 // DDR3 (4 Gb, x32) - names as in A
 output wire [14:0]  ddr_addr, output wire [2:0] ddr_ba, output wire [0:0] ddr_cke, output wire [0:0] ddr_odt, output wire [0:0] ddr_cs_n,
 output wire         ddr_ras_n, output wire ddr_cas_n, output wire ddr_we_n, output wire ddr_ck_p, output wire ddr_ck_n, output wire ddr_reset_n,
 inout  wire [3:0]   ddr_dm, inout wire [31:0] ddr_dq, inout wire [3:0] ddr_dqs_n, inout wire [3:0] ddr_dqs_p,
 // A
 input  wire [2:0]   I_button,
 inout  wire         IO_cam_sda, output wire O_cam_scl, output wire O_cam_clk,
 output wire [2:0]   O_hdmi_tx_p, output wire O_hdmi_clk_p,
 output wire         O_uart_tx,                  // T25: the ONE shared UART (D2)
 output wire         O_dac_clk, output wire [13:0] O_dac_data, output wire O_dac_pd,
 // B
 output wire         adc_clk, input wire [11:0] adc_d, input wire key4,
 output wire         servo_tx, input wire servo_rx,
 // Stage 7: work-mode LEDs (LED0 = mode 1 camera->DAC, LED1 = mode 2 AD->servo, LED2 = mode 3 camera->servo)
 output wire [5:0]   O_led
);
 localparam integer DAC_HOLD_DEN = DAC_SAMPLE_COUNT * 40;
 localparam integer DAC_HOLD_CALC = (DAC_ROI_TIME_NS + DAC_HOLD_DEN / 2) / DAC_HOLD_DEN;
 localparam integer DAC_HOLD_EFFECTIVE = (DAC_HOLD_CALC < 1) ? 1 : DAC_HOLD_CALC;
 localparam integer AXI_ID_WIDTH = 4, AXI_ADDR_WIDTH = 32, AXI_DATA_WIDTH = 256, AXI_MASK_WIDTH = 32;

 // ------------------------------------------------------------------ B power-up reset (as B: 2 sys-clock shift register), then merge_reset u_b
 reg [1:0] b_release = 2'b00;
 always @(posedge I_sys_clk) b_release <= {b_release[0], 1'b1};

 // ------------------------------------------------------------------ nets
 wire S_dfi_clk, S_ddr_init_cal_done;
 wire S_hs_rx_clk, S_hs_rx_valid; wire [31:0] S_hs_rx_data; wire [3:0] S_lane_error;
 wire S_csi_frame_start, S_csi_frame_end, S_csi_valid; wire [31:0] S_csi_data;
 wire S_raw10_frame_start, S_raw10_frame_end, S_raw10_valid; wire [39:0] S_raw10_data;
 wire [39:0] S_axis_tdata; wire S_axis_tvalid, S_axis_tlast, S_axis_tuser;
 wire S_ISP_O_tready; wire [127:0] S_ISP_O_tdata; wire S_ISP_O_tlast, S_ISP_O_tuser, S_ISP_O_tvalid;
 wire [127:0] S_WF_tdata; wire S_WF_tlast, S_WF_tuser, S_WF_tvalid, S_WF_tready;
 wire [7:0] S_wbuf_sync, S_rbuf_sync;
 wire [7:0] S_ae; wire S_cam_cfg_done, S_ae_cfg_done, S_ae_req;
 wire S_wave_sample_valid, S_wave_sample_last, S_wave_frame_start, S_wave_frame_end; wire [15:0] S_wave_sample_x, S_wave_sample_y;
 wire S_uart_report_busy, S_dac_sample_we, S_dac_frame_commit, S_dac_frame_valid; wire [7:0] S_dac_sample_addr; wire [13:0] S_dac_sample_code;
 wire [7:0] cwc_probe0, cwc_probe1, cwc_probe2, cwc_probe3, cwc_probe4, cwc_probe5;
 // FDMA / AXI
 wire [AXI_ADDR_WIDTH-1:0] S_fdma_waddr, S_fdma_raddr; wire S_fdma_wareq, S_fdma_rareq; wire [15:0] S_fdma_wsize, S_fdma_rsize;
 wire S_fdma_wbusy, S_fdma_rbusy, S_fdma_wvalid, S_fdma_wready, S_fdma_rvalid, S_fdma_rready;
 wire [AXI_DATA_WIDTH-1:0] S_fdma_wdata, S_fdma_rdata;
 wire [AXI_ADDR_WIDTH-1:0] S_axi_awaddr, S_axi_araddr; wire S_axi_awvalid, S_axi_awready, S_axi_arvalid, S_axi_arready;
 wire [AXI_ID_WIDTH-1:0] S_axi_awid, S_axi_arid, S_axi_bid, S_axi_rid; wire [7:0] S_axi_awlen, S_axi_arlen; wire [2:0] S_axi_awsize, S_axi_arsize;
 wire [1:0] S_axi_awburst, S_axi_arburst, S_axi_bresp, S_axi_rresp; wire [0:0] S_axi_awlock, S_axi_arlock; wire [3:0] S_axi_awcache, S_axi_arcache, S_axi_awqos, S_axi_arqos;
 wire [2:0] S_axi_awprot, S_axi_arprot; wire [AXI_DATA_WIDTH-1:0] S_axi_wdata, S_axi_rdata; wire [AXI_MASK_WIDTH-1:0] S_axi_wstrb;
 wire S_axi_wvalid, S_axi_wlast, S_axi_wready, S_axi_bvalid, S_axi_bready, S_axi_rlast, S_axi_rvalid, S_axi_rready;
 // display <-> camera read FIFO
 wire pclk, vtc_vs, cam_pop, cam_underrun, cam_tvalid; wire [63:0] cam_tdata;
 wire clk25, clk70, pll_lock, sys_rst_n, hsrx_rst_n, b_rst_n;
 // B scope data
 wire [767:0] b_w0, b_w1; wire b_bank, b_tog; wire [23:0] b_freq; wire [15:0] b_amp; wire [79:0] b_harm; wire [39:0] b_hh; wire [2:0] b_type, b_stat;
 // UART sources
 wire a_rpt_req, a_ack_req, a_tap_valid, a_tap_is_ack, a_byte_ready; wire [7:0] a_tap_data, a_req_drop, a_stale_drop; wire [15:0] a_rpt_len;
 wire sum_req, sum_valid, sum_ready, trc_req, trc_valid, trc_ready; wire [7:0] sum_data, trc_data;
 wire m_r0, m_r1, m_r2, m_r3;

 // ------------------------------------------------------------------ display (proven top) - owns ui_pll, merge_reset, VTC, scope UI, compositor, HDMI
 merge_top_s3 #(.USE_STIM(0)) u_disp (
  .I_sys_clk(I_sys_clk), .I_ddr_init_done(S_ddr_init_cal_done), .I_b_run_rst_n(b_release[1]),
  .O_pclk(pclk), .O_vtc_vs(vtc_vs), .O_cam_pop(cam_pop), .I_cam_tvalid(cam_tvalid), .I_cam_tdata(cam_tdata), .O_cam_underrun(cam_underrun),
  .O_hdmi_tx_p(O_hdmi_tx_p), .O_hdmi_clk_p(O_hdmi_clk_p),
  .I_hsrx_clk(S_hs_rx_clk), .O_clk25(clk25), .O_clk70(clk70), .O_pll_lock(pll_lock),
  .O_sys_rst_n(sys_rst_n), .O_hsrx_rst_n(hsrx_rst_n), .O_b_rst_n(b_rst_n),
  .I_w0(b_w0), .I_w1(b_w1), .I_w_bank(b_bank), .I_w_tog(b_tog), .I_w_freq(b_freq), .I_w_amp(b_amp), .I_w_harm(b_harm), .I_w_hh(b_hh), .I_w_type(b_type), .I_w_stat(b_stat));

 // ------------------------------------------------------------------ A: camera clock, sensor config
 PH1_LOGIC_ODDR X_cam_clk (.q(O_cam_clk), .clk(clk25), .d0(1'b1), .d1(1'b0), .rst(~pll_lock));
 ui_ae_set X_ui_ae_set (.I_clk(clk25), .I_rst(sys_rst_n), .I_btn({1'b0, ~I_button[0]}), .I_cam_cfg_done(S_cam_cfg_done), .I_ae_cfg_done(S_ae_cfg_done), .O_ae_req(S_ae_req), .O_ae(S_ae));
 ui_cfg_imx415 #(.CLK_DIV(24_000_000/100_000-1)) X_ui_cfg_imx415 (
  .I_clk(clk25), .I_rst_n(sys_rst_n), .I_ae_req(S_ae_req), .I_ae_data(S_ae), .O_cam_scl(O_cam_scl), .IO_cam_sda(IO_cam_sda),
  .O_cfg_done(S_cam_cfg_done), .O_ae_cfg_done(S_ae_cfg_done));
 mipi_dphy_rx_ph1a_mipiio_wrapper #(.LANE_NUM(4), .BYTE_NUM(1)) u_mipi_dphy_rx_ph1a_mipiio_wrapper (
  .I_lp_clk(clk70), .I_rst(~pll_lock), .I_clk_lane_in_delay('d0), .I_data_lane0_in_delay('d20), .I_data_lane1_in_delay('d20),
  .I_data_lane2_in_delay('d20), .I_data_lane3_in_delay('d20), .I_lane_invert(4'b0000),
  .O_hs_rx_clk(S_hs_rx_clk), .O_hs_rx_valid(S_hs_rx_valid), .O_hs_rx_data(S_hs_rx_data),
  .I_lp_tx_en(1'b0), .I_lp_tx_lane0_p(1'b0), .I_lp_tx_lane0_n(1'b0), .O_lane_error(S_lane_error));
 // ---- camera pipeline on hs_rx_clk (reset: merge_reset hsrx_rst_n, async assert / sync release in this clock)
 ui_csi_unpacket_4lane X_ui_csi_unpacket_4lane (.I_clk(S_hs_rx_clk), .I_rst_n(hsrx_rst_n), .I_hs_valid(S_hs_rx_valid), .I_hs_data(S_hs_rx_data),
  .O_csi_frame_start(S_csi_frame_start), .O_csi_frame_end(S_csi_frame_end), .O_csi_valid(S_csi_valid), .O_csi_data(S_csi_data));
 ui_raw10_unpacket_4lane X_ui_raw10_unpacket_4lane (.I_clk(S_hs_rx_clk), .I_rst_n(hsrx_rst_n), .I_csi_frame_start(S_csi_frame_start), .I_csi_frame_end(S_csi_frame_end),
  .I_csi_valid(S_csi_valid), .I_csi_data(S_csi_data), .O_raw10_frame_start(S_raw10_frame_start), .O_raw10_frame_end(S_raw10_frame_end),
  .O_raw10_valid(S_raw10_valid), .O_raw10_data(S_raw10_data));
 ui_image_correction #(.DATA_WIDTH(40), .TDEST_WIDTH(10)) X_ui_image_correction (.I_clk(S_hs_rx_clk), .I_rst_n(hsrx_rst_n), .I_raw_data(S_raw10_data),
  .I_raw_valid(S_raw10_valid), .I_raw_frame_start(S_raw10_frame_start), .I_raw_frame_end(S_raw10_frame_end),
  .O_raw_tdata(S_axis_tdata), .O_raw_tlast(S_axis_tlast), .O_raw_tvalid(S_axis_tvalid), .O_raw_tuser(S_axis_tuser));
 ui_isp_top X_ui_isp_top (.I_clk(S_hs_rx_clk), .I_rst_n(hsrx_rst_n), .I_tlast(S_axis_tlast), .I_tuser(S_axis_tuser), .I_tdata(S_axis_tdata), .I_tvalid(S_axis_tvalid),
  .I_tdest(), .O_tready(S_WF_tready), .O_tdata(S_ISP_O_tdata), .O_tlast(S_ISP_O_tlast), .O_tuser(S_ISP_O_tuser), .O_tvalid(S_ISP_O_tvalid), .I_tready());
 waveform_extract_axis4 #(.ROI_X_START(430), .ROI_X_END(1308), .ROI_Y_START(280), .ROI_Y_END(680), .TRACE_R_MIN(180), .TRACE_G_MIN(100), .TRACE_G_MARGIN(25),
  .TRACE_B_MAX(160), .TRACE_R_MAX(255), .TRACE_WHITE_MIN(256)) X_waveform_extract (
  .I_clk(S_hs_rx_clk), .I_rst_n(hsrx_rst_n), .I_tdata(S_ISP_O_tdata), .I_tlast(S_ISP_O_tlast), .I_tuser(S_ISP_O_tuser), .I_tvalid(S_ISP_O_tvalid), .I_tready(),
  .O_tdata(S_WF_tdata), .O_tlast(S_WF_tlast), .O_tuser(S_WF_tuser), .O_tvalid(S_WF_tvalid), .O_tready(1'b1),
  .O_sample_valid(S_wave_sample_valid), .O_sample_x(S_wave_sample_x), .O_sample_y(S_wave_sample_y), .O_sample_last(S_wave_sample_last),
  .O_frame_start(S_wave_frame_start), .O_frame_end(S_wave_frame_end));

 // ------------------------------------------------------------------ frame buffer (A's ui_dbuf, read side re-parameterised for the right half: D4)
 ui_setvbuf #(.BUF_DELAY(1), .BUF_LENTH(3)) X_ui_setvbuf (.I_bufn(S_wbuf_sync), .O_bufn(S_rbuf_sync));
 ui_dbuf #(.AXI_DATA_WIDTH(AXI_DATA_WIDTH), .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH), .ENABLE_VSYNC(1),
  .W_BUFDEPTH(1024), .W_DATAWIDTH(128), .W_BASEADDR(0), .W_DSIZEBITS(25), .W_XSIZE(480), .W_XSTRIDE(480), .W_YSIZE(1080), .W_XDIV(2), .W_BUFSIZE(3),
  .R_BUFDEPTH(512), .R_DATAWIDTH(64), .R_BASEADDR(0), .R_DSIZEBITS(25), .R_XSIZE(960), .R_XSTRIDE(960), .R_YSIZE(1080), .R_XDIV(2), .R_BUFSIZE(3)) X_ui_dbuf (
  .I_ui_clk(S_dfi_clk), .I_ui_rstn(S_ddr_init_cal_done), .I_W_en(1'b1), .I_W_wclk(S_hs_rx_clk),
  .I_W_tuser(S_WF_tuser), .I_W_tvalid(S_WF_tvalid), .I_W_tdata(S_WF_tdata), .I_W_tlast(S_WF_tlast), .O_W_tready(), .O_W_sync_cnt(S_wbuf_sync), .I_W_buf(S_wbuf_sync),
  .I_R_en(vtc_vs), .I_Rsync_en(1'b0), .I_R_rclk(pclk), .I_R_tready(cam_pop), .O_R_tuser(), .O_R_tvalid(cam_tvalid), .O_R_tdata(cam_tdata),
  .O_R_vrst(), .O_R_tlast(), .O_R_sync_cnt(), .I_R_buf(S_rbuf_sync),
  .O_fdma_waddr(S_fdma_waddr), .O_fdma_wareq(S_fdma_wareq), .O_fdma_wsize(S_fdma_wsize), .I_fdma_wbusy(S_fdma_wbusy), .O_fdma_wdata(S_fdma_wdata),
  .I_fdma_wvalid(S_fdma_wvalid), .O_fdma_wready(S_fdma_wready), .O_fdma_wbuf(), .O_fdma_wirq(),
  .O_fdma_raddr(S_fdma_raddr), .O_fdma_rareq(S_fdma_rareq), .O_fdma_rsize(S_fdma_rsize), .I_fdma_rbusy(S_fdma_rbusy), .I_fdma_rdata(S_fdma_rdata),
  .I_fdma_rvalid(S_fdma_rvalid), .O_fdma_rready(S_fdma_rready), .O_fdma_rbuf(), .O_fdma_rirq());
 ui_FDMA #(.M_AXI_B2B_SET(1), .M_AXI_ID_WIDTH(AXI_ID_WIDTH), .M_AXI_ADDR_WIDTH(AXI_ADDR_WIDTH), .M_AXI_DATA_WIDTH(AXI_DATA_WIDTH), .M_AXI_MAX_BURST_LEN(16)) X_ui_FDMA (
  .I_fdma_waddr(S_fdma_waddr), .I_fdma_wareq(S_fdma_wareq), .I_fdma_wsize(S_fdma_wsize), .O_fdma_wbusy(S_fdma_wbusy), .I_fdma_wdata(S_fdma_wdata),
  .O_fdma_wvalid(S_fdma_wvalid), .I_fdma_wready(1'b1),
  .I_fdma_raddr(S_fdma_raddr), .I_fdma_rareq(S_fdma_rareq), .I_fdma_rsize(S_fdma_rsize), .O_fdma_rbusy(S_fdma_rbusy), .O_fdma_rdata(S_fdma_rdata),
  .O_fdma_rvalid(S_fdma_rvalid), .I_fdma_rready(1'b1),
  .M_AXI_ACLK(S_dfi_clk), .M_AXI_ARESETN(S_ddr_init_cal_done),
  .M_AXI_AWID(S_axi_awid), .M_AXI_AWADDR(S_axi_awaddr), .M_AXI_AWLEN(S_axi_awlen), .M_AXI_AWSIZE(S_axi_awsize), .M_AXI_AWBURST(S_axi_awburst),
  .M_AXI_AWLOCK(S_axi_awlock), .M_AXI_AWCACHE(S_axi_awcache), .M_AXI_AWPROT(S_axi_awprot), .M_AXI_AWQOS(S_axi_awqos), .M_AXI_AWVALID(S_axi_awvalid), .M_AXI_AWREADY(S_axi_awready),
  .M_AXI_WDATA(S_axi_wdata), .M_AXI_WSTRB(S_axi_wstrb), .M_AXI_WLAST(S_axi_wlast), .M_AXI_WVALID(S_axi_wvalid), .M_AXI_WREADY(S_axi_wready),
  .M_AXI_BID(S_axi_bid), .M_AXI_BRESP(S_axi_bresp), .M_AXI_BVALID(S_axi_bvalid), .M_AXI_BREADY(S_axi_bready),
  .M_AXI_ARID(S_axi_arid), .M_AXI_ARADDR(S_axi_araddr), .M_AXI_ARLEN(S_axi_arlen), .M_AXI_ARSIZE(S_axi_arsize), .M_AXI_ARBURST(S_axi_arburst),
  .M_AXI_ARLOCK(S_axi_arlock), .M_AXI_ARCACHE(S_axi_arcache), .M_AXI_ARPROT(S_axi_arprot), .M_AXI_ARQOS(S_axi_arqos), .M_AXI_ARVALID(S_axi_arvalid), .M_AXI_ARREADY(S_axi_arready),
  .M_AXI_RID(S_axi_rid), .M_AXI_RDATA(S_axi_rdata), .M_AXI_RRESP(S_axi_rresp), .M_AXI_RLAST(S_axi_rlast), .M_AXI_RVALID(S_axi_rvalid), .M_AXI_RREADY(S_axi_rready));
 // DDR3 memory controller IP (MC0_DRAM_DDR3 + MC0_MIS_AXI as generated in ui_ddr.sv): the AXI/DDR3 branch of A's system_top, written out without the `ifdef
 ui_ddr X_ui_ddr (
  .sys_rst_n(pll_lock), .sys_clk(I_ddr_clk),
  .ddr_ck_p(ddr_ck_p), .ddr_ck_n(ddr_ck_n), .ddr_reset_n(ddr_reset_n), .ddr_cke(ddr_cke), .ddr_odt(ddr_odt), .ddr_cs_n(ddr_cs_n),
  .ddr_ras_n(ddr_ras_n), .ddr_cas_n(ddr_cas_n), .ddr_we_n(ddr_we_n), .ddr_ba(ddr_ba), .ddr_addr(ddr_addr),
  .ddr_dqs_p(ddr_dqs_p), .ddr_dqs_n(ddr_dqs_n), .ddr_dq(ddr_dq), .ddr_dm(ddr_dm),
  .ctl_ram_rst_n(), .ctl_ram_cke(), .dfi_clk(S_dfi_clk), .pll_locked(), .ddrphy_rst_n(), .ddr_init_cal_done(S_ddr_init_cal_done), .ddr_init_cal_err(), .ddr_init_cal_step(),
  .axi_aclk(), .axi_aresetn(),
  .axi_awid(S_axi_awid), .axi_awaddr(S_axi_awaddr), .axi_awlen(S_axi_awlen), .axi_awsize(S_axi_awsize), .axi_awburst(S_axi_awburst), .axi_awlock(S_axi_awlock),
  .axi_awcache(S_axi_awcache), .axi_awprot(S_axi_awprot), .axi_awqos(S_axi_awqos), .axi_awvalid(S_axi_awvalid), .axi_awready(S_axi_awready),
  .axi_wdata(S_axi_wdata), .axi_wstrb(S_axi_wstrb), .axi_wlast(S_axi_wlast), .axi_wvalid(S_axi_wvalid), .axi_wready(S_axi_wready),
  .axi_bid(S_axi_bid), .axi_bresp(S_axi_bresp), .axi_bvalid(S_axi_bvalid), .axi_bready(S_axi_bready),
  .axi_arid(S_axi_arid), .axi_araddr(S_axi_araddr), .axi_arlen(S_axi_arlen), .axi_arsize(S_axi_arsize), .axi_arburst(S_axi_arburst), .axi_arlock(S_axi_arlock),
  .axi_arcache(S_axi_arcache), .axi_arprot(S_axi_arprot), .axi_arqos(S_axi_arqos), .axi_arvalid(S_axi_arvalid), .axi_arready(S_axi_arready),
  .axi_rid(S_axi_rid), .axi_rdata(S_axi_rdata), .axi_rresp(S_axi_rresp), .axi_rlast(S_axi_rlast), .axi_rvalid(S_axi_rvalid), .axi_rready(S_axi_rready),
  .pzq_cal_done_i(), .pzq_cal_done_o(), .user_clk(), .apb_clk(), .mcu_busy(), .user_update(), .user_ram_addr(), .user_ram_wr_en(), .user_ram_rd_en(),
  .user_ram_wr_data(), .user_ram_rd_data(), .uart_rxd(), .uart_txd());

 // ------------------------------------------------------------------ A: wave sampling + report (BYTE_TAP=1) and DAC replay (sys_clk domain)
 wave_sample32_uart #(
  .SYS_CLK_HZ(25_000_000), .BAUD_RATE(115_200), .ROI_X_START(430), .ROI_X_END(1308), .ROI_Y_START(280), .ROI_Y_END(680), .EDGE_GUARD_PIXELS(12),
  .EDGE_AVERAGE_REJECT_ENABLE(1), .SAMPLE_COUNT(DAC_SAMPLE_COUNT), .DAC_Y_SCALE_NUM(DAC_Y_SCALE_NUM), .DAC_Y_SCALE_DEN(DAC_Y_SCALE_DEN),
  .DAC_Y_SCALE_OFFSET(DAC_Y_SCALE_OFFSET), .DAC_Y_ACTIVE_PX(DAC_Y_ACTIVE_PX), .DAC_Y_MID_PX(DAC_Y_MID_PX), .DAC_SIMPLE_MODE(DAC_SIMPLE_MODE), .DEBOUNCE_CYCLES(25_000), .Y_JUMP_MAX(100),
  .OUTLIER_THRESHOLD(1000), .OUTLIER_FILTER_ENABLE(0), .FRAME_WAIT_TIMEOUT_CYCLES(100_000_000), .INVALID_FILL_ENABLE(1), .LINEAR_INTERP_ENABLE(1), .BYTE_TAP(1)
 ) X_wave_sample32_uart (
  .I_sys_clk(I_sys_clk), .I_video_clk(S_hs_rx_clk), .I_rst_n(sys_rst_n), .I_capture_key_n(I_button[2]),
  .I_frame_start(S_wave_frame_start), .I_frame_end(S_wave_frame_end), .I_sample_valid(S_wave_sample_valid), .I_sample_x(S_wave_sample_x), .I_sample_y(S_wave_sample_y),
  .O_uart_tx(), .O_report_busy(S_uart_report_busy),
  .I_byte_ready(a_byte_ready), .O_tap_valid(a_tap_valid), .O_tap_data(a_tap_data), .O_tap_is_ack(a_tap_is_ack), .O_tap_rpt_req(a_rpt_req), .O_tap_ack_req(a_ack_req),
  .O_tap_rpt_len(a_rpt_len), .O_tap_req_drop(a_req_drop), .O_tap_stale_drop(a_stale_drop),
  .O_dac_sample_we(S_dac_sample_we), .O_dac_sample_addr(S_dac_sample_addr), .O_dac_sample_code(S_dac_sample_code),
  .O_dac_frame_commit(S_dac_frame_commit), .O_dac_frame_valid(S_dac_frame_valid),
  .O_dbg_raw_valid_0(cwc_probe0), .O_dbg_raw_valid_1(cwc_probe1), .O_dbg_raw_valid_2(cwc_probe2), .O_dbg_raw_valid_3(cwc_probe3),
  .O_dbg_bin14_status(cwc_probe4), .O_dbg_bin24_status(cwc_probe5));
 assign O_dac_pd = 1'b0;
 dac904_wave_replay #(.SAMPLE_COUNT(DAC_SAMPLE_COUNT), .ADDR_WIDTH(8), .SAMPLE_HOLD_CYCLES(DAC_HOLD_EFFECTIVE), .INTERP_UPDATE_DIV(DAC_INTERP_UPDATE_DIV),
  .TEST_WAVE_ENABLE(DAC_TEST_WAVE_ENABLE), .DAC_CAL_ENABLE(DAC_CAL_ENABLE), .IDLE_CODE(14'h2000)) X_dac904_wave_replay (
  .I_clk(I_sys_clk), .I_rst_n(sys_rst_n), .I_sample_we(S_dac_sample_we), .I_sample_addr(S_dac_sample_addr), .I_sample_code(S_dac_sample_code),
  .I_frame_commit(S_dac_frame_commit), .I_frame_valid(S_dac_frame_valid), .O_dac_clk(O_dac_clk), .O_dac_data(O_dac_data));

 // ------------------------------------------------------------------ B: measurement core (ADC, NCO/IQ, classifier, summary/trajectory generators, servo UART, scope data)
 // ------------------------------------------------------------------ Stage 7: work mode (D9 button) + camera one-period table for the servo
 wire [1:0] S_mode; wire [383:0] S_cam_points; wire S_cam_new, S_cam_valid, S_cam_fb, S_cam_rej, S_cam_busy; wire [7:0] S_cam_period;
 mode_ctrl #(.CLK_HZ(25000000), .LED_ACTIVE_LOW(LED_ACTIVE_LOW)) X_mode_ctrl (.I_clk(I_sys_clk), .I_rst_n(sys_rst_n), .I_key_n(I_button[1]), .O_mode(S_mode), .O_led(O_led));
 cam_period_table X_cam_period_table (.I_clk(I_sys_clk), .I_rst_n(sys_rst_n), .I_we(S_dac_sample_we), .I_addr(S_dac_sample_addr), .I_code(S_dac_sample_code),
  .I_commit(S_dac_frame_commit), .I_valid(S_dac_frame_valid), .O_points_flat(S_cam_points), .O_table_valid(S_cam_valid), .O_new(S_cam_new),
  .O_fallback(S_cam_fb), .O_reject(S_cam_rej), .O_busy(S_cam_busy), .O_period(S_cam_period));
 b_core #(.SYSCLK_HZ(25000000), .UART_BAUD(115200)) X_b_core (
  .sys_clk(I_sys_clk), .rst_n(b_rst_n), .key4(key4), .adc_clk(adc_clk), .adc_d(adc_d), .servo_tx(servo_tx), .servo_rx(servo_rx),
  .i_mode(S_mode), .i_cam_points_flat(S_cam_points), .i_cam_new(S_cam_new), .i_cam_valid(S_cam_valid),
  .sum_req(sum_req), .sum_valid(sum_valid), .sum_data(sum_data), .sum_ready(sum_ready),
  .trc_req(trc_req), .trc_valid(trc_valid), .trc_data(trc_data), .trc_ready(trc_ready),
  .o_scope_wave0_flat(b_w0), .o_scope_wave1_flat(b_w1), .o_scope_bank(b_bank), .o_scope_toggle(b_tog),
  .o_scope_frequency_x10(b_freq), .o_scope_amplitude_cv(b_amp), .o_scope_harmonics_cv(b_harm), .o_scope_harmonic_heights(b_hh),
  .o_scope_wave_type(b_type), .o_scope_status(b_stat));

 // ------------------------------------------------------------------ the shared T25 UART: s0 = A report, s1 = B summary (122), s2 = B trajectory (379), s3 = A key ack (5)
 assign a_byte_ready = m_r0 | m_r3;
 uart_t25_mux #(.SYS_CLK_HZ(25000000), .BAUD(115200), .STATUS_PERIOD_CYCLES(25000000)) X_uart_mux (
  .clk(I_sys_clk), .rst_n(sys_rst_n),
  .s0_req(a_rpt_req), .s0_len(a_rpt_len), .s0_valid(a_tap_valid & ~a_tap_is_ack), .s0_data(a_tap_data), .s0_ready(m_r0),
  .s1_req(sum_req),   .s1_len(16'd122),   .s1_valid(sum_valid),                   .s1_data(sum_data),   .s1_ready(sum_ready),
  .s2_req(trc_req),   .s2_len(16'd379),   .s2_valid(trc_valid),                   .s2_data(trc_data),   .s2_ready(trc_ready),
  .s3_req(a_ack_req), .s3_len(16'd5),     .s3_valid(a_tap_valid & a_tap_is_ack),  .s3_data(a_tap_data), .s3_ready(m_r3),
  .a_req_drop(a_req_drop), .a_stale_drop(a_stale_drop), .tx(O_uart_tx));
endmodule
