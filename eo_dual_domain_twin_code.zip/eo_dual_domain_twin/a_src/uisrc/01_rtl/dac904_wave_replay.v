`timescale 1ns / 1ns

// 128 点乒乓重放 + 播放侧线性插值。
//
// 每个采样点仍然保持 SAMPLE_HOLD_CYCLES 个时钟，整圈时长
// SAMPLE_COUNT * SAMPLE_HOLD_CYCLES 不变；只是在这一段时间内把输出从
// 当前点线性滑向下一个点，把"阶梯"变成"斜坡"。
//
// 它不增加采样信息：任意两个原始点之间仍然是一条直线，也不会把 128 点
// 变成真正的正弦。它的唯一作用是让 DAC 输出在示波器上不再呈方波状。
module dac904_wave_replay #(
    parameter integer SAMPLE_COUNT = 128,
    parameter integer ADDR_WIDTH = 8,
    parameter integer SAMPLE_HOLD_CYCLES = 1,
    parameter integer TEST_WAVE_ENABLE = 0,
    parameter [13:0] IDLE_CODE = 14'h2000,
    // 0 = 接缝保持最后一拍再跳；1 = 接缝也线性过渡。
    // ROI 现在覆盖整数个周期，首尾相位差 <1°，接缝插值不会造出陡斜坡；
    // 反而能消掉 SEAM_INTERP=0 时那一拍平直保持（示波器上表现为
    // 波谷处一个小平台）。默认 1。
    parameter integer SEAM_INTERP = 1,
    // 2026-11-02 调试：1 = 完全绕过插值（不乘、不加），每个采样点
    // 直接保持 SAMPLE_HOLD_CYCLES 拍。先把 DAC 波形和时序跑通；
    // 改回 0 恢复线性插值。
    parameter integer SIMPLE_MODE = 0,
    // 插值输出的更新分频：1 = 每个时钟更新（数据每 40 ns 翻转一次）。
    // 调大可以把 DAC 数据总线的翻转频率降低相应倍数，用来判断
    // "输出乱码"是总线采样裕量不足（A）还是算术错误（B）：
    //   DIV=4 后变干净 -> A；仍乱 -> B。
    // 波形形状不受影响：每个采样点仍然是 SAMPLE_HOLD_CYCLES 拍，
    // 只是斜坡被量化成更少的级数。
    parameter integer INTERP_UPDATE_DIV = 1,
    // 校准模式：输出 5 级阶梯（0 / 4096 / 8192 / 12288 / 16383），
    // 每级停留约 0.5 s。用于 P2 "DAC 相机闭环校准"：
    // 示波器上会看到 5 条水平电平线，用光标读出各自电压，
    // 再线性拟合 Vout = a*code + b，比假设满量程可靠。
    // 测完务必改回 0。
    parameter integer DAC_CAL_ENABLE = 0,
    // 2026-11-02：自动整周期循环。
    // 现象：示波器上每 609 us（= 128 点 x 119 拍 x 40 ns，正好一圈）出现
    // 一次相位回跳。原因：ROI 里实际装的是约 2.115 个周期而不是 2 个，
    // 首尾差约 0.115 周期（~41°），循环回到第 0 点时相位往回跳。
    // ROI 宽度靠手工标定永远对不准（相机位置、被拍示波器时基、信号频率
    // 一变就失配），所以改为：新帧提交后扫描一遍，找第一个和最后一个
    // "上升过中线"的点，只循环 [first_rise, last_rise) 这一段（整数个周期）。
    // 每点保持时间不变，因此输出频率不变，只是去掉了多出来的那段零头。
    // 0 = 恢复原来的 0..SAMPLE_COUNT-1 整帧循环。
    parameter integer AUTO_LOOP_ENABLE = 1,
    // 自动循环段至少要多长（点数），短于此值认为检测失败，退回整帧循环。
    parameter integer AUTO_LOOP_MIN_LEN = 16,
    // 峰峰值小于此码值时不做检测（无信号/直线），退回整帧循环。
    parameter integer AUTO_LOOP_MIN_PP = 256
)(
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_sample_we,
    input  wire [ADDR_WIDTH-1:0] I_sample_addr,
    input  wire [13:0] I_sample_code,
    input  wire        I_frame_commit,
    input  wire        I_frame_valid,
    output wire        O_dac_clk,
    output reg  [13:0] O_dac_data
);

    // 禁止把这两个数组推断成 RAM。
    //
    // 这段代码对数组的要求是：4 个异步读端口（2 个地址 x 2 个 bank）+ 2 个
    // 写端口。任何 RAM（含 LUTRAM）都提供不了这么多端口，一旦被推断成 RAM，
    // 读出的数据就会错位/返回旧值，DAC 上表现为满屏噪声。
    // 三角波（TEST_WAVE_ENABLE=1）不读这两个数组，所以在同样的时钟/引脚/
    // 约束下完全干净——这正好把问题指向了这里。
    (* syn_ramstyle = "registers" *) reg [13:0] frame_mem0 [0:SAMPLE_COUNT-1];
    (* syn_ramstyle = "registers" *) reg [13:0] frame_mem1 [0:SAMPLE_COUNT-1];
    reg active_bank;
    reg write_bank;
    reg pending_bank;
    reg pending_bank_valid;
    reg active_frame_valid;
    reg [ADDR_WIDTH-1:0] sample_index;
    localparam integer DIV_WIDTH = (SAMPLE_HOLD_CYCLES <= 1) ? 1 :
                                   $clog2(SAMPLE_HOLD_CYCLES);
    reg [DIV_WIDTH-1:0] sample_divider;
    wire sample_advance = (SAMPLE_HOLD_CYCLES <= 1) ||
                          (sample_divider == SAMPLE_HOLD_CYCLES - 1);
    function [13:0] triangle_code;
        input [ADDR_WIDTH-1:0] index;
        integer half_count;
        integer step_size;
        begin
            half_count = SAMPLE_COUNT / 2;
            step_size = 8192 / half_count;
            if (index < half_count)
                triangle_code = 14'h1000 + (index * step_size);
            else
                triangle_code = 14'h3000 - ((index - half_count) * step_size);
        end
    endfunction

    // ------------------------------------------------------------------
    // DAC 时钟：I_clk (25 MHz) 二分频 -> 12.5 MHz，寄存器输出。
    // 数据在它的下降沿更新，DAC 在上升沿采样 => 名义间隔 40 ns。
    // 引脚侧时序模型（TB）验证该相位为 0 违例；而 25 MHz + posedge 会是
    // 数据与采样沿重合（TB 报 58 次违例）。
    // 一帧仍是 128 点 x 100 拍 x 40 ns = 512 us。
    // ------------------------------------------------------------------
    reg dac_clk_div;
    assign O_dac_clk = dac_clk_div;

    // ---- 校准阶梯：0 / 4096 / 8192 / 12288 / 16383，每级约 0.5 s ----
    localparam [23:0] CAL_DWELL = 24'd12_500_000;   // 0.5 s @ 25 MHz
    reg [23:0] cal_cnt;
    reg [2:0]  cal_step;
    reg [13:0] cal_code;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            cal_cnt  <= 24'd0;
            cal_step <= 3'd0;
        end else if (cal_cnt == CAL_DWELL - 1'b1) begin
            cal_cnt  <= 24'd0;
            // Exactly five 0.5 s levels: 0, 4096, 8192, 12288, 16383.
            // Do not let the 3-bit counter dwell on the final level for
            // multiple extra slots before wrapping.
            if (cal_step == 3'd4)
                cal_step <= 3'd0;
            else
                cal_step <= cal_step + 1'b1;
        end else begin
            cal_cnt <= cal_cnt + 1'b1;
        end
    end
    always @* begin
        case (cal_step)
            3'd0: cal_code = 14'd0;
            3'd1: cal_code = 14'd4096;
            3'd2: cal_code = 14'd8192;
            3'd3: cal_code = 14'd12288;
            default: cal_code = 14'd16383;
        endcase
    end

    // ------------------------------------------------------------------
    // 播放侧插值：在第 i 点的保持时间内，输出从 y[i] 线性滑到 y[i+1]。
    // 这里的 cur/next 在"点切换"的那一刻锁存，因此实际是滞后一个点播放，
    // 对显示没有影响（整条波形只是晚 4 us 出现）。
    // ------------------------------------------------------------------
    // ---- 循环区间：当前播放段 [loop_start, loop_last] ----
    localparam integer AUTO_LOOP = (AUTO_LOOP_ENABLE != 0) &&
                                   (TEST_WAVE_ENABLE == 0);
    reg [ADDR_WIDTH-1:0] loop_start;
    reg [ADDR_WIDTH-1:0] loop_last;
    reg [ADDR_WIDTH-1:0] pend_loop_start;
    reg [ADDR_WIDTH-1:0] pend_loop_last;
    reg                  pending_ready;   // 待切换 bank 的周期检测已完成

    // ---- 周期检测扫描（新帧提交后 3 个阶段，约 260 拍，远短于一圈）----
    localparam [1:0] SCAN_IDLE   = 2'd0,
                     SCAN_MINMAX = 2'd1,
                     SCAN_CROSS  = 2'd2,
                     SCAN_DONE   = 2'd3;
    reg [1:0]            scan_state;
    reg [ADDR_WIDTH-1:0] scan_idx;
    reg [13:0]           scan_min;
    reg [13:0]           scan_max;
    reg [13:0]           thr_mid;
    reg [13:0]           thr_low;
    reg [13:0]           thr_high;
    reg                  scan_armed;
    reg                  rise_found;
    reg [ADDR_WIDTH-1:0] rise_first;
    reg [ADDR_WIDTH-1:0] rise_last;
    reg                  fall_armed;
    reg                  fall_found;
    reg [ADDR_WIDTH-1:0] fall_first;
    reg [ADDR_WIDTH-1:0] fall_last;
    // 只读待切换的 bank（它已停止写入），与播放端口互不影响
    wire [13:0] scan_code = pending_bank ? frame_mem1[scan_idx]
                                         : frame_mem0[scan_idx];
    wire [13:0] scan_min_nx = (scan_code < scan_min) ? scan_code : scan_min;
    wire [13:0] scan_max_nx = (scan_code > scan_max) ? scan_code : scan_max;
    wire [13:0] scan_pp_nx  = scan_max_nx - scan_min_nx;
    wire [ADDR_WIDTH-1:0] rise_span = rise_found ? (rise_last - rise_first)
                                                 : {ADDR_WIDTH{1'b0}};
    wire [ADDR_WIDTH-1:0] fall_span = fall_found ? (fall_last - fall_first)
                                                 : {ADDR_WIDTH{1'b0}};
    // 上升对和下降对取较长的那一段（周期数越多，接缝相位误差占比越小）。
    // 只要窗口 >= 1.5 个周期，两者至少有一个能凑成完整周期。
    wire use_rise = (rise_span >= fall_span);
    wire [ADDR_WIDTH-1:0] best_span  = use_rise ? rise_span  : fall_span;
    wire [ADDR_WIDTH-1:0] best_first = use_rise ? rise_first : fall_first;
    wire [ADDR_WIDTH-1:0] best_last  = use_rise ? rise_last  : fall_last;

    wire [ADDR_WIDTH-1:0] next_index =
        (sample_index == loop_last) ? loop_start
                                    : (sample_index + 1'b1);
    wire [13:0] play_cur = active_bank ? frame_mem1[sample_index]
                                       : frame_mem0[sample_index];
    wire [13:0] play_next = active_bank ? frame_mem1[next_index]
                                        : frame_mem0[next_index];
    wire [13:0] cur_code = (TEST_WAVE_ENABLE != 0) ? triangle_code(sample_index)
                                                   : play_cur;
    wire [13:0] nxt_code = (TEST_WAVE_ENABLE != 0) ? triangle_code(next_index)
                                                   : play_next;

    reg [13:0] interp_cur;
    reg [13:0] interp_next;
    reg signed [21:0] interp_frac;
    reg signed [21:0] interp_delta;
    reg [13:0] code_reg;

    // 用"乘倒数 + 移位"代替 (frac / SAMPLE_HOLD_CYCLES)。
    // 除法的综合结果在这里不可靠：板上出现过斜坡被放大、输出满量程回绕
    // 的现象，而仿真（逐拍比对）完全正确——典型的综合/仿真不一致。
    // 乘法各厂商综合器都稳定，因此改成定点乘。
    // 对 SAMPLE_HOLD_CYCLES=4 是精确的（2^20/4 整除），对 100 的误差
    // 不超过 1 个码。
    localparam integer INTERP_SHIFT = 20;
    localparam integer INTERP_MUL   = (1 << INTERP_SHIFT) / SAMPLE_HOLD_CYCLES;
    reg signed [47:0] interp_prod;
    localparam integer UPD_W = (INTERP_UPDATE_DIV <= 1) ? 1
                                                        : $clog2(INTERP_UPDATE_DIV);
    reg [UPD_W-1:0] update_divider;
    wire update_tick = (INTERP_UPDATE_DIV <= 1) ||
                       (update_divider == INTERP_UPDATE_DIV - 1);

    always @* begin
        interp_delta = $signed({8'd0, interp_next}) - $signed({8'd0, interp_cur});
        // 接缝保护：循环最后一点(loop_last)回到 loop_start 的那段保持平直，
        // 不生成 last->start 的斜坡。接缝发生在 next_index 回卷的那一拍，
        // 即 sample_index == loop_last（自动循环关闭时 = SAMPLE_COUNT-1）。
        if ((SEAM_INTERP == 0) && (sample_index == loop_last))
            interp_delta = 22'sd0;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            active_bank <= 1'b0;
            write_bank <= 1'b1;
            pending_bank <= 1'b0;
            pending_bank_valid <= 1'b0;
            active_frame_valid <= 1'b0;
            sample_index <= {ADDR_WIDTH{1'b0}};
            sample_divider <= {DIV_WIDTH{1'b0}};
            dac_clk_div <= 1'b0;
            interp_cur <= IDLE_CODE;
            interp_next <= IDLE_CODE;
            interp_frac <= 22'sd0;
            code_reg <= IDLE_CODE;
            loop_start <= {ADDR_WIDTH{1'b0}};
            loop_last <= SAMPLE_COUNT - 1;
            pend_loop_start <= {ADDR_WIDTH{1'b0}};
            pend_loop_last <= SAMPLE_COUNT - 1;
            pending_ready <= 1'b0;
            scan_state <= SCAN_IDLE;
            scan_idx <= {ADDR_WIDTH{1'b0}};
            scan_min <= 14'h3fff;
            scan_max <= 14'h0000;
            thr_mid <= 14'h0000;
            thr_low <= 14'h0000;
            thr_high <= 14'h0000;
            scan_armed <= 1'b0;
            rise_found <= 1'b0;
            rise_first <= {ADDR_WIDTH{1'b0}};
            rise_last <= {ADDR_WIDTH{1'b0}};
            fall_armed <= 1'b0;
            fall_found <= 1'b0;
            fall_first <= {ADDR_WIDTH{1'b0}};
            fall_last <= {ADDR_WIDTH{1'b0}};
        end else begin
            // 双提交守卫：上一帧还没在循环边界被消费时（pending_bank_valid=1），
            // 新一帧既不写入也不提交。否则 write_bank 已翻到"正在显示的那个
            // bank"，会把屏幕上的画面写花（撕裂）。代价是这一帧被丢弃——
            // 但串口报文要 2.85 ms，正常不会在 512 us 内连交两帧。
            if (I_sample_we && (I_sample_addr < SAMPLE_COUNT) &&
                !pending_bank_valid) begin
                if (write_bank)
                    frame_mem1[I_sample_addr] <= I_sample_code;
                else
                    frame_mem0[I_sample_addr] <= I_sample_code;
            end

            if (I_frame_commit && I_frame_valid && !pending_bank_valid) begin
                pending_bank <= write_bank;
                pending_bank_valid <= 1'b1;
                write_bank <= ~write_bank;
                pend_loop_start <= {ADDR_WIDTH{1'b0}};
                pend_loop_last <= SAMPLE_COUNT - 1;
                if (AUTO_LOOP) begin
                    pending_ready <= 1'b0;
                    scan_state <= SCAN_MINMAX;
                    scan_idx <= {ADDR_WIDTH{1'b0}};
                    scan_min <= 14'h3fff;
                    scan_max <= 14'h0000;
                end else begin
                    pending_ready <= 1'b1;
                end
            end

            // ---- 周期检测：找第一个/最后一个过中线的点（上升、下降各一组）----
            // 中线 = (min+max)/2；回滞：上升必须先低于 mid-(pp/8)、下降必须先
            // 高于 mid+(pp/8) 才允许下一次过中线，避免噪声在中线附近反复触发。
            case (scan_state)
                SCAN_MINMAX: begin
                    scan_min <= scan_min_nx;
                    scan_max <= scan_max_nx;
                    if (scan_idx == SAMPLE_COUNT - 1) begin
                        thr_mid <= scan_min_nx + (scan_pp_nx >> 1);
                        thr_low <= scan_min_nx + (scan_pp_nx >> 1) -
                                   (scan_pp_nx >> 3);
                        thr_high <= scan_min_nx + (scan_pp_nx >> 1) +
                                    (scan_pp_nx >> 3);
                        scan_idx <= {ADDR_WIDTH{1'b0}};
                        scan_armed <= 1'b0;
                        rise_found <= 1'b0;
                        rise_first <= {ADDR_WIDTH{1'b0}};
                        rise_last <= {ADDR_WIDTH{1'b0}};
                        fall_armed <= 1'b0;
                        fall_found <= 1'b0;
                        fall_first <= {ADDR_WIDTH{1'b0}};
                        fall_last <= {ADDR_WIDTH{1'b0}};
                        scan_state <= SCAN_CROSS;
                    end else begin
                        scan_idx <= scan_idx + 1'b1;
                    end
                end
                SCAN_CROSS: begin
                    if (scan_code < thr_low) begin
                        scan_armed <= 1'b1;
                    end else if (scan_armed && (scan_code >= thr_mid)) begin
                        scan_armed <= 1'b0;
                        if (!rise_found) begin
                            rise_found <= 1'b1;
                            rise_first <= scan_idx;
                        end
                        rise_last <= scan_idx;
                    end
                    if (scan_code > thr_high) begin
                        fall_armed <= 1'b1;
                    end else if (fall_armed && (scan_code <= thr_mid)) begin
                        fall_armed <= 1'b0;
                        if (!fall_found) begin
                            fall_found <= 1'b1;
                            fall_first <= scan_idx;
                        end
                        fall_last <= scan_idx;
                    end
                    if (scan_idx == SAMPLE_COUNT - 1)
                        scan_state <= SCAN_DONE;
                    else
                        scan_idx <= scan_idx + 1'b1;
                end
                SCAN_DONE: begin
                    // 循环 [first, last-1]，长度 = 整数个周期；
                    // 检测失败则保持提交时预置的整帧 0..SAMPLE_COUNT-1
                    if ((best_span >= AUTO_LOOP_MIN_LEN) &&
                        ((scan_max - scan_min) >= AUTO_LOOP_MIN_PP)) begin
                        pend_loop_start <= best_first;
                        pend_loop_last <= best_last - 1'b1;
                    end
                    pending_ready <= 1'b1;
                    scan_state <= SCAN_IDLE;
                end
                default: ;
            endcase

            if (sample_advance) begin
                sample_divider <= {DIV_WIDTH{1'b0}};
                if (sample_index == loop_last) begin
                    if (pending_bank_valid && pending_ready) begin
                        active_bank <= pending_bank;
                        pending_bank_valid <= 1'b0;
                        pending_ready <= 1'b0;
                        active_frame_valid <= 1'b1;
                        loop_start <= pend_loop_start;
                        loop_last <= pend_loop_last;
                        sample_index <= pend_loop_start;
                    end else begin
                        sample_index <= loop_start;
                    end
                end else begin
                    sample_index <= sample_index + 1'b1;
                end
            end else begin
                sample_divider <= sample_divider + 1'b1;
            end

            // 插值状态机
            if (SIMPLE_MODE != 0) begin
                // 调试模式：不做插值，采样点直接保持，避免 48 位乘法器
                if (sample_advance)
                    code_reg <= cur_code;
            end else if (!active_frame_valid) begin
                // 上电/无有效帧时跟随存储器，等第一帧到达就能直接播
                interp_cur <= cur_code;
                interp_next <= nxt_code;
                interp_frac <= 22'sd0;
                code_reg <= IDLE_CODE;
            end else if (sample_advance) begin
                // 刚播完一段：锁存新起点/终点，第一个时钟输出起点本身，
                // 保证每个原始点都精确经过
                interp_cur <= cur_code;
                interp_next <= nxt_code;
                interp_frac <= 22'sd0;
                code_reg <= cur_code;
            end else begin
                interp_frac <= interp_frac + interp_delta;
                // 只有 update_tick 那拍才真正更新 DAC 数据，
                // 这样数据总线的翻转频率 = 25MHz / INTERP_UPDATE_DIV
                if (update_tick) begin
                    interp_prod = (interp_frac + interp_delta) * INTERP_MUL;
                    code_reg <= $signed({8'd0, interp_cur}) +
                                (interp_prod >>> INTERP_SHIFT);
                end
            end

            // 校准模式优先：直接输出阶梯码，绕过插值和 frame_mem
            if (DAC_CAL_ENABLE != 0)
                code_reg <= cal_code;

            // DAC 时钟二分频
            dac_clk_div <= ~dac_clk_div;

            // 更新率分频计数器
            if (sample_advance || update_tick)
                update_divider <= {UPD_W{1'b0}};
            else
                update_divider <= update_divider + 1'b1;

        end
    end

    // DAC 数据输出寄存器：在 dac_clk_div 的下降沿更新（每两个 I_clk 一次），
    // 让数据比下一个采样上升沿早 40 ns。
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)
            O_dac_data <= IDLE_CODE;
        else if ((TEST_WAVE_ENABLE == 0) && (DAC_CAL_ENABLE == 0) && !active_frame_valid)
            O_dac_data <= IDLE_CODE;
        else if (dac_clk_div == 1'b1)
            O_dac_data <= code_reg;
    end

endmodule
