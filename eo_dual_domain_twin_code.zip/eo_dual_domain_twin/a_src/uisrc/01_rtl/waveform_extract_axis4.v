`timescale 1ns/1ps

// 4 像素/拍的 RGB888 波形提取模块
//
// 用途：
//   接在官方 ISP 输出与 uidbuf 写入口之间，图像数据原样透传；
//   同时在固定 ROI 四条边上叠加彩色边框，便于 HDMI 直接观察 ROI；
//   同时在固定 ROI 内从绿色波形轨迹提取坐标。
//
// 输入数据格式（与官方 ui_data96_128/ui_isp_top 对齐）：
//   I_tdata[127:120] : 保留字节，通常为 0
//   I_tdata[119:96]  : RGB 像素 3
//   I_tdata[95:88]   : 保留字节，通常为 0
//   I_tdata[87:64]   : RGB 像素 2
//   I_tdata[55:32]   : RGB 像素 1
//   I_tdata[23:0]    : RGB 像素 0
//
// 坐标输出：
//   O_sample_valid 为 1 时，O_sample_x/O_sample_y 有效；
//   一个 4 像素数据拍最多输出一个坐标，y 为检测到的像素 y 坐标平均值。
//   如果一拍检测到多个像素，使用它们的平均 y。
//
// 注意：
//   该模块只做“固定 ROI + 绿色轨迹阈值提取”，不做自动 ROI。
//   先将示波器屏幕和摄像头固定，再通过参数调 TRACE_* 阈值。

module waveform_extract_axis4 #(
    parameter integer IMG_WIDTH       = 1920,
    parameter integer IMG_HEIGHT      = 1080,

    parameter integer ROI_X_START     = 200,
    parameter integer ROI_X_END       = 1720,
    parameter integer ROI_Y_START     = 100,
    parameter integer ROI_Y_END       = 980,

    // 橙黄色波形判定参数：高 R、高 G、低 B。
    parameter integer TRACE_R_MIN     = 180,
    parameter integer TRACE_G_MIN     = 100,
    parameter integer TRACE_G_MARGIN  = 25,
    parameter integer TRACE_B_MAX     = 160,
    parameter integer TRACE_R_MAX     = 255,
    parameter integer TRACE_WHITE_MIN = 210,

    // ROI 边框颜色，RGB888
    parameter [23:0] ROI_BOX_COLOR    = 24'hFF0000,
    // ROI 内识别到的波形高亮颜色，RGB888
    parameter [23:0] TRACE_HIGHLIGHT_COLOR = 24'hFFFF00,
    // 坐标验证点颜色，RGB888；命中的波形像素显示为蓝色
    parameter [23:0] COORD_POINT_COLOR = 24'h0000FF
) (
    input  wire         I_clk,
    input  wire         I_rst_n,

    input  wire [127:0] I_tdata,
    input  wire          I_tlast,
    input  wire          I_tuser,
    input  wire          I_tvalid,
    output wire          I_tready,

    output reg  [127:0] O_tdata,
    output wire          O_tlast,
    output wire          O_tuser,
    output wire          O_tvalid,
    input  wire          O_tready,

    output reg           O_sample_valid,
    output reg  [15:0]   O_sample_x,
    output reg  [15:0]   O_sample_y,
    output reg           O_sample_last,
    output reg           O_frame_start,
    output reg           O_frame_end
);

    // 不改变官方视频链路的 AXI-Stream 握手
    assign I_tready = O_tready;
    assign O_tlast  = I_tlast;
    assign O_tuser  = I_tuser;
    assign O_tvalid = I_tvalid;

    // ROI 边框叠加。
    // 官方 ISP 输出为 4 个 RGB888 像素/拍，像素位置为：
    // pixel0=TDATA[23:0]，pixel1=TDATA[55:32]，
    // pixel2=TDATA[87:64]，pixel3=TDATA[119:96]。
    // 其余每个像素间隔的 8 bit 保留位保持原值。
    reg [15:0] overlay_x;
    reg [15:0] overlay_y;
    integer overlay_lane;
    integer overlay_pixel_x;

    always @* begin
        O_tdata  = I_tdata;
        overlay_x = I_tuser ? 16'd0 : x_count;
        overlay_y = I_tuser ? 16'd0 : y_count;

        for (overlay_lane = 0; overlay_lane < 4; overlay_lane = overlay_lane + 1) begin
            overlay_pixel_x = overlay_x + overlay_lane;
            if ((overlay_pixel_x >= ROI_X_START) &&
                (overlay_pixel_x <= ROI_X_END) &&
                (overlay_y >= ROI_Y_START) &&
                (overlay_y <= ROI_Y_END)) begin
                // ROI 边框优先显示为红色；命中的每列波形坐标点显示为蓝色。
                if ((overlay_pixel_x == ROI_X_START) ||
                    (overlay_pixel_x == ROI_X_END) ||
                    (overlay_y == ROI_Y_START) ||
                    (overlay_y == ROI_Y_END)) begin
                    O_tdata[overlay_lane*32 +: 24] = ROI_BOX_COLOR;
                end else begin
                    case (overlay_lane)
                        0: if (hit0) O_tdata[overlay_lane*32 +: 24] = COORD_POINT_COLOR;
                        1: if (hit1) O_tdata[overlay_lane*32 +: 24] = COORD_POINT_COLOR;
                        2: if (hit2) O_tdata[overlay_lane*32 +: 24] = COORD_POINT_COLOR;
                        3: if (hit3) O_tdata[overlay_lane*32 +: 24] = COORD_POINT_COLOR;
                        default: ;
                    endcase
                end
            end
        end
    end

    reg [15:0] x_count;
    reg [15:0] y_count;

    wire fire = I_tvalid && O_tready;

    // 每拍四个 RGB888 像素，按照官方数据重排顺序取出
    wire [23:0] pixel0 = I_tdata[23:0];
    wire [23:0] pixel1 = I_tdata[55:32];
    wire [23:0] pixel2 = I_tdata[87:64];
    wire [23:0] pixel3 = I_tdata[119:96];

    wire [7:0] r0 = pixel0[23:16];
    wire [7:0] g0 = pixel0[15:8];
    wire [7:0] b0 = pixel0[7:0];
    wire [7:0] r1 = pixel1[23:16];
    wire [7:0] g1 = pixel1[15:8];
    wire [7:0] b1 = pixel1[7:0];
    wire [7:0] r2 = pixel2[23:16];
    wire [7:0] g2 = pixel2[15:8];
    wire [7:0] b2 = pixel2[7:0];
    wire [7:0] r3 = pixel3[23:16];
    wire [7:0] g3 = pixel3[15:8];
    wire [7:0] b3 = pixel3[7:0];

    function trace_pixel;
        input [7:0] r;
        input [7:0] g;
        input [7:0] b;
        reg orange_trace;
        reg white_trace;
        begin
            // 橙黄色波形通常满足：R 较高、G 较高、B 较低，
            // 且 R 不低于 G、G 与 B 之间有明显色差。
            orange_trace = (r >= TRACE_R_MIN) &&
                           (g >= TRACE_G_MIN) &&
                           ({1'b0,r} >= {1'b0,g}) &&
                           ({1'b0,g} >= ({1'b0,b} + TRACE_G_MARGIN)) &&
                           (r <= TRACE_R_MAX) &&
                           (b <= TRACE_B_MAX);
            white_trace = (r >= TRACE_WHITE_MIN) &&
                          (g >= TRACE_WHITE_MIN) &&
                          (b >= TRACE_WHITE_MIN);
            trace_pixel = orange_trace || white_trace;
        end
    endfunction

    wire hit0 = trace_pixel(r0, g0, b0);
    wire hit1 = trace_pixel(r1, g1, b1);
    wire hit2 = trace_pixel(r2, g2, b2);
    wire hit3 = trace_pixel(r3, g3, b3);

    integer hit_count;
    integer x_sum;
    integer y_sum;
    reg [15:0] avg_x;
    reg [15:0] avg_y;

    // 坐标计数和提取结果均在视频时钟域产生。
    // tuser 表示帧起始；tlast 表示当前行结束。
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            x_count        <= 16'd0;
            y_count        <= 16'd0;
            O_sample_valid <= 1'b0;
            O_sample_x     <= 16'd0;
            O_sample_y     <= 16'd0;
            O_sample_last  <= 1'b0;
            O_frame_start  <= 1'b0;
            O_frame_end    <= 1'b0;
        end else begin
            O_sample_valid <= 1'b0;
            O_sample_last  <= 1'b0;
            O_frame_start  <= 1'b0;
            O_frame_end    <= 1'b0;

            if (fire) begin
                // 帧首拍优先清零坐标
                if (I_tuser) begin
                    x_count       <= 16'd0;
                    y_count       <= 16'd0;
                    O_frame_start <= 1'b1;
                end

                hit_count = 0;
                x_sum = 0;
                y_sum = 0;

                // 当前拍四个像素的绝对坐标
                if ((x_count     >= ROI_X_START) && (x_count     <= ROI_X_END) &&
                    (y_count     >= ROI_Y_START) && (y_count     <= ROI_Y_END) &&
                    hit0) begin hit_count = hit_count + 1; x_sum = x_sum + x_count;     y_sum = y_sum + y_count; end
                if ((x_count + 1 >= ROI_X_START) && (x_count + 1 <= ROI_X_END) &&
                    (y_count     >= ROI_Y_START) && (y_count     <= ROI_Y_END) &&
                    hit1) begin hit_count = hit_count + 1; x_sum = x_sum + x_count + 1; y_sum = y_sum + y_count; end
                if ((x_count + 2 >= ROI_X_START) && (x_count + 2 <= ROI_X_END) &&
                    (y_count     >= ROI_Y_START) && (y_count     <= ROI_Y_END) &&
                    hit2) begin hit_count = hit_count + 1; x_sum = x_sum + x_count + 2; y_sum = y_sum + y_count; end
                if ((x_count + 3 >= ROI_X_START) && (x_count + 3 <= ROI_X_END) &&
                    (y_count     >= ROI_Y_START) && (y_count     <= ROI_Y_END) &&
                    hit3) begin hit_count = hit_count + 1; x_sum = x_sum + x_count + 3; y_sum = y_sum + y_count; end

                if ((hit_count != 0) &&
                    (x_count + 3 >= ROI_X_START) &&
                    (x_count <= ROI_X_END)) begin
                    O_sample_valid <= 1'b1;
                    case (hit_count)
                        1: begin avg_x = x_sum;       avg_y = y_sum;       end
                        2: begin avg_x = x_sum >> 1;  avg_y = y_sum >> 1;  end
                        3: begin avg_x = x_sum / 3;    avg_y = y_sum / 3;    end
                        default: begin avg_x = x_sum >> 2; avg_y = y_sum >> 2; end
                    endcase
                    O_sample_x     <= avg_x;
                    O_sample_y <= avg_y;
                end

                if (I_tlast) begin
                    x_count       <= 16'd0;
                    y_count       <= y_count + 16'd1;
                    O_sample_last <= 1'b1;
                    if (y_count == (IMG_HEIGHT - 1))
                        O_frame_end <= 1'b1;
                end else if (I_tuser) begin
                    x_count <= 16'd4;
                end else begin
                    x_count <= x_count + 16'd4;
                end
            end
        end
    end

endmodule
