# ===========================================================================
# 4b FIX after the 2nd synthesis (run.log): every  get_cells -o -hier {...}  line FAILED in TD 6.2 ("USR-8011 ERROR: get_cells: invalid option -o"), so in that run NONE of the
# cell-based exceptions (E01-E14, D1, D3, D4) was applied; only get_pins/get_ports ones (E15, adc_d, DAC) were.  This file now uses get_pins with the netlist names seen in the
# TD timing report (<reg>_reg[..] with pins .clk/.d/.sr; hierarchy separator '/').  The pin names are PATTERNS: the next run's log must show no "No pins matched" warning for any of them.
# E03 also used a port name (I_capture_key_n) that is not a port of the merged top: the pad is I_button[2].  F01 (reset-pin exception for the ui_dbuf FIFO reset synchronisers) is new.
# Previous file kept as constraints/merge_syn2_timing_v1_getcells.sdc.bak for the diff.
# ===========================================================================
# ===========================================================================
# SECOND SYNTHESIS (Stage 4b, top merge_top_full): this file = merge_stage3_timing_v2.sdc with ONLY these edits (diff: stage4/docs/merge_syn2_timing_vs_v2.diff):
#   * PLL clock paths and the E15 pin get the hierarchy prefix  u_disp/  (the PLL, merge_reset, VTC and HDMI live in merge_top_s3 = u_disp)
#   * B's ADC clock port is  adc_clk  (was O_adc_clk in the draft)
# Everything else (E01-E15, D1/D3/D4 and their bounds) is unchanged and NEVER RAN IN TD BEFORE: expect SDC warnings/errors on the first run; read the TD log, do not
# silence them.  Names are verified against the netlist with tools/sdc_match_check.py (0 matches = the exception does nothing = FAIL).
# ===========================================================================
# ===========================================================================
# STAGE 3 merged timing constraints - DRAFT v2, describes the FINAL R-2 RTL (Gray request tag, FMT=02, HS_RX meter). Never run in TD; register names are PATTERNS to be verified in the
# synthesised netlist, every line marked [VERIFY-NAME] must be checked before use).
# Decisions in force: D3 per-signal CDC, NO blanket set_clock_groups -asynchronous, NO blanket false_path,
#   sys_clk and its PLL-derived clocks stay one synchronous group (fully timed).
#   set_max_delay -datapath_only is used ONLY for the bundled-data payloads whose stability proof is complete (section 2 below,
#   each with its forward/reverse window argument); adc_d is a port input budget, not a CDC payload.
# Every exception below has a row in reports/CDC_exceptions.csv (source / destination / type / reason).
# MATCH COUNTS: get_cells is used WITHOUT -nowarn so TD prints a warning for a zero-match pattern (SWUG200 3.1.7); TD's documentation does not
# describe Tcl control flow in SDC, so a hard 'error on zero matches' inside the SDC is NOT assumed. The authoritative check is
# tools/sdc_match_check.py (run on the synthesised netlist's instance list) and its per-exception counts go into the final report.
# ===========================================================================

# ---- primary clocks (A) ----
create_clock -name {ddr_clk} -period 10.000 -waveform {0.000 5.000} [get_ports {I_ddr_clk}]
create_clock -name {sys_clk} -period 40.000 -waveform {0.000 20.000} [get_ports {I_sys_clk}]
derive_clocks

# ---- PLL outputs, CORRECTED mapping (ui_pll: clkc[0]=137.5 MHz, [1]=687.5 MHz, [2]=25 MHz, [3]=68.75 MHz) ----
# A's original timing.sdc has these names shifted (clkc[0] was called clk_25m). Names are cosmetic, periods come from the PLL.
rename_clock -name {pclkx1} [get_clocks {u_disp/X_ui_pll/pll_inst.clkc[0]}]
rename_clock -name {pclkx5} [get_clocks {u_disp/X_ui_pll/pll_inst.clkc[1]}]
rename_clock -name {clk_25m} [get_clocks {u_disp/X_ui_pll/pll_inst.clkc[2]}]
rename_clock -name {clk_70m} [get_clocks {u_disp/X_ui_pll/pll_inst.clkc[3]}]

# ---- camera byte clock (A), 100 MHz upper bound until measured ----
create_clock -name {hs_rx_clk} -period 10.000 [get_pins {u_mipi_dphy_rx_ph1a_mipiio_wrapper/u_ph1a_mipiio_wrapper/u_PH1_PHY_MIPIIO.hsrx_byteclk_to_fabric}]

# ---- B ADC (kept from B) ----
create_generated_clock -name {adc_3m125} -source [get_ports {I_sys_clk}] -divide_by 8 [get_ports {adc_clk}]   ;# [VERIFY-NAME] port names after pin merge
# adc_d input budget (the ONE -datapath_only kept from B; a pad-to-register input budget, NOT a CDC payload - user decision 3).
# Basis of the 40 ns (all from B's own SDC/RTL comments, nothing assumed here):
#   * adc_3m125 = sys_clk / 8 = 3.125 MHz, period 320 ns. B samples adc_d only on the enabled ADC falling edge (HALF_DIV=4),
#     i.e. 160 ns after the ADC rising edge that launches the data.
#   * budget = <= 40 ns on-chip (pad -> sampling register, this constraint) + <= 30 ns assumed external return = <= 70 ns,
#     leaving >= 90 ns of the 160 ns window.
#   * The ADC DEVICE data-valid window (output delay after the clock edge and hold after the next) is NOT in the project files;
#     the 30 ns external figure and "data valid through the sampling edge until the next rising edge (~160 ns later)" are B's
#     assumptions and must be confirmed against the ADC datasheet / board measurement. -datapath_only also disables hold analysis here,
#     so board-level hold is NOT signed off by this SDC.
set_max_delay 40.000 -datapath_only -from [get_ports {adc_d[*]}]                                              ;# [VERIFY-NAME]

# ---- DAC bound kept from A (unchanged, see A timing.sdc comments) ----
set_output_delay -clock [get_clocks {sys_clk}] -max 17.000 [get_ports {O_dac_data[*]}]
set_output_delay -clock [get_clocks {sys_clk}] -min 0.000  [get_ports {O_dac_data[*]}]

# ---- DDR: vendor SDC (ui_ddr.sdc / ddr_ip.adc) is kept native and added to the project unchanged ----


# ===========================================================================
# ASYNC CLOCK GROUPS (4b-fix9) - A's ORIGINAL timing.sdc arrangement (baseline_A/uisrc/04_pin/timing.sdc:54-57), restored for hs_rx_clk and the DDR dfi clock.
# This REVERSES decision D3 for these domains ONLY (per-signal exceptions E01,E02,E06-E14,E16,E17,F01 are removed: they were moot inside the groups and their
# cell names drift with every P&R, which kept the invalid-constraint gate above 0).  sys_clk, clk_25m, clk_70m, pclkx1 and pclkx5 stay ONE synchronous group
# (same as A), so the B scope sys -> pixel exceptions (D3 12 ns, D4 40 ns, E04, E05) and the pixel -> serial reset (E15) still apply.
# A's design closed timing and ran on hardware with exactly this grouping.
# dfi clock is named by its PLL pin, as in A's timing.sdc (the IP sdc renames it to dfi_clk later).
set_clock_groups -asynchronous \
    -group [get_clocks {hs_rx_clk}] \
    -group [get_clocks {sys_clk clk_25m clk_70m pclkx1 pclkx5}] \
    -group [get_clocks {X_ui_ddr/u_ddrmc_top/u_ddr_phy/u_ddrphy_clk_gen/u_ddrphy_pll1/pll_inst.clkc[0]}]

# ===========================================================================
# SECTION 1 - SINGLE-BIT synchroniser first stages: set_false_path -to <first flop>.  Only source->first-stage is cut; the second
# stage and everything after stays timed.  Multi-bit values appear here ONLY when Gray coded (one bit changes per event) and every
# bit has its own 2-FF chain.
# ===========================================================================
# E01 A wave_sample32_uart: sys -> video  req_gray_sys[1:0] (Gray request tag, a flop) -> req_gray_meta[1:0]   (replaces capture_toggle_*)
# E02 A wave_sample32_uart: video -> sys  frame_toggle -> frame_toggle_meta
# E03 A wave_sample32_uart: asynchronous key input -> key_meta
set_false_path -from [get_ports {I_button[2]}] -to [get_cells {X_wave_sample32_uart/key_meta_reg* X_wave_sample32_uart/key_sync_reg*}]   ;# E03 (4b-fix9): pattern list (meta or sync may carry the packed cell name)
# E04 B scope core: sys -> pixel  scope_commit_toggle -> update_meta
set_false_path -to [get_cells {u_disp/X_scope/update_meta_reg* u_disp/X_scope/update_sync_reg* u_disp/X_scope/update_seen_reg*}]   ;# E04 (4b-fix9): pattern list; sys -> pclkx1 stays in ONE sync group so this exception is still needed (P&R: setup -1.885 at update_meta_reg)
# E05 B scope core: sys -> pixel  scope_published_bank -> bank_meta
set_false_path -to [get_cells {u_disp/X_scope/bank_meta_reg* u_disp/X_scope/bank_sync_reg*}]   ;# E05 (4b-fix9): pattern list; no -from
# E06 A ui_dbuf: W_wclk (hs_rx_clk) -> ui_clk (dfi_clk)  wfifo_rst_done (long level) -> wfifo_rst_done_r1
# E07 A ui_dbuf: hs_rx_clk -> dfi_clk  W_tuser_r3 -> wfs_r1.  W_tuser_r3 = W_tuser_r2|W_tuser_r1|I_W_tuser is high for >= 3 hs_rx_clk
#     cycles (C-08): >= 30 ns even at 100 MHz, vs. a dfi_clk period of ~4.3 ns.  dfi_clk provenance: DDR IP configuration baseline_A/uisrc/03_ip/al_ip/ui_ddr/ui_ddr.ipc
#     <MEMCLK_FREQUENCY>933.000000</MEMCLK_FREQUENCY> MHz (line 17); dfi_clk = MEMCLK/4 = 233.3 MHz (4.286 ns), consistent with the user's STA report (DDR PHY group Min
#     Period 4.172 ns / Fmax 239.693 MHz).  The /4 ratio is an inference (4:1 DFI), only the consistency with that STA report supports it.
#     A pulse of >= 1.5 periods of the sampling clock is what a 2-FF sampler needs.
# E08 A ui_dbuf: pclkx1 -> dfi_clk  I_R_en (= vtc_vs, a whole-line-wide level) -> rfs_r1.  Source flop is the VTC vs register in the pixel domain.
# E09 A R-2 status request: sys -> video  tq_req_sys -> tq_req_meta (single-bit toggle)
# E10 A R-2 status acknowledge: video -> sys  tq_ack -> tq_ack_meta (single-bit toggle, written one video clock after tq_*)
# E11 A R-2 HS_RX meter gate: sys -> video  fm_gate_sys -> fm_gate_meta (single-bit level, flop output)
# E12 A R-2 HS_RX meter done: video -> sys  fm_done -> fm_done_meta (single-bit toggle; fm_result is written first, see D3)
# E13 A sfifo (vendor, B5): Gray pointer, registered bin2gray output, one bit changes per +1 -> sync_r1 (first stage of a 2-FF chain per bit).
#     Two instances (write pointer -> read side, read pointer -> write side).  The dual-clock RAM itself needs no exception here: write and
#     read happen in their own clocks inside the RAM primitive and the data is only used after the pointer has crossed.
# E13 (4b-fix7) REPLACES the old first-stage false_path.  Reason (P&R viol_pr6.rpt): TD packs the sfifo Gray-pointer chain (primary_addr_gray_reg -> sync_r1 ->
#     primary_addr_gray_sync -> secondary_addr_o) together with rd_addr/wr_addr flops and names the packed cell after an ARBITRARY member (endpoints seen:
#     rd_addr_reg[8], wr_addr_reg[0], primary_addr_gray_sync_reg[4], sync_r1_reg[7], secondary_addr_o_reg[4]), so no cell-name pattern can cover it.  Worst P&R
#     numbers of the whole design came from here (setup -5.6 ns, hold -4.5 ns, dfi_clk<->pclkx1 / hs_rx_clk).  The source side IS stable: the Gray register
#     primary_addr_gray_reg_reg[*] (vendor sfifo.v:253, keep) - it is also the form that survives P&R (the set_max_delay -from .clk lines never went invalid).
#     Form: per-instance, from the Gray pointer register to the destination clock, set_max_delay -datapath_only 4.0 ns (< the shortest period involved, dfi_clk 4.285 ns),
#     i.e. the Gray bits must all arrive inside one destination period; hold is not analysed (-datapath_only), which is the intended CDC treatment of a Gray pointer.
#     This replaces a first-stage false_path with a BOUNDED delay (stricter, not looser); it is not a clock-group.
# E14 A ui_dbuf (patched, C-04c): write-FSM idle flag, ui_clk -> I_W_wclk.  W_idle_ui = (W_MS == S_IDLE) is a single flop output (one bit, no
#     decode on the way); W_idle_sync1 / W_idle_sync is the 2-FF chain in I_W_wclk.  Replaces the direct multi-bit read of W_MS at uidbuf.v:214.

# E16 A ui_dbuf (C-04d, NEW): W_empty (sfifo empty_flag = rd_addr_diff==0, built from read-side address and synchronised write address in the sfifo read clock) was read
#     unsynchronised in the I_W_wclk (hs_rx) lost-sync decision.  W_empty_sync1 is now the first stage of a 2-FF chain.  Its D has exactly one source (W_empty), so the
#     exception is applied to the capture pin only (no -from: the source is a combinational cone over several sfifo address flops whose netlist names are not verified).
#     Effect on behaviour: the lost-sync decision is delayed by 2 hs_rx cycles (~27 ns).  W_empty is a FIFO fill state, changes slowly, and the path only feeds a recovery sequence.

# E17 (3rd synthesis, user-approved) clk_70m (MIPI lp clock, PLL clkc[3]) -> hs_rx_clk: vendor MIPI wrapper, lane0 hs_detect O_hs_en -> S_data_lane_hs_en_1d (first flop).
#     Reported -0.956 ns with a 0.005 ns budget: STA treats 68.75 MHz and 100 MHz as related clocks whose edges coincide at 160 ns.
#     WHY a false_path and not a new waiver: A's original SDC separated hs_rx from the other clocks with an asynchronous clock group, so this path was
#     already outside timing in the A design, which works on hardware.  The merge replaced the blanket group by per-signal exceptions (D3); this restores
#     A's behaviour for this one path, it does not add a release.  The synchroniser structure inside the vendor wrapper is NOT visible to us (source not
#     available): the justification is behavioural, hs_en is a lane-enable that changes only at HS burst start/end (orders of magnitude slower than either clock).
#     Applied to the single reported endpoint pin only; if TD reports the same crossing on other lanes, add them one by one after reading the report.

# E15 pixel -> serial reset crossing (display side, stage2 serial_reset_sync): the reset is asserted ASYNCHRONOUSLY from the pclk domain and released
#     synchronously by a 2-FF chain in the serial domain.  The async set/reset pin has no setup requirement (first merged synthesis reported
#     X_reset/hold_cnt_reg[20] -> u_serial_reset_sync/q_reg[*].sr as a pclk->serial setup path, SWNS -0.038 ns).  The RELEASE is guaranteed by
#     serial_reset_sync itself (2 flops clocked by the serial clock), not by this path.  The TD pin name is ".sr" (not CLR): from the timing report.
set_false_path -to [get_cells -hier {u_disp/X_hdmi_tx/u_serial_reset_sync_l0/q_reg* u_disp/X_hdmi_tx/u_serial_reset_sync_l1/q_reg* u_disp/X_hdmi_tx/u_serial_reset_sync_l2/q_reg* u_disp/X_hdmi_tx/u_serial_reset_sync_l3/q_reg*}]   ;# E15 cell form (4b-fix2): in P&R the pin names .sr/.d are gone (packed slice: .ssr/.asr/.ia), the cell name q_reg[N]_syn_M still matches q_reg*.
#     NOTE (fix13): each serial_reset_sync now also has a dedicated OSERDES-rst flop named q_reg_io; its name starts with q_reg so the same patterns (q_reg*) cover its async set.
#     NOTE (4b-fix2): a cell form covers ALL inputs of the packed cell, not only the reset pin; for E15/F01 that includes the D of the 2-FF reset chain (same-clock, 1 hop).

# F01 (found by the 2nd synthesis, NEW): A ui_dbuf sfifo read-side reset synchroniser.  wfifo_rst (a function of wrst_cnt, I_W_wclk = hs_rx_clk) drives the ASYNCHRONOUS
#     set pins of asy_r_rst0/asy_r_rst1 in the read clock domain (sfifo.v:84-90: assert async, release through the two flops synchronously in the read clock).
#     Same structure as E15: the async pin has no setup requirement, the release timing is guaranteed by asy_r_rst0->asy_r_rst1 inside the FIFO.  Reported -2.832 ns
#     (hs_rx_clk -> dfi_clk, X_ui_dbuf/wrst_cnt_reg[0].clk -> X_ui_dbuf/wdbuf_fifo/asy_r_rst0_reg.sr).  Applied to the .sr pins only; their .d pins stay timed.

# ===========================================================================
# SECTION 2 - BUNDLED-DATA payloads: set_max_delay -datapath_only.  Each is qualified by a toggle/handshake that is synchronised
# separately (section 1); the proof is: forward window (data arrives before it is used) + reverse window (data is not rewritten while
# it is being used).  The bound is an UPPER bound on the data path; -datapath_only drops the clock-skew term and hold analysis, which is
# valid ONLY because the data is static around the use instant (the reverse window).
# ===========================================================================
# D1 A video -> sys snapshot data: done_* memories/registers, done_req/done_valid, st_* (frame-path status snapshot), tq_* (timeout-path
#    status snapshot), fm_result (HS_RX meter result).
#    Forward: done_*/done_req/done_valid are written >= 1 video clock BEFORE frame_toggle flips; st_* are written ON the flip edge;
#             tq_* one video clock before tq_ack toggles; fm_result one clock before fm_done toggles.
#             The sys side first reads st_* at the third sys edge after the flip (meta, sync, evt) -> >= 80 ns after the flip edge
#             (first sampling edge can fall right behind the flip).  Bound 40 ns < 80 ns, i.e. >= 40 ns of margin.
#    Reverse: R-2 interlock - no key is accepted during report_snapshot_active/report_active, an accepted key clears done_valid and
#             discards pending events, so no done_*/st_* write can occur in a snapshot window (tb_r2 S2/S3, M1/M7: wr_in_snap=0).
#             st_* are rewritten no earlier than the next frame commit (>= 12 us); tq_* only on a new request; fm_result once per 2 gates.
#    -to is the sys-domain CLOCK (not a cell list): the receivers are the report_* registers AND the control flops that read done_valid/done_req
#    combinationally (evt_valid), too many/too implicit to enumerate by name. A -to on the clock keeps the exception to paths that END in the
#    sys domain; paths from these registers into hs_rx_clk endpoints (none exist: tools/reader check, 0 video-domain reads of the -from names)
#    and every hs_rx_clk-internal path stay under the 10 ns hs_rx_clk constraint. clk_25m is NOT listed: that domain has no reader of these
#    registers (user-confirmed; re-verify at the first merged synthesis: the -to sys_clk match count and the clock of the report_* flops).
#    The patterns are the DATA names only; the single-bit handshakes (tq_req_*, tq_ack*, fm_done*, frame_toggle*) stay under E02/E09/E10/E12.
set_max_delay 40.000 -datapath_only -from [get_pins {X_wave_sample32_uart/done_*.clk X_wave_sample32_uart/st_post_state*.clk X_wave_sample32_uart/st_div_*.clk X_wave_sample32_uart/st_divisor*.clk X_wave_sample32_uart/st_fill_stage*.clk X_wave_sample32_uart/tq_post_state*.clk X_wave_sample32_uart/tq_div_*.clk X_wave_sample32_uart/tq_divisor*.clk X_wave_sample32_uart/tq_fill_stage*.clk X_wave_sample32_uart/tq_capture_count*.clk X_wave_sample32_uart/tq_y_*.clk X_wave_sample32_uart/tq_bin_*.clk X_wave_sample32_uart/fm_result*.clk}] -to [get_clocks {sys_clk}]   ;# -from names VERIFIED in TD netlist 2026-11-02 (get_pins: register arrays, bits collapse to [N]; see 4b notes); -to clock defined in this SDC
# D2 A R-2 fm_report copy and report_hs_cnt are sys-domain only (no crossing).
# D3 B scope payload sys -> pixel: scope_frequency_x10, amplitude, harmonics, heights, type, status, dc_mean.
#    Forward: written on the same sys edge as scope_commit_toggle (B writes together).  The pixel side samples the payload at the third
#             pixel edge after the toggle (update_sync != update_seen) = latency in (2T, 3T] = (14.5, 21.8] ns after the toggle edge ->
#             the payload path must be < 2T = 14.5 ns.  Bound 12 ns (2.5 ns margin).  PROPOSED value: it is the number STA must
#             confirm; if the routed slack is negative the design (not this number) has to change.
#    Reverse: next payload change >= 43.4 ms later (tb_cdc_b B5: dt_tog_min 43.4 ms at 40 kHz, 63.3 ms at 3 kHz) vs a 3-pixel-edge window.
set_max_delay 12.000 -datapath_only -from [get_pins {X_b_core/scope_frequency_x10*.clk X_b_core/scope_amplitude_cv*.clk X_b_core/scope_harmonics_cv*.clk X_b_core/scope_harmonic_heights*.clk X_b_core/scope_wave_type*.clk X_b_core/scope_status*.clk X_b_core/scope_dc_mean*.clk}] -to [get_clocks {pclkx1}]   ;# -from names VERIFIED in TD netlist 2026-11-02 (get_pins: register arrays, bits collapse to [N]; see 4b notes); -to clock defined in this SDC
# D4 (4b-fix10: + u_disp/X_scope/waveform_flat*.clk - in P&R the sys-domain bank registers carry this name, hold -1.231 at wave_sample_r_reg, 12 endpoints) B waveform banks sys -> pixel: scope_wave0*, scope_wave1*, scope_valid0*, scope_valid1* (768+ bits x 2 banks).
#    The pixel side reads only the bank selected by bank_sync; a bank is written (ANALYZE) only while it is NOT published (P3=0) and
#    the displayed bus changes only on a toggle/bank-flip edge (P4=0).  Published flip -> first write to the old bank >= 22.6 ms
#    (lower bound, trace wait skipped; real >= +2.2 s) vs. bank switch in the pixel domain <= 20.5 ns.  The data is therefore
#    static for the whole time it is displayed.  THE GUARANTEE COMES FROM THE STATIC WINDOW, NOT FROM THIS DELAY BOUND; the bound only keeps
#    the routed path from running away.  40 ns (not 12 ns as in D3): D3's 12 ns embodies a design requirement (< 2 pixel periods) and is strict;
#    here 12 ns would only add routing pressure with no benefit.
set_max_delay 40.000 -datapath_only -from [get_pins {X_b_core/scope_wave0*.clk X_b_core/scope_wave1*.clk X_b_core/scope_valid0*.clk X_b_core/scope_valid1*.clk u_disp/X_scope/waveform_flat*.clk}] -to [get_clocks {pclkx1}]   ;# -from names VERIFIED in TD netlist 2026-11-02 (get_pins: register arrays, bits collapse to [N]; see 4b notes); -to clock defined in this SDC

# D5 (4b-fix12/13) sys_clk-domain B core -> pclkx1: bounded delay, hold NOT analysed (-datapath_only).  PIN FORM ONLY.
#    HISTORY: P&R of fix11 had hold WNS -1.801 ns, 44 endpoints, ALL sys_clk -> pclkx1 (15) or sys_clk -> clk_25m reset removal (29), budget 0.000 ns, clock skew
#    +2.08 ns (pclkx1 arrives 2.08 ns after sys_clk: same PLL, coincident edges, big PLL insertion delay), data delay 0.3-0.9 ns.  The router even logs
#    'PHY-5089 Skip 44 abnormal timing path for routing due to clock skew is greater than 1000ps' for exactly these.  The launching cells are packed slices NAMED AFTER AN
#    ARBITRARY MEMBER (X_b_core/scope_commit_toggle_reg_syn_N, frame_mode_reg_syn_N, state_reg[N]_syn_N), so the name lists of D3/D4 do not cover them.
#    Re-analysis of the routed database (viol_pr8) does NOT re-read the SDC: only a new P&R applies a changed SDC.
#    RESULT of the fix12b P&R (chk.timing item 9): this pin-form line DOMINATES 9194 of 9208 paths; the clock-pair form 'set_max_delay 12 -from sys_clk -to pclkx1' that was tried
#    next to it was SHADOWED on 8014 of 8016 paths (nothing unique) and was removed in fix13 and RE-ADDED in fix14 as D5b (name drift in the fix13 P&R left 12 hold paths uncovered).  Hold went to +0.020 ns, 0 violations.
#    COMPLETENESS (static reader check, fix13): the only sys-domain values that reach the pixel domain are the B scope inputs of merge_top_s3 (I_w0/I_w1 banks, I_w_bank,
#    I_w_tog, I_w_freq/amp/harm/hh/type/stat) - payload (D3), banks (D4), toggle/bank (E04/E05) - plus ddr_init_done which goes through the pclk rst_sync.  Every register of
#    b_core.v is clocked by sys_clk, so '-from X_b_core/*.clk -to pclkx1' selects exactly these crossings.
#    EFFECT ON D3/D4: this line is the dominant one for them (chk.timing: D3 1864 and D4 6096 paths 'Shadowed').  D3 is unchanged (same 12 ns); D4's payload bound is therefore 12 ns instead
#    of 40 ns, which the routed design meets (setup WNS >= 0).  The D4 static-window argument (data not rewritten while displayed) is what makes the waiver of hold valid.
#    WHAT THIS LOOSENS: hold is not analysed on paths that START in a cell named X_b_core/* and END at a pclkx1 flop; a pclk flop packed into such a cell would lose its hold check.
set_max_delay 12.000 -datapath_only -from [get_pins {X_b_core/*.clk}] -to [get_clocks {pclkx1}]
# D5b (4b-fix14) SAFETY NET for D5: the same bound, clock-pair form.  WHY: in the fix13 P&R the cell names drifted again - 12 sys_clk -> pclkx1 paths (hold -0.88..-1.175 ns, endpoints
#    u_disp/X_scope/wave_sample_r_reg[0..11]) started in packed cells named u_disp/X_scope/sub7_syn_62 and X_wave_sample32_uart/mux2447_syn_NNNN, which neither D5 (X_b_core/*) nor D4 match, so
#    nothing waived their hold (chk.timing 9: D5 dominated 7954 paths, 8 ignored).  The pin form WINS where it matches (it keeps shadowing this line, as seen in fix12b: 8014 of 8016 shadowed),
#    this line only takes the leftovers.  Every sys_clk -> pclkx1 path in this design is a crossing (static reader check in D5), so the clock-pair form loosens nothing that D5 does not.
set_max_delay 12.000 -datapath_only -from [get_clocks {sys_clk}] -to [get_clocks {pclkx1}]
# D8 (4b-fix14) pixel clock (pclkx1) -> serial clock (pclkx5): the HDMI 10:1 serialiser hand-over, bounded delay, hold NOT analysed (-datapath_only).
#    OBSERVED: fix13 P&R setup -0.056 ns, pclkx1 O_tmds_code_data_reg -> lane_lvds_10_1 S_shift_data_reg[N], budget 1.454 ns (ONE serial period), data 0.869 ns, skew 0.361.
#    WHY THE DEFAULT 1-CYCLE CHECK IS THE WRONG MODEL (lane_lvds_10_1.v, A's own vendor RTL, not modified): pclkx5 = 5 x pclkx1 from the same PLL, edges coincide every pixel period.
#    S_odd_even toggles on every pixel edge; the serial side detects the toggle through S_odd_even_1d/_2d, S_load_en, _1d, _2d (5 serial flops) and only then loads S_shift_data <= I_data_in.
#    So the 10-bit word is sampled 4..5 serial periods (5.8..7.3 ns) after the pixel edge that launched it (4 if the first toggle flop already sees the new value, 5 otherwise) - never 1.
#    The data word is stable for the whole pixel period.  Bound = 4.0 ns (< 4 serial periods = 5.816 ns), which also keeps the 10 bits routed close together.
#    REFERENCE: project A's own timing.sdc puts clk_25m(=137.5 MHz pixel), clk_70m(=687.5 MHz serial), pclkx1 and pclkx5 in SEPARATE async groups (set_clock_groups -asynchronous), i.e. A never
#    timed this crossing at all and is board-proven; D8 is stricter than A (bounded) and keeps the same hold treatment as A.
#    WHAT THIS LOOSENS: hold is not analysed for pixel -> serial paths.  The only race is the capture at the 5th serial edge, which coincides with the NEXT pixel launch; it needs data delay
#    (clk2q + route, observed 0.87 ns) > capture-vs-launch clock skew (observed 0.36 ns).  Not verified by STA any more - same as A.  This line covers ALL pclkx1 -> pclkx5 paths: the toggle
#    first stage S_odd_even_1d (metastability-by-design, second stage follows) and the data bus.  E15 (set_false_path to q_reg*) still wins for the reset-synchroniser flops.
set_max_delay 4.000 -datapath_only -from [get_clocks {pclkx1}] -to [get_clocks {pclkx5}]
# D9 (4b-fix15) HDMI serial-reset synchroniser, hop between its own flops (pclkx5 -> pclkx5), bounded delay, hold NOT analysed (-datapath_only).  NAME-INDEPENDENT on the capture side.
#    OBSERVED (DAC-only P&R, 2026-11-03 00:53): pclkx5 setup -0.500 / -0.119 / -0.091 ns, 3 endpoints, ALL of them hops inside serial_reset_sync (q_reg_io[0]->[1], q[5]->[6], q[5]->q_reg_io):
#    launch cells u_serial_reset_sync_lN/q_reg*_syn_M, but the capture cells were named X_wave_sample32_uart/mux7_syn_157 and mux3388_syn_577 (TD names a packed slice after one of its members).
#    E15 (set_false_path -to q_reg*) matches the CAPTURE cell name, so it silently stopped covering these hops - the same hops that were waived in the earlier accepted runs only by name luck.
#    WHY A BOUND INSTEAD OF A WAIVER: the chain input is a monotonic 0->1 step per reset release.  If one hop captures the step one serial period late, the release just reaches the OSERDES one cycle later
#    (reset stays asserted a bit longer); it cannot create a glitch or a wrong value.  2 serial periods = 2.908 ns, bound 2.8 ns (same style as D8) also stops the tool from spreading the chain over the chip.
#    The LAUNCH side is matched by pin (begin cells keep the q_reg* names in every report so far, q_reg_io_reg* included), the capture side by clock only, so a renamed capture cell cannot escape.
#    NOT CHANGED: E15 (async set pins), the OSERDES reset pin check (q_reg_io -> O_hdmi_tx_p[*].rst recovery, +0.174 ns in that P&R) - BUT it starts at the same launch pins, so TD may now judge it with this
#    2.8 ns bound.  CHECK in the next final_timing.rpt: the 'recovery' group of pclkx5 must still list O_hdmi_tx_p[*].rst with a slack; if it is gone, read the net delay of q_reg_io -> .rst by hand (was 0.81 ns).
set_max_delay 2.800 -datapath_only -from [get_pins {u_disp/X_hdmi_tx/u_serial_reset_sync_l0/q_reg*.clk u_disp/X_hdmi_tx/u_serial_reset_sync_l1/q_reg*.clk u_disp/X_hdmi_tx/u_serial_reset_sync_l2/q_reg*.clk u_disp/X_hdmi_tx/u_serial_reset_sync_l3/q_reg*.clk}] -to [get_clocks {pclkx5}]
# D6 (4b-fix12b/13, effective: removal -0.685/-0.167 gone in the fix12b P&R) sys_clk reset synchroniser -> clk_25m asynchronous-reset pins, REMOVAL.  clk_25m is the 25 MHz output of u_disp/X_ui_pll (multiply_by 1.0 from I_sys_clk), so
#    it is phase-aligned to sys_clk with the PLL insertion delay (+2.08 ns).  Reported -0.685 ns (X_ui_cfg_imx415 cnt/add2) and -0.167 ns (ae_set, key1, rst_cnt): the
#    release from u_disp/X_reset/u_sys arrives 1.5-2.0 ns after the sys edge, i.e. 0.1-0.6 ns BEFORE the clk_25m edge, so the clk_25m flops leave reset one
#    25 MHz cycle earlier than STA assumes.  cfg_imx415 / ae_set are A's modules; I did not re-verify which reset A itself used for them.  Waived with set_false_path (4b-fix12b; was set_max_delay -datapath_only 40 in fix12).
#    HONEST LIMIT: the release is within ~0.1-0.6 ns of the clk_25m edge, which is a real (one-time, at reset release) metastability exposure of those flops; it is A's own structure.
set_false_path -from [get_pins {u_disp/X_reset/u_sys/q_reg*.clk}] -to [get_clocks {clk_25m}]   ;# D6 (4b-fix12b): false_path instead of set_max_delay -datapath_only: same treatment as E15/F01 (async reset release), and it is the form that is known to remove removal AND recovery checks on reset pins

# ===========================================================================
# STILL OPEN (no exception, paths fully timed / will show as violated in STA by design):
#   C-04c  A ui_dbuf: W_MS (written in ui_clk) is read directly in the W_wclk domain, no synchroniser.  Original structure of A,
#          needs a design review, NOT constrained here.
#   A timeout path with TIMEOUT_LIVE_DUMP=1 is an uncontrolled read and is excluded from every acceptance build (parameter default 0).
#   hs_rx_clk period (10 ns above) is a 100 MHz upper bound until HS_RX_CNT has been read on the board.
# ===========================================================================
