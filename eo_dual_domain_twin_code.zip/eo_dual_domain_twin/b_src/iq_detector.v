`timescale 1ns/1ps
// 13-bit centered sample, Q15 references, signed 48-bit sums.
// Q uses positive sine; sine phase is atan2(I,Q).
module iq_detector(
 input wire clk, input wire rst_n, input wire clear, input wire sample_valid,
 input wire signed [12:0] sample, input wire [31:0] phase,
 output reg signed [47:0] i_acc, output reg signed [47:0] q_acc);
 wire signed [15:0] sine,cosine;
 // Round to closest ROM phase instead of truncation (avoids 0.7 deg bias).
 wire [31:0] rounded_phase=phase+32'h00800000;
 sincos_rom reference_rom(.address(rounded_phase[31:24]),.sine(sine),.cosine(cosine));
 wire signed [28:0] i_product=sample*cosine;
 wire signed [28:0] q_product=sample*sine;
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin i_acc<=0; q_acc<=0; end
  else if (clear) begin i_acc<=0; q_acc<=0; end
  else if (sample_valid) begin
   i_acc<=i_acc+{{19{i_product[28]}},i_product};
   q_acc<=q_acc+{{19{q_product[28]}},q_product};
  end
 end
endmodule
