`timescale 1ns/1ps
// Read at the ADC falling edge, HALF_DIV system-clock periods after rising.
// adc_d[0] is the physical MSB. All logic remains in the sys_clk domain.
module adc_interface #(parameter integer HALF_DIV=2,
                       parameter integer REVERSE_BIT_ORDER=1)(
 input wire sys_clk, input wire rst_n, input wire [11:0] adc_d,
 output reg adc_clk, output reg sample_valid, output reg [11:0] sample_data);
 reg [15:0] divider;
 wire [11:0] code=REVERSE_BIT_ORDER ?
 {adc_d[0],adc_d[1],adc_d[2],adc_d[3],adc_d[4],adc_d[5],
  adc_d[6],adc_d[7],adc_d[8],adc_d[9],adc_d[10],adc_d[11]} : adc_d;
 // Synchronous reset: these registers directly drive the inferred ERAM.
 always @(posedge sys_clk) begin
  if (!rst_n) begin divider<=0; adc_clk<=0; sample_valid<=0; sample_data<=0; end
  else begin
   sample_valid<=0;
   if (divider==HALF_DIV-1) begin
    divider<=0; adc_clk<=~adc_clk;
    if (adc_clk) begin sample_data<=code; sample_valid<=1; end
   end else divider<=divider+1'b1;
  end
 end
endmodule

