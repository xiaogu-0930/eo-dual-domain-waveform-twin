`timescale 1ns/1ps
// Conservative waveform classification from fundamental-relative harmonics.
module waveform_classifier #(
 parameter integer MIN_H1=16,
 parameter integer SINE_MAX_PERCENT=5,
 parameter integer EVEN_MAX_PERCENT=8)(
 input wire clk,
 input wire rst_n,
 input wire analyze,
 input wire metrics_valid,
 input wire clipped,
 input wire [15:0] h1,
 input wire [15:0] h2,
 input wire [15:0] h3,
 input wire [15:0] h4,
 input wire [15:0] h5,
 output reg result_valid,
 output reg [2:0] wave_type);

 localparam [2:0] TYPE_SINE=0, TYPE_SQUARE=1, TYPE_TRIANGLE=2,
  TYPE_MIXED=3, TYPE_UNKNOWN=4;

 wire higher_are_small =
  (h2 * 100 <= h1 * SINE_MAX_PERCENT) &&
  (h3 * 100 <= h1 * SINE_MAX_PERCENT) &&
  (h4 * 100 <= h1 * SINE_MAX_PERCENT) &&
  (h5 * 100 <= h1 * SINE_MAX_PERCENT);
 wire even_are_small =
  (h2 * 100 <= h1 * EVEN_MAX_PERCENT) &&
  (h4 * 100 <= h1 * EVEN_MAX_PERCENT);
 wire square_h3 = (h3 * 100 >= h1 * 28) && (h3 * 100 <= h1 * 39);
 wire square_h5 = (h5 * 100 >= h1 * 15) && (h5 * 100 <= h1 * 25);
 wire triangle_h3 = (h3 * 100 >= h1 * 8) && (h3 * 100 <= h1 * 14);
 wire triangle_h5 = (h5 * 1000 >= h1 * 25) && (h5 * 1000 <= h1 * 55);

 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) begin
   result_valid <= 1'b0;
   wave_type <= TYPE_UNKNOWN;
  end else begin
   result_valid <= 1'b0;
   if (analyze) begin
    result_valid <= 1'b1;
    if (!metrics_valid || clipped || h1 < MIN_H1)
     wave_type <= TYPE_UNKNOWN;
    else if (higher_are_small)
     wave_type <= TYPE_SINE;
    else if (even_are_small && square_h3 && square_h5)
     wave_type <= TYPE_SQUARE;
    else if (even_are_small && triangle_h3 && triangle_h5)
     wave_type <= TYPE_TRIANGLE;
    else
     wave_type <= TYPE_MIXED;
   end
  end
 end
endmodule
