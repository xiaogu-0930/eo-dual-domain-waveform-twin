`timescale 1ns/1ps
module nco(
 input wire clk, input wire rst_n, input wire clear, input wire enable,
 input wire [31:0] phase_increment,
 output reg [31:0] phase);
 always @(posedge clk or negedge rst_n) begin
  if (!rst_n) phase<=0;
  else if (clear) phase<=0;
  else if (enable) phase<=phase+phase_increment;
 end
endmodule
