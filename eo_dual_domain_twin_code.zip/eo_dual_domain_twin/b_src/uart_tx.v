`timescale 1ns/1ps
// send accepted only when !busy; idle high, 8-N-1, least significant bit first.
module uart_tx #(parameter integer CLK_HZ=25000000,
                 parameter integer BAUD=115200)(
 input wire clk, input wire rst_n, input wire send, input wire [7:0] data,
 output reg tx, output reg busy);
 localparam integer BIT_CYCLES=(CLK_HZ+BAUD/2)/BAUD;
 reg [15:0] baud_count;
 reg [3:0] bit_number;
 reg [9:0] shift_register;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   tx<=1; busy<=0; baud_count<=0; bit_number<=0; shift_register<=10'h3ff;
  end else if(!busy) begin
   tx<=1;
   if(send) begin
    shift_register<={1'b1,data,1'b0}; tx<=0; busy<=1; baud_count<=0; bit_number<=0;
   end
  end else if(baud_count==BIT_CYCLES-1) begin
   baud_count<=0;
   if(bit_number==9) begin busy<=0; tx<=1; end
   else begin
    bit_number<=bit_number+1'b1;
    shift_register<={1'b1,shift_register[9:1]}; tx<=shift_register[1];
   end
  end else baud_count<=baud_count+1'b1;
 end
endmodule
