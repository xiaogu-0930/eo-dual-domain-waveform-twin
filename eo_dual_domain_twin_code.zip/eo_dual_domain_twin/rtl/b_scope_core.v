`timescale 1ns/1ps
module b_scope_core #(parameter integer DRAW_DIVIDER=1)(
 input wire pixel_clk,
 input wire rst_n,
 input wire [767:0] waveform0_flat,
 input wire [767:0] waveform1_flat,
 input wire waveform_bank,
 input wire update_toggle,
 input wire [23:0] frequency_x10_in,
 input wire [15:0] amplitude_cv_in,
 input wire [79:0] harmonics_cv_in,
 input wire [39:0] harmonic_heights_in,
 input wire [2:0] wave_type_in,
 input wire [2:0] status_in,
 input wire [11:0] x_in,
 input wire [11:0] y_in,
 output reg [23:0] rgb
);
 localparam integer H_ACTIVE=1920,H_TOTAL=2068;
 localparam integer H_SYNC_START=2008,H_SYNC_END=2052;
 localparam integer V_ACTIVE=1080,V_TOTAL=1108;
 localparam integer V_SYNC_START=1084,V_SYNC_END=1089;
 localparam integer GRAPH_X=32,GRAPH_W=896,GRAPH_Y=100,GRAPH_H=550;
 reg [11:0] h_d1,h_d2,v_d1,v_d2;
 wire [11:0] scan_x=x_in;
 wire [11:0] scan_y=y_in;
 reg [5:0] wave_bin;
 reg [11:0] wave_sample_r,wave_y_r;
 reg bank_meta,bank_sync,update_meta,update_sync,update_seen; /* fehdl keep="true" */
 reg [27:0] frequency_digits;
 reg [15:0] amplitude_digits;
 reg [23:0] frequency_binary_work,amplitude_binary_work;
 reg [27:0] frequency_bcd_work;
 reg [19:0] amplitude_bcd_work;
 reg [4:0] bcd_cycle;
 reg bcd_active;
 reg [39:0] harmonic_heights;
 reg [15:0] harm_bin0,harm_bin1,harm_bin2,harm_bin3,harm_bin4;
 reg [19:0] harm_bcd0,harm_bcd1,harm_bcd2,harm_bcd3,harm_bcd4;
 reg [19:0] harm_digits0,harm_digits1,harm_digits2,harm_digits3,harm_digits4;
 reg [4:0] harm_cycle;
 reg harm_active;
 reg [2:0] wave_type,status;
 wire [767:0] waveform_flat=bank_sync?waveform1_flat:waveform0_flat;
 wire [11:0] h_count=h_d2,v_count=v_d2;
 wire [23:0] wave_y_offset=({12'd0,(12'd4095-wave_sample_r)}*24'd550)>>12;
 wire active_video=(h_count<H_ACTIVE && v_count<V_ACTIVE);
 wire [3:0] freq_d0=frequency_digits[3:0];
 wire [3:0] freq_d1=frequency_digits[7:4];
 wire [3:0] freq_d2=frequency_digits[11:8];
 wire [3:0] freq_d3=frequency_digits[15:12];
 wire [3:0] freq_d4=frequency_digits[19:16];
 wire [3:0] freq_d5=frequency_digits[23:20];
 wire [3:0] amp_d0=amplitude_digits[3:0];
 wire [3:0] amp_d1=amplitude_digits[7:4];
 wire [3:0] amp_d2=amplitude_digits[11:8];
 wire [3:0] amp_d3=amplitude_digits[15:12];
 function [27:0] bcd_add3_7;
  input [27:0] value;
  integer n;
  begin
   bcd_add3_7=value;
   for(n=0;n<7;n=n+1)
    if(value[n*4 +: 4]>=4'd5) bcd_add3_7[n*4 +: 4]=value[n*4 +: 4]+4'd3;
  end
 endfunction
 function [19:0] bcd_add3_5;
  input [19:0] value;
  integer n;
  begin
   bcd_add3_5=value;
   for(n=0;n<5;n=n+1)
    if(value[n*4 +: 4]>=4'd5) bcd_add3_5[n*4 +: 4]=value[n*4 +: 4]+4'd3;
  end
 endfunction
 wire [27:0] freq_bcd_adj=bcd_add3_7(frequency_bcd_work);
 wire [19:0] amp_bcd_adj=bcd_add3_5(amplitude_bcd_work);
 wire [27:0] freq_bcd_next={freq_bcd_adj[26:0],frequency_binary_work[23]};
 wire [19:0] amp_bcd_next={amp_bcd_adj[18:0],amplitude_binary_work[23]};
 wire [19:0] harm_adj0=bcd_add3_5(harm_bcd0);
 wire [19:0] harm_adj1=bcd_add3_5(harm_bcd1);
 wire [19:0] harm_adj2=bcd_add3_5(harm_bcd2);
 wire [19:0] harm_adj3=bcd_add3_5(harm_bcd3);
 wire [19:0] harm_adj4=bcd_add3_5(harm_bcd4);
 wire [19:0] harm_next0={harm_adj0[18:0],harm_bin0[15]};
 wire [19:0] harm_next1={harm_adj1[18:0],harm_bin1[15]};
 wire [19:0] harm_next2={harm_adj2[18:0],harm_bin2[15]};
 wire [19:0] harm_next3={harm_adj3[18:0],harm_bin3[15]};
 wire [19:0] harm_next4={harm_adj4[18:0],harm_bin4[15]};
 function [6:0] seven_segment;
  input [3:0] value;
  begin
   case(value)
    0:seven_segment=7'b1111110;1:seven_segment=7'b0110000;
    2:seven_segment=7'b1101101;3:seven_segment=7'b1111001;
    4:seven_segment=7'b0110011;5:seven_segment=7'b1011011;
    6:seven_segment=7'b1011111;7:seven_segment=7'b1110000;
    8:seven_segment=7'b1111111;9:seven_segment=7'b1111011;
    default:seven_segment=7'b0000001;
   endcase
  end
 endfunction
 function [4:0] glyph_row;
  input [7:0] ch; input [2:0] row;
  begin
   case(ch)
    "0":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=19;3:glyph_row=21;4:glyph_row=25;5:glyph_row=17;6:glyph_row=14;default:glyph_row=0;endcase
    "1":case(row) 0:glyph_row=4;1:glyph_row=12;2:glyph_row=4;3:glyph_row=4;4:glyph_row=4;5:glyph_row=4;6:glyph_row=14;default:glyph_row=0;endcase
    "2":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=1;3:glyph_row=2;4:glyph_row=4;5:glyph_row=8;6:glyph_row=31;default:glyph_row=0;endcase
    "3":case(row) 0:glyph_row=30;1:glyph_row=1;2:glyph_row=1;3:glyph_row=14;4:glyph_row=1;5:glyph_row=1;6:glyph_row=30;default:glyph_row=0;endcase
    "4":case(row) 0:glyph_row=2;1:glyph_row=6;2:glyph_row=10;3:glyph_row=18;4:glyph_row=31;5:glyph_row=2;6:glyph_row=2;default:glyph_row=0;endcase
    "5":case(row) 0:glyph_row=31;1:glyph_row=16;2:glyph_row=16;3:glyph_row=30;4:glyph_row=1;5:glyph_row=1;6:glyph_row=30;default:glyph_row=0;endcase
    "6":case(row) 0:glyph_row=14;1:glyph_row=16;2:glyph_row=16;3:glyph_row=30;4:glyph_row=17;5:glyph_row=17;6:glyph_row=14;default:glyph_row=0;endcase
    "7":case(row) 0:glyph_row=31;1:glyph_row=1;2:glyph_row=2;3:glyph_row=4;4:glyph_row=8;5:glyph_row=8;6:glyph_row=8;default:glyph_row=0;endcase
    "8":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=17;3:glyph_row=14;4:glyph_row=17;5:glyph_row=17;6:glyph_row=14;default:glyph_row=0;endcase
    "9":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=17;3:glyph_row=15;4:glyph_row=1;5:glyph_row=1;6:glyph_row=14;default:glyph_row=0;endcase
    "A":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=17;3:glyph_row=31;4:glyph_row=17;5:glyph_row=17;6:glyph_row=17;default:glyph_row=0;endcase
    "E":case(row) 0:glyph_row=31;1:glyph_row=16;2:glyph_row=16;3:glyph_row=30;4:glyph_row=16;5:glyph_row=16;6:glyph_row=31;default:glyph_row=0;endcase
    "F":case(row) 0:glyph_row=31;1:glyph_row=16;2:glyph_row=16;3:glyph_row=30;4:glyph_row=16;5:glyph_row=16;6:glyph_row=16;default:glyph_row=0;endcase
    "G":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=16;3:glyph_row=23;4:glyph_row=17;5:glyph_row=17;6:glyph_row=15;default:glyph_row=0;endcase
    "H":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=17;3:glyph_row=31;4:glyph_row=17;5:glyph_row=17;6:glyph_row=17;default:glyph_row=0;endcase
    "I":case(row) 0:glyph_row=14;1:glyph_row=4;2:glyph_row=4;3:glyph_row=4;4:glyph_row=4;5:glyph_row=4;6:glyph_row=14;default:glyph_row=0;endcase
    "K":case(row) 0:glyph_row=17;1:glyph_row=18;2:glyph_row=20;3:glyph_row=24;4:glyph_row=20;5:glyph_row=18;6:glyph_row=17;default:glyph_row=0;endcase
    "L":case(row) 0:glyph_row=16;1:glyph_row=16;2:glyph_row=16;3:glyph_row=16;4:glyph_row=16;5:glyph_row=16;6:glyph_row=31;default:glyph_row=0;endcase
    "M":case(row) 0:glyph_row=17;1:glyph_row=27;2:glyph_row=21;3:glyph_row=21;4:glyph_row=17;5:glyph_row=17;6:glyph_row=17;default:glyph_row=0;endcase
    "N":case(row) 0:glyph_row=17;1:glyph_row=25;2:glyph_row=25;3:glyph_row=21;4:glyph_row=19;5:glyph_row=19;6:glyph_row=17;default:glyph_row=0;endcase
    "O":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=17;3:glyph_row=17;4:glyph_row=17;5:glyph_row=17;6:glyph_row=14;default:glyph_row=0;endcase
    "P":case(row) 0:glyph_row=30;1:glyph_row=17;2:glyph_row=17;3:glyph_row=30;4:glyph_row=16;5:glyph_row=16;6:glyph_row=16;default:glyph_row=0;endcase
    "Q":case(row) 0:glyph_row=14;1:glyph_row=17;2:glyph_row=17;3:glyph_row=17;4:glyph_row=21;5:glyph_row=18;6:glyph_row=13;default:glyph_row=0;endcase
    "R":case(row) 0:glyph_row=30;1:glyph_row=17;2:glyph_row=17;3:glyph_row=30;4:glyph_row=20;5:glyph_row=18;6:glyph_row=17;default:glyph_row=0;endcase
    "S":case(row) 0:glyph_row=15;1:glyph_row=16;2:glyph_row=16;3:glyph_row=14;4:glyph_row=1;5:glyph_row=1;6:glyph_row=30;default:glyph_row=0;endcase
    "T":case(row) 0:glyph_row=31;1:glyph_row=4;2:glyph_row=4;3:glyph_row=4;4:glyph_row=4;5:glyph_row=4;6:glyph_row=4;default:glyph_row=0;endcase
    "U":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=17;3:glyph_row=17;4:glyph_row=17;5:glyph_row=17;6:glyph_row=14;default:glyph_row=0;endcase
    "V":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=17;3:glyph_row=17;4:glyph_row=17;5:glyph_row=10;6:glyph_row=4;default:glyph_row=0;endcase
    "z":case(row) 0:glyph_row=0;1:glyph_row=31;2:glyph_row=2;3:glyph_row=4;4:glyph_row=8;5:glyph_row=16;6:glyph_row=31;default:glyph_row=0;endcase
    "p":case(row) 0:glyph_row=0;1:glyph_row=30;2:glyph_row=17;3:glyph_row=30;4:glyph_row=16;5:glyph_row=16;6:glyph_row=16;default:glyph_row=0;endcase
    "=":case(row) 0:glyph_row=0;1:glyph_row=31;2:glyph_row=0;3:glyph_row=31;4:glyph_row=0;5:glyph_row=0;6:glyph_row=0;default:glyph_row=0;endcase
    "W":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=17;3:glyph_row=21;4:glyph_row=21;5:glyph_row=21;6:glyph_row=10;default:glyph_row=0;endcase
    "X":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=10;3:glyph_row=4;4:glyph_row=10;5:glyph_row=17;6:glyph_row=17;default:glyph_row=0;endcase
    "Y":case(row) 0:glyph_row=17;1:glyph_row=17;2:glyph_row=10;3:glyph_row=4;4:glyph_row=4;5:glyph_row=4;6:glyph_row=4;default:glyph_row=0;endcase
    "D":case(row) 0:glyph_row=30;1:glyph_row=17;2:glyph_row=17;3:glyph_row=17;4:glyph_row=17;5:glyph_row=17;6:glyph_row=30;default:glyph_row=0;endcase
    ".":glyph_row=(row==6)?4:0;
    default:glyph_row=0;
   endcase
  end
 endfunction
 function [7:0] title_char;
  input [5:0] index;
  begin case(index)
   0:title_char="F";1:title_char="P";2:title_char="G";3:title_char="A";
   5:title_char="W";6:title_char="A";7:title_char="V";8:title_char="E";
   9:title_char="F";10:title_char="O";11:title_char="R";12:title_char="M";
   14:title_char="M";15:title_char="O";16:title_char="N";17:title_char="I";
   18:title_char="T";19:title_char="O";20:title_char="R";default:title_char=" ";
  endcase end
 endfunction
 function [7:0] type_char;
  input [2:0] typ; input [3:0] index;
  begin
   type_char=" ";
   case(typ)
    0:case(index) 0:type_char="S";1:type_char="I";2:type_char="N";3:type_char="E";default:type_char=" ";endcase
    1:case(index) 0:type_char="S";1:type_char="Q";2:type_char="U";3:type_char="A";4:type_char="R";5:type_char="E";default:type_char=" ";endcase
    2:case(index) 0:type_char="T";1:type_char="R";2:type_char="I";3:type_char="A";4:type_char="N";5:type_char="G";6:type_char="L";7:type_char="E";default:type_char=" ";endcase
    3:case(index) 0:type_char="M";1:type_char="I";2:type_char="X";3:type_char="E";4:type_char="D";default:type_char=" ";endcase
    default:case(index) 0:type_char="U";1:type_char="N";2:type_char="K";3:type_char="N";4:type_char="O";5:type_char="W";6:type_char="N";default:type_char=" ";endcase
   endcase
  end
 endfunction


 // ---- C-09 timing fix (pclk, 2nd synthesis: v_d2 -> char_calc -> text_char_pipe was 12 LUT levels, -3.9 ns at 137.5 MHz) ----
 // ZERO added latency: the /12, %12, /30, %30 of the text layout are computed in the two stages that already existed as plain delay registers
 // (h_d1 -> h_d2, v_d1 -> v_d2): stage 1 (aligned with h_d1/v_d1) registers  scan - offset  (low 8 bits: every in-range difference is < 256),
 // stage 2 (aligned with h_d2/v_d2) registers the quotient / remainder.  char_calc then reads q_*/c_*/hr_/m_ instead of dividing.
 // Out-of-range values are garbage but never used: every use sits inside the original range test on h_count/v_count.
 // The latency x_in -> rgb stays 5 clocks and the output stays cycle-identical to B's hdmi_scope_fast (tb_scope_equiv T4/T5).
 reg [7:0] d1_f,d1_a,d1_t,d1_h,d1_i0,d1_i1,d1_i2,d1_i3,d1_i4,d1_v;
 reg [3:0] q_f,q_a,q_t,q_h;
 reg [2:0] c_f,c_a,c_t,c_h,c_i0,c_i1,c_i2,c_i3,c_i4;
 reg       z_i0,z_i1,z_i2,z_i3,z_i4;      // (h-off)/12 == 0 for the five harmonic labels
 reg [2:0] hr_v;                          // (v-758)/30
 reg [4:0] m_v;                           // (v-758)%30
 function [3:0] dq12; input [7:0] d; begin dq12=d/12; end endfunction
 function [2:0] dc12; input [7:0] d; reg [3:0] r; begin r=d%12; dc12=r>>1; end endfunction
 reg [23:0] base_calc;
 reg trace_calc,bar_calc,text_active_calc,number_calc,status_calc,axis_calc;
 reg [23:0] base_pipe;
 reg [23:0] base_pipe2;
 reg trace_pipe,bar_pipe,number_pipe,status_pipe,axis_pipe;
 reg trace_pipe2,bar_pipe2,number_pipe2,status_pipe2,axis_pipe2;
 reg [7:0] text_char_pipe;
 reg [2:0] text_row_pipe;
 reg [2:0] text_col_pipe;
 reg text_active_pipe,text_pipe;
 wire [4:0] text_glyph_pipe=glyph_row(text_char_pipe,text_row_pipe);
 wire [2:0] text_glyph_idx=(text_col_pipe<3'd5)?(3'd4-text_col_pipe):3'd0;   // STAGE3 FIX: baseline indexed [4-col] -> -1 for col=5 (X in sim, implementation-defined in hardware)
 reg [3:0] digit_calc;
 reg [5:0] digit_x_calc;
 reg [4:0] digit_y_calc;
 reg [3:0] digit_pipe;
 reg [5:0] digit_x_pipe;
 reg [4:0] digit_y_pipe;
 reg number_active_pipe;
 reg [6:0] segment_calc;
 reg [7:0] char_calc;
 reg [2:0] row_calc;
 reg [2:0] col_calc;
 reg [4:0] glyph_calc;
 reg [7:0] bar_height_calc;
 wire [6:0] segment_pipe=seven_segment(digit_pipe);
 wire number_pixel_pipe_value=
  (segment_pipe[0]&&digit_y_pipe<2&&digit_x_pipe>=4&&digit_x_pipe<16)||
  (segment_pipe[1]&&digit_x_pipe>=15&&digit_y_pipe>=1&&digit_y_pipe<7)||
  (segment_pipe[2]&&digit_x_pipe>=15&&digit_y_pipe>=9&&digit_y_pipe<15)||
  (segment_pipe[3]&&digit_y_pipe>=14&&digit_x_pipe>=4&&digit_x_pipe<16)||
  (segment_pipe[4]&&digit_x_pipe<5&&digit_y_pipe>=9&&digit_y_pipe<15)||
  (segment_pipe[5]&&digit_x_pipe<5&&digit_y_pipe>=1&&digit_y_pipe<7)||
  (segment_pipe[6]&&digit_y_pipe>=7&&digit_y_pipe<9&&digit_x_pipe>=4&&digit_x_pipe<16);

 always @* begin
  base_calc=24'h080b10;
  trace_calc=0;bar_calc=0;text_active_calc=0;number_calc=0;status_calc=0;axis_calc=0;
  digit_calc=0;digit_x_calc=0;digit_y_calc=0;segment_calc=0;
  char_calc=8'h20;row_calc=0;col_calc=0;glyph_calc=0;
  bar_height_calc=0;
  if(active_video && h_count<960) begin
   base_calc=(v_count<82)?24'h17212b:24'h10151d;
   if(h_count>=GRAPH_X && h_count<GRAPH_X+GRAPH_W &&
      v_count>=GRAPH_Y && v_count<GRAPH_Y+GRAPH_H) begin
    base_calc=24'h17212b;
    if(h_count[5:0]==6'd32 || v_count[4:0]==5'd4) base_calc=24'h283744;
    if(h_count[3:0]==4'd0) base_calc=24'h202c36;
    if(h_count>=GRAPH_X+GRAPH_W/2-1 && h_count<=GRAPH_X+GRAPH_W/2+1) axis_calc=1;
    if(v_count>=wave_y_r-2 && v_count<=wave_y_r+2) trace_calc=1;
   end
   // Bottom spectrum: five vertical bars, with a separate harmonic-value column.
   if(v_count>=748 && v_count<1000 && h_count>=40 && h_count<630) begin
    if(v_count==996 || v_count==936 || v_count==876 || v_count==816 || v_count==756) axis_calc=1;
    if(h_count>=70 && h_count<150) bar_height_calc=harmonic_heights[7:0];
    else if(h_count>=180 && h_count<260) bar_height_calc=harmonic_heights[15:8];
    else if(h_count>=290 && h_count<370) bar_height_calc=harmonic_heights[23:16];
    else if(h_count>=400 && h_count<480) bar_height_calc=harmonic_heights[31:24];
    else if(h_count>=510 && h_count<590) bar_height_calc=harmonic_heights[39:32];
    if(v_count>=996-bar_height_calc && v_count<996 && bar_height_calc!=0) bar_calc=1;
   end
   // Compact 5x7 pixel font at 2x scale. F0, amplitude and type share one row.
   if(v_count>=32 && v_count<46) begin
    if(h_count>=28 && h_count<184) begin
     case(q_f)
      0:char_calc="F";1:char_calc="0";2:char_calc="=";
      3,4,5,6,7,8:char_calc=8'd48+frequency_digits[(6-(q_f-3))*4 +: 4];
      9:char_calc=".";10:char_calc=8'd48+frequency_digits[3:0];11:char_calc="H";12:char_calc="z";
      default:char_calc=" ";
     endcase
     row_calc=(v_count-32)>>1;col_calc=c_f;text_active_calc=1;
    end else if(h_count>=220 && h_count<364) begin
     case(q_a)
      0:char_calc="A";1:char_calc="M";2:char_calc="P";3:char_calc="=";
      4:char_calc=8'd48+amplitude_digits[15:12];5:char_calc=8'd48+amplitude_digits[11:8];
      6:char_calc=".";7:char_calc=8'd48+amplitude_digits[7:4];8:char_calc=8'd48+amplitude_digits[3:0];
      9:char_calc="V";10:char_calc="p";11:char_calc="p";
      default:char_calc=" ";
     endcase
     row_calc=(v_count-32)>>1;col_calc=c_a;text_active_calc=1;
    end else if(h_count>=404 && h_count<560) begin
     case(q_t)
      0:char_calc="T";1:char_calc="Y";2:char_calc="P";3:char_calc="E";4:char_calc="=";
      default:char_calc=type_char(wave_type,q_t-5);
     endcase
     row_calc=(v_count-32)>>1;col_calc=c_t;text_active_calc=1;
    end
   end
   // H1-H5 values: fixed 5-digit centivolt BCD, displayed as xxx.xx Vpp.
   if(v_count>=758 && v_count<908 && h_count>=650 && h_count<818 &&
      m_v<14) begin
    case(q_h)
     0:char_calc="H";1:char_calc=8'd49+hr_v;2:char_calc="=";
     3:char_calc=8'd48+(hr_v==0?harm_digits0[15:12]:(hr_v==1?harm_digits1[15:12]:(hr_v==2?harm_digits2[15:12]:(hr_v==3?harm_digits3[15:12]:harm_digits4[15:12]))));
     4:char_calc=8'd48+(hr_v==0?harm_digits0[11:8]:(hr_v==1?harm_digits1[11:8]:(hr_v==2?harm_digits2[11:8]:(hr_v==3?harm_digits3[11:8]:harm_digits4[11:8]))));
     5:char_calc=".";
     6:char_calc=8'd48+(hr_v==0?harm_digits0[7:4]:(hr_v==1?harm_digits1[7:4]:(hr_v==2?harm_digits2[7:4]:(hr_v==3?harm_digits3[7:4]:harm_digits4[7:4]))));
     7:char_calc=8'd48+(hr_v==0?harm_digits0[3:0]:(hr_v==1?harm_digits1[3:0]:(hr_v==2?harm_digits2[3:0]:(hr_v==3?harm_digits3[3:0]:harm_digits4[3:0]))));
     8:char_calc="V";9:char_calc="p";10:char_calc="p";default:char_calc=" ";
    endcase
    row_calc=m_v>>1;col_calc=c_h;text_active_calc=1;
   end
   // Harmonic identifiers centered below the five bars.
   if(v_count>=1008 && v_count<1022) begin
    if(h_count>=98 && h_count<122) begin char_calc=z_i0?"H":"1";row_calc=(v_count-1008)>>1;col_calc=c_i0;text_active_calc=1;end
    else if(h_count>=208 && h_count<232) begin char_calc=z_i1?"H":"2";row_calc=(v_count-1008)>>1;col_calc=c_i1;text_active_calc=1;end
    else if(h_count>=318 && h_count<342) begin char_calc=z_i2?"H":"3";row_calc=(v_count-1008)>>1;col_calc=c_i2;text_active_calc=1;end
    else if(h_count>=428 && h_count<452) begin char_calc=z_i3?"H":"4";row_calc=(v_count-1008)>>1;col_calc=c_i3;text_active_calc=1;end
    else if(h_count>=538 && h_count<562) begin char_calc=z_i4?"H":"5";row_calc=(v_count-1008)>>1;col_calc=c_i4;text_active_calc=1;end
   end
   if(status!=0&&h_count>=900&&h_count<936&&v_count>=42&&v_count<78) status_calc=1;
   if(DRAW_DIVIDER!=0 && h_count==959) axis_calc=1;
  end
 end

 always @(posedge pixel_clk or negedge rst_n) begin
  if(!rst_n) begin
   h_d1<=0;h_d2<=0;v_d1<=0;v_d2<=0;
   d1_f<=0;d1_a<=0;d1_t<=0;d1_h<=0;d1_i0<=0;d1_i1<=0;d1_i2<=0;d1_i3<=0;d1_i4<=0;d1_v<=0;
   q_f<=0;q_a<=0;q_t<=0;q_h<=0;c_f<=0;c_a<=0;c_t<=0;c_h<=0;c_i0<=0;c_i1<=0;c_i2<=0;c_i3<=0;c_i4<=0;
   z_i0<=0;z_i1<=0;z_i2<=0;z_i3<=0;z_i4<=0;hr_v<=0;m_v<=0;
   wave_bin<=0;wave_sample_r<=12'd2048;wave_y_r<=GRAPH_Y+GRAPH_H/2;
   bank_meta<=0;bank_sync<=0;update_meta<=0;update_sync<=0;update_seen<=0;
   frequency_digits<=0;amplitude_digits<=0;frequency_binary_work<=0;amplitude_binary_work<=0;
   frequency_bcd_work<=0;amplitude_bcd_work<=0;bcd_cycle<=0;bcd_active<=0;
   harmonic_heights<=0;wave_type<=3'd4;status<=3'd4;
   harm_bin0<=0;harm_bin1<=0;harm_bin2<=0;harm_bin3<=0;harm_bin4<=0;
   harm_bcd0<=0;harm_bcd1<=0;harm_bcd2<=0;harm_bcd3<=0;harm_bcd4<=0;
   harm_digits0<=0;harm_digits1<=0;harm_digits2<=0;harm_digits3<=0;harm_digits4<=0;
   harm_cycle<=0;harm_active<=0;
   base_pipe<=0;base_pipe2<=0;
   trace_pipe<=0;bar_pipe<=0;number_pipe<=0;status_pipe<=0;axis_pipe<=0;
   trace_pipe2<=0;bar_pipe2<=0;number_pipe2<=0;status_pipe2<=0;axis_pipe2<=0;
    text_char_pipe<=8'h20;text_row_pipe<=0;text_col_pipe<=0;text_active_pipe<=0;text_pipe<=0;
    digit_pipe<=0;digit_x_pipe<=0;digit_y_pipe<=0;number_active_pipe<=0;
   rgb<=0;
  end else begin
   bank_meta<=waveform_bank;bank_sync<=bank_meta;
   update_meta<=update_toggle;update_sync<=update_meta;
   if(update_sync!=update_seen) begin
    update_seen<=update_sync;frequency_binary_work<=frequency_x10_in;
    amplitude_binary_work<={8'd0,amplitude_cv_in};frequency_bcd_work<=0;amplitude_bcd_work<=0;
    bcd_cycle<=0;bcd_active<=1'b1;harmonic_heights<=harmonic_heights_in;
    harm_bin0<=harmonics_cv_in[15:0];harm_bin1<=harmonics_cv_in[31:16];
    harm_bin2<=harmonics_cv_in[47:32];harm_bin3<=harmonics_cv_in[63:48];
    harm_bin4<=harmonics_cv_in[79:64];
    harm_bcd0<=0;harm_bcd1<=0;harm_bcd2<=0;harm_bcd3<=0;harm_bcd4<=0;
    harm_cycle<=0;harm_active<=1'b1;
    wave_type<=wave_type_in;status<=status_in;
   end else if(bcd_active) begin
    frequency_binary_work<={frequency_binary_work[22:0],1'b0};
    amplitude_binary_work<={amplitude_binary_work[22:0],1'b0};
    frequency_bcd_work<=freq_bcd_next;amplitude_bcd_work<=amp_bcd_next;
    if(bcd_cycle==23) begin
     frequency_digits<=freq_bcd_next;amplitude_digits<=amp_bcd_next[15:0];bcd_active<=0;
    end else bcd_cycle<=bcd_cycle+1'b1;
   end
   if(harm_active) begin
    harm_bin0<={harm_bin0[14:0],1'b0};harm_bin1<={harm_bin1[14:0],1'b0};
    harm_bin2<={harm_bin2[14:0],1'b0};harm_bin3<={harm_bin3[14:0],1'b0};harm_bin4<={harm_bin4[14:0],1'b0};
    harm_bcd0<=harm_next0;harm_bcd1<=harm_next1;harm_bcd2<=harm_next2;
    harm_bcd3<=harm_next3;harm_bcd4<=harm_next4;
    if(harm_cycle==15) begin
     harm_digits0<=harm_next0;harm_digits1<=harm_next1;harm_digits2<=harm_next2;
     harm_digits3<=harm_next3;harm_digits4<=harm_next4;harm_active<=0;
    end else harm_cycle<=harm_cycle+1'b1;
   end
   h_d1<=scan_x;h_d2<=h_d1;v_d1<=scan_y;v_d2<=v_d1;
   // C-09 stage 1 (same edge as h_d1/v_d1): scan - offset
   d1_f<=scan_x-12'd28;  d1_a<=scan_x-12'd220; d1_t<=scan_x-12'd404; d1_h<=scan_x-12'd650;
   d1_i0<=scan_x-12'd98; d1_i1<=scan_x-12'd208; d1_i2<=scan_x-12'd318; d1_i3<=scan_x-12'd428; d1_i4<=scan_x-12'd538;
   d1_v<=scan_y-12'd758;
   // C-09 stage 2 (same edge as h_d2/v_d2): quotient / remainder
   q_f<=dq12(d1_f); c_f<=dc12(d1_f); q_a<=dq12(d1_a); c_a<=dc12(d1_a);
   q_t<=dq12(d1_t); c_t<=dc12(d1_t); q_h<=dq12(d1_h); c_h<=dc12(d1_h);
   c_i0<=dc12(d1_i0); z_i0<=(dq12(d1_i0)==4'd0); c_i1<=dc12(d1_i1); z_i1<=(dq12(d1_i1)==4'd0);
   c_i2<=dc12(d1_i2); z_i2<=(dq12(d1_i2)==4'd0); c_i3<=dc12(d1_i3); z_i3<=(dq12(d1_i3)==4'd0);
   c_i4<=dc12(d1_i4); z_i4<=(dq12(d1_i4)==4'd0);
   hr_v<=d1_v/30; m_v<=d1_v%30;
   wave_sample_r<=waveform_flat[wave_bin*12 +: 12];
   wave_y_r<=GRAPH_Y+wave_y_offset;
   if(scan_x>=GRAPH_X&&scan_x<GRAPH_X+GRAPH_W)
    wave_bin<=(((scan_x-GRAPH_X)*12'd192)/GRAPH_W);
   else wave_bin<=0;
   base_pipe<=base_calc;base_pipe2<=base_pipe;
   trace_pipe<=trace_calc;bar_pipe<=bar_calc;number_pipe<=number_calc;status_pipe<=status_calc;axis_pipe<=axis_calc;
   trace_pipe2<=trace_pipe;bar_pipe2<=bar_pipe;number_pipe2<=number_pipe;
   status_pipe2<=status_pipe;axis_pipe2<=axis_pipe;
   text_char_pipe<=char_calc;text_row_pipe<=row_calc;text_col_pipe<=col_calc;
   text_active_pipe<=text_active_calc;text_pipe<=text_active_pipe&&(text_col_pipe<3'd5)&&text_glyph_pipe[text_glyph_idx]; // STAGE3 FIX: col 5 (character gap) is forced to 0; no out-of-range index
    digit_pipe<=digit_calc;digit_x_pipe<=digit_x_calc;digit_y_pipe<=digit_y_calc;
    number_active_pipe<=number_calc;number_pipe<=number_active_pipe&&number_pixel_pipe_value;
   rgb<=base_pipe2;
   if(trace_pipe2) rgb<=24'h45e6ce;
   if(bar_pipe2) rgb<=24'h418cc8;
   if(text_pipe) rgb<=24'hf2f6fa;
   if(number_pipe2) rgb<=24'hf4cf66;
   if(status_pipe2) rgb<=24'he6565c;
   if(axis_pipe2) rgb<=24'h9ab0be;
  end
 end
endmodule
