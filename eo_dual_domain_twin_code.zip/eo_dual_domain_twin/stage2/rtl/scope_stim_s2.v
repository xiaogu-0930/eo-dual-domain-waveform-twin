`timescale 1ns/1ps
// STAGE 2 TEMPORARY placeholder for B's analysis outputs (replaced by the real wave_harmonic data path in a later
// stage).  Constant waveform/numbers so the left half has defined content; update_toggle toggles once, 2^15 sys
// clocks after power-up, so the scope latches the waveform.  Deterministic, synthesizable, no random.
module scope_stim_s2 (
 input  wire         clk,           // I_sys_clk (25 MHz)
 output wire [767:0] waveform0_flat,
 output wire [767:0] waveform1_flat,
 output wire         waveform_bank,
 output reg          update_toggle,
 output wire [23:0]  frequency_x10_in,
 output wire [15:0]  amplitude_cv_in,
 output wire [79:0]  harmonics_cv_in,
 output wire [39:0]  harmonic_heights_in,
 output wire [2:0]   wave_type_in,
 output wire [2:0]   status_in
);
 genvar i;
 generate
  for (i = 0; i < 24; i = i + 1) begin : g_w
   assign waveform0_flat[i*32 +: 32] = (32'h9E3779B1 * (i + 1)) ^ 32'hA5C31F2B;
   assign waveform1_flat[i*32 +: 32] = (32'h85EBCA6B * (i + 3)) ^ 32'h1B873593;
  end
 endgenerate
 assign waveform_bank       = 1'b0;
 assign frequency_x10_in    = 24'd12345;
 assign amplitude_cv_in     = 16'd500;
 assign harmonics_cv_in     = 80'h0123_4567_89AB_CDEF_0246;
 assign harmonic_heights_in = 40'h1234_5678_9A;
 assign wave_type_in        = 3'd1;
 assign status_in           = 3'd0;
 reg [15:0] cnt = 16'd0;
 initial update_toggle = 1'b0;
 always @(posedge clk) begin
  if (cnt != 16'hFFFF) cnt <= cnt + 1'b1;
  if (cnt == 16'h8000) update_toggle <= ~update_toggle;
 end
endmodule
