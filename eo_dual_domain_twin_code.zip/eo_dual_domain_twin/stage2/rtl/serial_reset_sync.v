`timescale 1ns/1ps
// STAGE2 (decision D1): reset synchroniser for the HDMI serial-clock domain.
//   assertion : asynchronous (I_rst high sets every stage at once)
//   release   : synchronous - O_serial_rst falls on an I_serial_clk edge, STAGES serial clocks after I_rst fell
// STAGES >= 2.  STAGES=8 is a starting value; the simulation proves the release is on a serial edge and lasts
// exactly STAGES edges, it does NOT prove 8 is sufficient for the OSERDES on the board (BOARD TEST item).
// Note: every stage has the asynchronous set pin driven by I_rst (standard reset synchroniser), so recovery/removal
// checks apply to all STAGES flops, not only the first one (differs from item 2 of the v2 plan; listed in report).
module serial_reset_sync #(parameter integer STAGES = 8)(
 input  wire I_serial_clk,
 input  wire I_rst,          // high-active, pixel-domain, asynchronous to I_serial_clk
 output wire O_serial_rst,   // high-active, released synchronously to I_serial_clk
 output wire O_serial_rst_io // STAGE5 (fix13): SAME VALUE as O_serial_rst, from its own pipeline (fix14, see below) that drives ONLY the OSERDES rst pin (single load)
);
 reg [STAGES-1:0] q; /* fehdl keep="true" */   // STAGE5 (fix11): keep so that the per-lane copies in hdmi_tx are not merged back into one chain
 // STAGE5 (fix14): O_serial_rst_io is the end of a NIO-flop pipeline that starts NIO stages early on the same chain, so its value in every cycle is identical to q[STAGES-1]
 // (q[STAGES-1](t) = q[STAGES-1-NIO](t-NIO)); assertion is still asynchronous for every flop.  Reason: in the fix13 P&R the single q_reg_io flop was placed 29 rows away from the
 // OSERDES (net 1.13-1.27 ns of a 1.454 ns period) and the recovery check failed by -0.14..-0.30 ns on 4 lanes; with a pipeline the placer can walk the signal to the I/O.
 // The names start with q_reg so that the E15 cell patterns (.../u_serial_reset_sync_lN/q_reg*) also cover these flops (their async set comes from the pixel domain).
 localparam integer NIO = (STAGES > 3) ? 3 : (STAGES - 1);
 reg [NIO-1:0] q_reg_io; /* fehdl keep="true" */
 always @(posedge I_serial_clk or posedge I_rst) begin
  if (I_rst) begin
   q        <= {STAGES{1'b1}};
   q_reg_io <= {NIO{1'b1}};
  end else begin
   q        <= {q[STAGES-2:0], 1'b0};
   q_reg_io <= (q_reg_io << 1) | q[STAGES-1-NIO];   // shift-in at bit 0; valid for every NIO>=1 (STAGES=2 -> NIO=1 is used by the S2/Q2 tests)
  end
 end
 assign O_serial_rst    = q[STAGES-1];
 assign O_serial_rst_io = q_reg_io[NIO-1];
endmodule
